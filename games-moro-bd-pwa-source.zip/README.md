<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/1b0e9b5f-efb0-4a9e-9fcf-f482b357daef

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Install as a Chrome Web App (PWA)

This project now includes a Web App Manifest, app icons, and a service worker.
1. Deploy the app to a public HTTPS host. Chrome's install option requires HTTPS (or localhost).
2. Keep the Express backend running; this project uses `/api` endpoints.
3. Build with `npm install` then `npm run build`, and run the server with `NODE_ENV=production npm start` on a Node.js host.
4. Open the HTTPS site in Chrome on Android, then use the browser menu (⋮) → **Install app** or **Add to Home screen**.

Important: the current server stores app data in in-memory arrays. Data can reset when the server restarts, and this is not production-ready for real tournaments or payments. Add a persistent database and secure authentication/authorization before public use. Do not expose API keys or secrets in client code.
