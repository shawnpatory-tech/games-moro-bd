/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { AndroidShell } from './components/common/AndroidShell.tsx';
import { TopAppBar } from './components/common/TopAppBar.tsx';
import { BottomNavBar } from './components/common/BottomNavBar.tsx';
import { ToastContainer } from './components/common/ToastContainer.tsx';

import { HomeDashboard } from './components/player/HomeDashboard.tsx';
import { TournamentFeed } from './components/player/TournamentFeed.tsx';
import { MyMatchesView } from './components/player/MyMatchesView.tsx';
import { LeaderboardView } from './components/player/LeaderboardView.tsx';
import { ProfileView } from './components/player/ProfileView.tsx';

import { OfficerDashboard } from './components/officer/OfficerDashboard.tsx';
import { AdminDashboard } from './components/admin/AdminDashboard.tsx';

import { TournamentDetailModal } from './components/player/TournamentDetailModal.tsx';
import { AuthModal } from './components/modals/AuthModal.tsx';
import { NotificationsDrawer } from './components/modals/NotificationsDrawer.tsx';
import { RulesModal } from './components/modals/RulesModal.tsx';
import { HelpSupportModal } from './components/modals/HelpSupportModal.tsx';
import { FirebaseDocModal } from './components/modals/FirebaseDocModal.tsx';
import { WalletModal } from './components/modals/WalletModal.tsx';
import { QualifyPayModal } from './components/player/QualifyPayModal.tsx';

import type { Tournament, TournamentMode } from './types/index.ts';
import { api } from './services/api.ts';

function MainApp() {
  const { user, role, isLoading } = useAuth();

  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [qualifyTournament, setQualifyTournament] = useState<Tournament | null>(null);
  const [modeFilter, setModeFilter] = useState<TournamentMode | undefined>(undefined);
  const [registeredCount, setRegisteredCount] = useState<number>(0);

  // Modals
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isFirebaseDocOpen, setIsFirebaseDocOpen] = useState<boolean>(false);
  const [isWalletOpen, setIsWalletOpen] = useState<boolean>(false);

  const fetchRegisteredCount = async () => {
    if (!user) return;
    try {
      const res = await api.getTournaments();
      const myCount = res.tournaments.filter((t) =>
        t.registeredPlayers.some((p) => p.userId === user.id)
      ).length;
      setRegisteredCount(myCount);
    } catch (err) {}
  };

  useEffect(() => {
    fetchRegisteredCount();
  }, [user, currentTab, selectedTournament]);

  const handleFilterModeFromHome = (mode: TournamentMode) => {
    setModeFilter(mode);
    setCurrentTab('tournaments');
  };

  const handleSelectTournamentFromNotif = async (tournamentId: string) => {
    try {
      const res = await api.getTournament(tournamentId);
      setSelectedTournament(res.tournament);
    } catch (err) {}
  };

  if (isLoading && !user) {
    return (
      <div className="min-h-screen bg-[#07080c] flex flex-col items-center justify-center text-white">
        <div className="relative w-16 h-16 rounded-2xl overflow-hidden border border-red-500 shadow-xl mb-4 animate-pulse">
          <img
            src="/src/assets/images/tournament_badge_logo_1793899506853.jpg"
            alt="GAMES MORO BD"
            className="w-full h-full object-cover"
          />
        </div>
        <h1 className="font-heading font-extrabold text-lg tracking-wider uppercase">
          GAMES MORO <span className="text-red-500">BD</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1 font-mono">
          Connecting to Tournament Engine...
        </p>
      </div>
    );
  }

  return (
    <AndroidShell
      activeTab={currentTab}
      onOpenNotifications={() => setIsNotificationsOpen(true)}
      onOpenAuth={() => setIsAuthOpen(true)}
    >
      <TopAppBar
        currentView={currentTab}
        onViewChange={(v) => setCurrentTab(v)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenFirebaseDoc={() => setIsFirebaseDocOpen(true)}
        onOpenWallet={() => setIsWalletOpen(true)}
      />

      <ToastContainer />

      {/* Screen Views */}
      <main className="flex-1 flex flex-col">
        {currentTab === 'home' && (
          <HomeDashboard
            onSelectTournament={(t) => setSelectedTournament(t)}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onFilterMode={handleFilterModeFromHome}
            onOpenRules={() => setIsRulesOpen(true)}
            onPayQualify={(t) => setQualifyTournament(t)}
            onOpenWallet={() => setIsWalletOpen(true)}
          />
        )}

        {currentTab === 'tournaments' && (
          <TournamentFeed
            initialMode={modeFilter}
            onSelectTournament={(t) => setSelectedTournament(t)}
            onPayQualify={(t) => setQualifyTournament(t)}
          />
        )}

        {currentTab === 'my-matches' && (
          <MyMatchesView
            onSelectTournament={(t) => setSelectedTournament(t)}
            onExploreTournaments={() => setCurrentTab('tournaments')}
          />
        )}

        {currentTab === 'leaderboard' && <LeaderboardView />}

        {currentTab === 'profile' && (
          <ProfileView
            onOpenRules={() => setIsRulesOpen(true)}
            onOpenHelp={() => setIsHelpOpen(true)}
            onOpenFirebaseDoc={() => setIsFirebaseDocOpen(true)}
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenWallet={() => setIsWalletOpen(true)}
          />
        )}

        {/* Dedicated Staff Consoles */}
        {currentTab === 'officer' && (
          <OfficerDashboard />
        )}

        {currentTab === 'admin' && (
          <AdminDashboard />
        )}
      </main>

      {/* Fixed Bottom Navigation (Always present for 1-handed thumb control) */}
      <BottomNavBar
        currentTab={currentTab}
        onTabChange={(tab) => {
          setModeFilter(undefined);
          setCurrentTab(tab);
        }}
        registeredCount={registeredCount}
      />

      {/* Modals & Drawers */}
      {selectedTournament && (
        <TournamentDetailModal
          tournament={selectedTournament}
          onClose={() => setSelectedTournament(null)}
          onRefresh={async () => {
            const res = await api.getTournament(selectedTournament.id);
            setSelectedTournament(res.tournament);
            fetchRegisteredCount();
          }}
          onPayQualify={(t) => setQualifyTournament(t)}
        />
      )}

      {qualifyTournament && (
        <QualifyPayModal
          tournament={qualifyTournament}
          onClose={() => setQualifyTournament(null)}
          onSuccess={async () => {
            if (selectedTournament?.id === qualifyTournament.id) {
              const res = await api.getTournament(selectedTournament.id);
              setSelectedTournament(res.tournament);
            }
            fetchRegisteredCount();
          }}
          onOpenWallet={() => setIsWalletOpen(true)}
        />
      )}

      {isWalletOpen && (
        <WalletModal onClose={() => setIsWalletOpen(false)} />
      )}

      {isAuthOpen && <AuthModal onClose={() => setIsAuthOpen(false)} />}

      {isNotificationsOpen && (
        <NotificationsDrawer
          onClose={() => setIsNotificationsOpen(false)}
          onSelectTournamentId={handleSelectTournamentFromNotif}
        />
      )}

      {isRulesOpen && <RulesModal onClose={() => setIsRulesOpen(false)} />}

      {isHelpOpen && <HelpSupportModal onClose={() => setIsHelpOpen(false)} />}

      {isFirebaseDocOpen && (
        <FirebaseDocModal onClose={() => setIsFirebaseDocOpen(false)} />
      )}
    </AndroidShell>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
