import React from 'react';
import { Bell, ShieldCheck, Flame, BookOpen, Layers, HelpCircle, Wallet } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface TopAppBarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  onOpenNotifications: () => void;
  onOpenRules: () => void;
  onOpenHelp: () => void;
  onOpenFirebaseDoc: () => void;
  onOpenWallet: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  currentView,
  onViewChange,
  onOpenNotifications,
  onOpenRules,
  onOpenHelp,
  onOpenFirebaseDoc,
  onOpenWallet,
}) => {
  const { user, role, unreadNotifsCount, walletBalance } = useAuth();

  const isManagementView = currentView === 'admin' || currentView === 'officer';

  return (
    <header className="sticky top-0 z-40 bg-[#090a0f]/95 backdrop-blur-md border-b border-white/10 px-4 py-2.5 flex items-center justify-between gap-3">
      {/* Brand Wordmark & Emblem */}
      <div
        onClick={() => onViewChange('home')}
        className="flex items-center gap-2.5 cursor-pointer group shrink-0"
      >
        <div className="relative w-8 h-8 rounded-lg overflow-hidden border border-red-600/40 bg-black/60 shadow-md shadow-red-950/30">
          <img
            src="/src/assets/images/tournament_badge_logo_1793899506853.jpg"
            alt="GAMES MORO BD"
            className="w-full h-full object-cover group-hover:scale-110 transition-transform"
          />
        </div>
        <div className="flex flex-col">
          <span className="font-heading text-base font-extrabold tracking-wider text-white group-hover:text-red-400 transition-colors uppercase leading-tight">
            GAMES MORO <span className="text-red-500">BD</span>
          </span>
          <span className="text-[9px] font-mono tracking-widest text-slate-400 uppercase -mt-0.5">
            Esports Platform
          </span>
        </div>
      </div>

      {/* Center / Right Functional Affordances */}
      <div className="flex items-center gap-1.5 shrink-0">
        {/* Fast Rules & FAQ Quick Triggers */}
        <button
          onClick={onOpenRules}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          title="Official Tournament Rules"
        >
          <BookOpen className="w-4 h-4 text-slate-400" />
        </button>

        <button
          onClick={onOpenHelp}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          title="Support & FAQ"
        >
          <HelpCircle className="w-4 h-4 text-slate-400" />
        </button>

        {/* Firebase & Deployment Guide */}
        <button
          onClick={onOpenFirebaseDoc}
          className="p-1.5 rounded-lg text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
          title="Firebase & Architecture Blueprint"
        >
          <Layers className="w-4 h-4" />
        </button>

        {/* Wallet Balance & Deposit/Withdraw Trigger */}
        <button
          onClick={onOpenWallet}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-500/50 text-emerald-300 font-mono font-bold text-xs transition-all shadow-sm active:scale-95"
          title="ওয়ালেট: ডিপোজিট ও উইথড্র"
        >
          <Wallet className="w-3.5 h-3.5 text-emerald-400" />
          <span>৳{walletBalance}</span>
        </button>

        {/* Dashboard button for Authorized Roles */}
        {(role === 'officer' || role === 'admin' || role === 'owner') && (
          <button
            onClick={() => {
              if (isManagementView) {
                onViewChange('home');
              } else if (role === 'officer') {
                onViewChange('officer');
              } else {
                onViewChange('admin');
              }
            }}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all shadow-sm ${
              isManagementView
                ? 'bg-zinc-800 text-slate-200 border border-white/20 hover:bg-zinc-700'
                : role === 'owner'
                ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-900/40 glow-red'
                : role === 'admin'
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-900/40'
                : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/40'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>
              {isManagementView
                ? 'Player View'
                : role === 'owner'
                ? 'Owner HQ'
                : role === 'admin'
                ? 'Admin HQ'
                : 'Officer Desk'}
            </span>
          </button>
        )}

        {/* Notifications Icon */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadNotifsCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 ring-2 ring-[#090a0f] animate-ping" />
          )}
        </button>
      </div>
    </header>
  );
};
