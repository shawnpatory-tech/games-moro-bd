import React from 'react';
import { Home, Trophy, Swords, Medal, User as UserIcon, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface BottomNavBarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  registeredCount: number;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentTab,
  onTabChange,
  registeredCount,
}) => {
  const { role } = useAuth();

  const isStaff = role === 'officer' || role === 'admin' || role === 'owner';

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'tournaments', label: 'Tournaments', icon: Trophy },
    { id: 'my-matches', label: 'My Matches', icon: Swords, badge: registeredCount > 0 ? registeredCount : undefined },
    { id: 'leaderboard', label: 'Leaderboard', icon: Medal },
    { id: 'profile', label: 'Profile', icon: UserIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0c0d14]/95 backdrop-blur-lg border-t border-white/10 px-2 py-1 max-w-full">
      <div className="grid grid-cols-5 items-center max-w-md mx-auto h-14">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center h-full relative transition-all duration-150 ${
                isActive ? 'text-red-500 scale-105' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
                {item.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-2 bg-red-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] tracking-tight mt-1 truncate ${
                  isActive ? 'font-bold text-white' : 'font-medium'
                }`}
              >
                {item.label}
              </span>
              {isActive && (
                <span className="w-1 h-1 bg-red-500 rounded-full mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
