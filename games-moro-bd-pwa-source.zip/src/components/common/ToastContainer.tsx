import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useAuth();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-14 left-0 right-0 z-50 flex flex-col items-center gap-2 px-4 pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto max-w-sm w-full p-3 rounded-xl shadow-lg border backdrop-blur-md flex items-start gap-2.5 transition-all animate-in fade-in slide-in-from-top-4 ${
            t.type === 'success'
              ? 'bg-zinc-900/95 border-emerald-500/40 text-emerald-200'
              : t.type === 'error'
              ? 'bg-zinc-900/95 border-red-500/40 text-red-200'
              : 'bg-zinc-900/95 border-amber-500/40 text-amber-200'
          }`}
        >
          {t.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          ) : t.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          ) : (
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          )}

          <div className="flex-1 text-xs font-medium leading-relaxed">
            {t.message}
          </div>

          <button
            onClick={() => removeToast(t.id)}
            className="text-slate-400 hover:text-white shrink-0 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
