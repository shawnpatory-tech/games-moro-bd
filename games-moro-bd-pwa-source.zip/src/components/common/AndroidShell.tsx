import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Shield, Award, UserCheck, Flame, User, Bell } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { UserRole } from '../../types/index.ts';

interface AndroidShellProps {
  children: React.ReactNode;
  activeTab: string;
  onOpenNotifications: () => void;
  onOpenAuth: () => void;
}

export const AndroidShell: React.FC<AndroidShellProps> = ({
  children,
  activeTab,
  onOpenNotifications,
  onOpenAuth,
}) => {
  const { user, role, switchRole, unreadNotifsCount } = useAuth();
  const [isPhoneFrame, setIsPhoneFrame] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<string>('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const mins = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${mins}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  const rolesList: { role: UserRole; label: string; icon: React.ReactNode; color: string }[] = [
    { role: 'player', label: 'Player', icon: <User className="w-3.5 h-3.5" />, color: 'text-slate-300' },
    { role: 'officer', label: 'Officer', icon: <UserCheck className="w-3.5 h-3.5" />, color: 'text-blue-400' },
    { role: 'admin', label: 'Admin', icon: <Shield className="w-3.5 h-3.5" />, color: 'text-amber-400' },
    { role: 'owner', label: 'Owner (Super)', icon: <Award className="w-3.5 h-3.5" />, color: 'text-red-400' },
  ];

  return (
    <div className="min-h-screen bg-[#07080c] flex flex-col items-center justify-start text-slate-100 selection:bg-red-600 selection:text-white">
      {/* Top Testing & Viewport Control Strip (Always available for evaluators) */}
      <div className="w-full bg-[#0d0e15] border-b border-white/10 px-3 py-2 z-50">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Quick Perspective Role Switcher */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-slate-400 font-medium hidden sm:inline flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-red-500" />
              Role Switcher:
            </span>
            <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-white/10">
              {rolesList.map((r) => {
                const isActive = role === r.role;
                return (
                  <button
                    key={r.role}
                    onClick={() => switchRole(r.role)}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
                      isActive
                        ? 'bg-red-600 text-white shadow-sm shadow-red-600/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                    title={`Switch perspective to ${r.label}`}
                  >
                    {r.icon}
                    <span>{r.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Viewport Mode & User Status */}
          <div className="flex items-center gap-3">
            {/* Viewport Frame Toggle */}
            <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-white/10">
              <button
                onClick={() => setIsPhoneFrame(true)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-all ${
                  isPhoneFrame ? 'bg-zinc-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Android Mobile Frame Mode"
              >
                <Smartphone className="w-3.5 h-3.5 text-red-400" />
                <span className="hidden sm:inline">Phone Frame</span>
              </button>
              <button
                onClick={() => setIsPhoneFrame(false)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-all ${
                  !isPhoneFrame ? 'bg-zinc-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Full Responsive View"
              >
                <Monitor className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Responsive</span>
              </button>
            </div>

            {/* Current user badge */}
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenNotifications}
                className="relative p-1 text-slate-400 hover:text-slate-200 transition-colors"
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-600 text-[9px] font-bold text-white flex items-center justify-center animate-pulse">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-2 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-md text-[11px] font-medium"
              >
                <img
                  src={user?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                  alt={user?.username}
                  className="w-4 h-4 rounded-full object-cover border border-white/20"
                />
                <span className="truncate max-w-[90px]">{user?.username || 'Guest'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Container: Android Phone Frame OR Full Width */}
      <div
        className={`w-full flex justify-center items-center flex-1 transition-all duration-300 ${
          isPhoneFrame ? 'py-4 sm:py-8 px-2 sm:px-4' : 'p-0'
        }`}
      >
        <div
          className={`relative bg-[#090a0f] flex flex-col transition-all duration-300 overflow-hidden ${
            isPhoneFrame
              ? 'w-full max-w-[412px] h-[860px] max-h-[92vh] rounded-[44px] border-[10px] border-[#181924] shadow-[0_25px_70px_rgba(0,0,0,0.85)] ring-1 ring-white/15'
              : 'w-full max-w-4xl min-h-[calc(100vh-45px)] border-x border-white/10 shadow-2xl'
          }`}
        >
          {/* Android Status Bar (When in Phone Frame) */}
          {isPhoneFrame && (
            <div className="sticky top-0 z-50 bg-[#090a0f]/95 backdrop-blur-md px-6 pt-3 pb-2 flex items-center justify-between text-[11px] text-slate-300 font-mono tracking-tight select-none border-b border-white/5">
              <span>{currentTime}</span>

              {/* Front Camera Pinhole */}
              <div className="w-3.5 h-3.5 rounded-full bg-black ring-2 ring-zinc-800/80 mx-auto" />

              <div className="flex items-center gap-1.5 text-slate-400">
                <span className="text-[10px] font-sans font-bold text-red-500">5G</span>
                {/* Signal bars */}
                <div className="flex items-end gap-[1.5px] h-2.5">
                  <div className="w-[2px] h-1 bg-slate-300 rounded-xs" />
                  <div className="w-[2px] h-1.5 bg-slate-300 rounded-xs" />
                  <div className="w-[2px] h-2 bg-slate-300 rounded-xs" />
                  <div className="w-[2px] h-2.5 bg-slate-300 rounded-xs" />
                </div>
                {/* Battery icon */}
                <div className="w-4 h-2 border border-slate-400 rounded-xs p-[1px] flex items-center">
                  <div className="w-full h-full bg-emerald-400 rounded-xs" />
                </div>
              </div>
            </div>
          )}

          {/* Screen Content Scroll Area */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden flex flex-col pb-20 relative scroll-smooth">
            {children}
          </div>

          {/* Android Navigation Bar Pill (When in Phone Frame) */}
          {isPhoneFrame && (
            <div className="absolute bottom-1 left-0 right-0 h-4 flex items-center justify-center pointer-events-none z-50">
              <div className="w-32 h-1 bg-white/30 rounded-full" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
