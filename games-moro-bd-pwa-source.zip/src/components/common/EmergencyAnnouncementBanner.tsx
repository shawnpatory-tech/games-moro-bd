import React, { useState } from 'react';
import {
  AlertTriangle,
  Flame,
  Info,
  Clock,
  X,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';
import type { AppSettings } from '../../types/index.ts';

interface EmergencyAnnouncementBannerProps {
  banner: AppSettings['emergencyBanner'];
}

export const EmergencyAnnouncementBanner: React.FC<EmergencyAnnouncementBannerProps> = ({
  banner,
}) => {
  const [isDismissed, setIsDismissed] = useState<boolean>(false);

  if (!banner || !banner.enabled || isDismissed) return null;

  const isWarning = banner.type === 'WARNING';
  const isAlert = banner.type === 'ALERT';
  const isMaintenance = banner.type === 'MAINTENANCE';

  return (
    <div
      className={`relative z-30 px-3.5 py-2.5 border-b flex items-center justify-between gap-2.5 transition-all animate-in slide-in-from-top-2 shadow-lg ${
        isWarning
          ? 'bg-red-950/95 border-red-600/70 text-red-100 glow-red'
          : isAlert
          ? 'bg-amber-950/95 border-amber-600/70 text-amber-100'
          : isMaintenance
          ? 'bg-blue-950/95 border-blue-600/70 text-blue-100'
          : 'bg-emerald-950/95 border-emerald-600/70 text-emerald-100'
      }`}
    >
      <div className="flex items-center gap-2 overflow-hidden flex-1">
        <div
          className={`p-1.5 rounded-lg shrink-0 ${
            isWarning
              ? 'bg-red-600 text-white animate-pulse'
              : isAlert
              ? 'bg-amber-600 text-white'
              : isMaintenance
              ? 'bg-blue-600 text-white'
              : 'bg-emerald-600 text-white'
          }`}
        >
          {isWarning ? (
            <AlertTriangle className="w-3.5 h-3.5" />
          ) : isAlert ? (
            <Flame className="w-3.5 h-3.5" />
          ) : isMaintenance ? (
            <Clock className="w-3.5 h-3.5" />
          ) : (
            <Info className="w-3.5 h-3.5" />
          )}
        </div>

        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="font-heading font-extrabold text-[10px] tracking-wider uppercase px-1.5 py-0.2 rounded bg-black/40 border border-white/10 shrink-0">
              {isWarning ? 'জরুরি নোটিশ' : isAlert ? 'গুরুত্বপূর্ণ ঘোষণা' : isMaintenance ? 'সার্ভার রক্ষণাবেক্ষণ' : 'অফিশিয়াল তথ্য'}
            </span>
          </div>
          <p className="text-xs font-semibold leading-tight truncate mt-0.5 select-text">
            {banner.message}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1 shrink-0">
        {banner.linkUrl && (
          <a
            href={banner.linkUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-1 rounded bg-black/40 hover:bg-black/70 text-xs font-bold flex items-center gap-0.5 text-white transition-colors"
          >
            <span>বিস্তারিত</span>
            <ChevronRight className="w-3 h-3" />
          </a>
        )}

        <button
          onClick={() => setIsDismissed(true)}
          className="p-1 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition-colors"
          title="Dismiss"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
