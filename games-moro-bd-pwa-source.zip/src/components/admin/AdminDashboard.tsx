import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  Trophy,
  Swords,
  FileCheck,
  Ban,
  Settings,
  History,
  Download,
  Plus,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Send,
  Eye,
  Check,
  Calendar,
  Layers,
  Sparkles,
  Edit2,
  Lock,
  Wallet,
  Video,
  PhoneCall,
  Sliders,
  UserPlus,
  Play,
  Volume2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type {
  Tournament,
  MatchReport,
  BlacklistEntry,
  AuditLog,
  ScoringConfig,
  User,
  UserRole,
  WalletTransaction,
  AppSettings,
  AbnormalPlayReport,
} from '../../types/index.ts';
import { api } from '../../services/api.ts';
import { QuickBanModal } from './QuickBanModal.tsx';

export const AdminDashboard: React.FC = () => {
  const { user, role, showToast } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'queue' | 'incidents' | 'matches' | 'users' | 'blacklist' | 'customizer' | 'scoring' | 'wallet' | 'audit' | 'broadcast'
  >('queue');

  // Data states
  const [reports, setReports] = useState<MatchReport[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [blacklist, setBlacklist] = useState<BlacklistEntry[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [scoringConfig, setScoringConfig] = useState<ScoringConfig | null>(null);
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>([]);
  const [appSettings, setAppSettings] = useState<AppSettings | null>(null);
  const [abnormalIncidents, setAbnormalIncidents] = useState<AbnormalPlayReport[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Quick Ban modal state
  const [isQuickBanOpen, setIsQuickBanOpen] = useState<boolean>(false);
  const [quickBanDefaultUid, setQuickBanDefaultUid] = useState<string>('');
  const [quickBanDefaultName, setQuickBanDefaultName] = useState<string>('');

  // Add Officer modal state
  const [isAddOfficerOpen, setIsAddOfficerOpen] = useState<boolean>(false);
  const [newOfficerUsername, setNewOfficerUsername] = useState<string>('');
  const [newOfficerIgn, setNewOfficerIgn] = useState<string>('');
  const [newOfficerUid, setNewOfficerUid] = useState<string>('');
  const [newOfficerPhone, setNewOfficerPhone] = useState<string>('');
  const [isSubmittingOfficer, setIsSubmittingOfficer] = useState<boolean>(false);

  // App Customizer form states
  const [isSavingSettings, setIsSavingSettings] = useState<boolean>(false);
  const [editEmergencyEnabled, setEditEmergencyEnabled] = useState<boolean>(true);
  const [editEmergencyType, setEditEmergencyType] = useState<'WARNING' | 'ALERT' | 'INFO' | 'MAINTENANCE'>('WARNING');
  const [editEmergencyMsg, setEditEmergencyMsg] = useState<string>('');
  const [editEmergencyLink, setEditEmergencyLink] = useState<string>('');
  const [editBkash, setEditBkash] = useState<string>('01711000001');
  const [editNagad, setEditNagad] = useState<string>('01811000002');
  const [editRocket, setEditRocket] = useState<string>('01911000003');
  const [editSupportPhone, setEditSupportPhone] = useState<string>('+880 1711 000001');
  const [editWhatsapp, setEditWhatsapp] = useState<string>('+880 1711 000001');
  const [editNoticeBoard, setEditNoticeBoard] = useState<string>('');
  const [editTagline, setEditTagline] = useState<string>('');
  const [editShareMsg, setEditShareMsg] = useState<string>('');
  const [editVideoEnabled, setEditVideoEnabled] = useState<boolean>(true);
  const [editVideoTitle, setEditVideoTitle] = useState<string>('');
  const [editVideoUrl, setEditVideoUrl] = useState<string>('');
  const [editVideoDesc, setEditVideoDesc] = useState<string>('');

  // New Match modal state
  const [isCreatingMatch, setIsCreatingMatch] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState<string>('');
  const [newMode, setNewMode] = useState<'BR_RANK' | 'CS_RANK' | 'LONE_WOLF'>('BR_RANK');
  const [newOfficerId, setNewOfficerId] = useState<string>('');
  const [newStartTime, setNewStartTime] = useState<string>('');

  // Rejection modal state
  const [rejectReportId, setRejectReportId] = useState<string | null>(null);
  const [rejectionNotes, setRejectionNotes] = useState<string>('');

  // Blacklist modal state
  const [isBanning, setIsBanning] = useState<boolean>(false);
  const [banIgn, setBanIgn] = useState<string>('');
  const [banUid, setBanUid] = useState<string>('');
  const [banReason, setBanReason] = useState<string>('');
  const [banDuration, setBanDuration] = useState<'24h' | '7d' | '30d' | 'permanent'>('30d');

  // Announcement state
  const [broadcastTitle, setBroadcastTitle] = useState<string>('');
  const [broadcastMessage, setBroadcastMessage] = useState<string>('');

  // Review evidence modal
  const [previewEvidenceUrl, setPreviewEvidenceUrl] = useState<string | null>(null);

  const fetchAllData = async () => {
    try {
      setIsLoading(true);
      const [repRes, tournRes, userRes, blRes, auditRes, scoreRes, walletRes] = await Promise.all([
        api.getReports(),
        api.getTournaments(),
        api.getUsers(),
        api.getBlacklist(),
        api.getAuditLogs(),
        api.getScoringConfig(),
        api.getAdminWalletTransactions().catch(() => ({ transactions: [] })),
      ]);

      setReports(repRes.reports);
      setTournaments(tournRes.tournaments);
      setUsersList(userRes.users);
      setBlacklist(blRes.blacklist);
      setAuditLogs(auditRes.auditLogs);
      setScoringConfig(scoreRes.scoringConfig);
      setWalletTransactions(walletRes.transactions || []);
    } catch (err) {
      console.error('Error fetching admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Generate Daily Schedule
  const handleAutoSchedule = async () => {
    try {
      const res = await api.generateSchedule();
      showToast(`Generated ${res.count} scheduled match slots for today!`, 'success');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to generate schedule', 'error');
    }
  };

  // Create Custom Tournament
  const handleCreateTournament = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createTournament({
        title: newTitle,
        mode: newMode,
        assignedOfficerId: newOfficerId || undefined,
        startTime: newStartTime ? new Date(newStartTime).toISOString() : undefined,
      });
      showToast('New tournament match created and opened for registration!', 'success');
      setIsCreatingMatch(false);
      setNewTitle('');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to create tournament', 'error');
    }
  };

  // Approve Match Report
  const handleApproveReport = async (reportId: string) => {
    try {
      await api.approveReport(reportId);
      showToast('Match report approved! Tournament points disbursed to players.', 'success');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Approval failed', 'error');
    }
  };

  // Reject Match Report
  const handleRejectReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectReportId) return;
    try {
      await api.rejectReport(rejectReportId, rejectionNotes);
      showToast('Report rejected and returned to officer with notes.', 'info');
      setRejectReportId(null);
      setRejectionNotes('');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Rejection failed', 'error');
    }
  };

  // Change User Role
  const handleChangeRole = async (targetUserId: string, newRole: UserRole) => {
    try {
      await api.updateUserRole(targetUserId, newRole);
      showToast(`User role updated to ${newRole.toUpperCase()}`, 'success');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update role', 'error');
    }
  };

  // Add Blacklist
  const handleBlacklistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.blacklistPlayer({
        inGameUid: banUid,
        username: banIgn,
        reason: banReason,
        duration: banDuration,
      });
      showToast(`UID ${banUid} added to tournament blacklist.`, 'success');
      setIsBanning(false);
      setBanUid('');
      setBanIgn('');
      setBanReason('');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to blacklist player', 'error');
    }
  };

  // Unban
  const handleUnban = async (inGameUid: string) => {
    try {
      await api.unbanPlayer(inGameUid);
      showToast(`Lifted ban on UID ${inGameUid}`, 'success');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to unban player', 'error');
    }
  };

  // Review Appeal
  const handleReviewAppeal = async (
    inGameUid: string,
    decision: 'APPROVE' | 'REJECT',
    notes: string
  ) => {
    try {
      await api.reviewAppeal(inGameUid, decision, notes);
      showToast(`Appeal ${decision.toLowerCase()}d!`, 'success');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to process appeal', 'error');
    }
  };

  // Broadcast announcement
  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.broadcastNotification(broadcastTitle, broadcastMessage);
      showToast('System announcement broadcasted to all players!', 'success');
      setBroadcastTitle('');
      setBroadcastMessage('');
    } catch (err: any) {
      showToast(err.message || 'Broadcast failed', 'error');
    }
  };

  // Save Scoring Config
  const handleSaveScoring = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scoringConfig) return;
    try {
      await api.updateScoringConfig(scoringConfig);
      showToast('Scoring configuration updated!', 'success');
      await fetchAllData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update scoring', 'error');
    }
  };

  // Export Audit CSV
  const exportAuditCSV = () => {
    if (auditLogs.length === 0) return;
    const headers = ['Timestamp', 'Actor', 'Role', 'Action', 'Target', 'Details'];
    const rows = auditLogs.map((l) => [
      l.timestamp,
      `"${l.actorName}"`,
      l.actorRole,
      l.action,
      `"${l.targetName || ''}"`,
      `"${l.details.replace(/"/g, '""')}"`,
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GAMES_MORO_BD_AuditLogs_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Audit logs CSV exported!', 'success');
  };

  const pendingReports = reports.filter((r) => r.status === 'PENDING_APPROVAL');
  const officersList = usersList.filter((u) => u.role === 'officer');

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 pb-12">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-red-950/40 via-[#10121c] to-[#10121c] border border-red-600/40 rounded-2xl p-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-950 border border-red-500/60 flex items-center justify-center text-red-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-heading text-base font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>{role === 'owner' ? 'Owner / Super Admin Console' : 'Admin Operations Console'}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-red-900/60 text-red-200">
                {role.toUpperCase()}
              </span>
            </h2>
            <span className="text-xs text-slate-400">
              GAMES MORO BD Esports Administration
            </span>
          </div>
        </div>

        <button
          onClick={handleAutoSchedule}
          className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold uppercase transition-all shadow-md glow-red"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Auto Daily Schedule</span>
        </button>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-4 gap-2 text-center">
        <div className="bg-[#10121c] p-2.5 rounded-xl border border-white/5">
          <span className="text-[10px] text-slate-400">Total Players</span>
          <p className="font-heading text-base font-extrabold text-white mt-0.5">
            {usersList.length}
          </p>
        </div>
        <div className="bg-[#10121c] p-2.5 rounded-xl border border-white/5">
          <span className="text-[10px] text-slate-400">Tournaments</span>
          <p className="font-heading text-base font-extrabold text-blue-400 mt-0.5">
            {tournaments.length}
          </p>
        </div>
        <div className="bg-[#10121c] p-2.5 rounded-xl border border-white/5">
          <span className="text-[10px] text-slate-400">Approval Queue</span>
          <p
            className={`font-heading text-base font-extrabold mt-0.5 ${
              pendingReports.length > 0 ? 'text-amber-400 animate-pulse' : 'text-slate-400'
            }`}
          >
            {pendingReports.length}
          </p>
        </div>
        <div className="bg-[#10121c] p-2.5 rounded-xl border border-white/5">
          <span className="text-[10px] text-slate-400">Blacklisted</span>
          <p className="font-heading text-base font-extrabold text-red-400 mt-0.5">
            {blacklist.length}
          </p>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'queue', label: `Result Queue (${pendingReports.length})`, icon: FileCheck },
          { id: 'matches', label: 'Match Manager', icon: Trophy },
          { id: 'users', label: 'Users & Officers', icon: Users },
          { id: 'blacklist', label: `Blacklist (${blacklist.length})`, icon: Ban },
          { id: 'scoring', label: 'Scoring Rules', icon: Settings },
          { id: 'wallet', label: `MFS Wallet (${walletTransactions.length})`, icon: Wallet },
          { id: 'broadcast', label: 'Announcements', icon: Send },
          { id: 'audit', label: 'Audit Logs', icon: History },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                isActive
                  ? 'bg-red-600 text-white shadow-sm'
                  : 'bg-[#10121c] text-slate-400 hover:text-slate-200 border border-white/5'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: RESULT APPROVAL QUEUE */}
      {activeTab === 'queue' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Pending Officer Match Reports
            </h3>
            <span className="text-[11px] text-slate-400">
              Officer cannot approve own report
            </span>
          </div>

          {pendingReports.length === 0 ? (
            <div className="bg-[#10121c] border border-white/10 rounded-2xl p-8 text-center text-xs text-slate-400">
              <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              Approval queue is empty! All submitted matches have been verified.
            </div>
          ) : (
            pendingReports.map((report) => {
              const isSubmittedByMe = report.submittedByOfficerId === user?.id;
              const canApprove = role === 'owner' || !isSubmittedByMe;

              return (
                <div
                  key={report.id}
                  className="bg-[#10121c] border border-amber-500/40 rounded-2xl p-4 flex flex-col gap-3 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700/40">
                        {report.mode.replace('_', ' ')}
                      </span>
                      <h4 className="font-heading font-extrabold text-sm text-white mt-1">
                        {report.tournamentTitle}
                      </h4>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block font-mono">
                        Submitted by:
                      </span>
                      <span className="text-xs font-semibold text-blue-400">
                        {report.submittedByOfficerName}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <strong>Officer Notes:</strong> {report.officerNotes}
                  </p>

                  {/* Results preview summary */}
                  <div className="flex flex-col gap-1 text-xs">
                    <span className="text-[11px] font-bold text-slate-300">
                      Disbursement Preview ({report.results.length} Players):
                    </span>
                    <div className="space-y-1">
                      {report.results.slice(0, 5).map((r, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between bg-black/30 px-2.5 py-1.5 rounded-lg text-[11px]"
                        >
                          <span className="font-mono text-slate-400">
                            #{r.placement} {r.inGameName} ({r.kills} Kills)
                          </span>
                          <span className="font-heading font-bold text-amber-400 tabular-nums">
                            +{r.calculatedPoints} TP
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Evidence inspect button */}
                  {report.evidenceScreenshotUrl && (
                    <button
                      onClick={() => setPreviewEvidenceUrl(report.evidenceScreenshotUrl)}
                      className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 font-semibold"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Inspect Scoreboard Evidence Screenshot</span>
                    </button>
                  )}

                  {/* Conflict of Interest Warning if submitted by current officer */}
                  {!canApprove && (
                    <div className="bg-red-950/60 p-2.5 rounded-xl border border-red-700/50 text-[11px] text-red-300 flex items-center gap-2">
                      <Lock className="w-4 h-4 text-red-400 shrink-0" />
                      <span>
                        Conflict of Interest Rule: You submitted this report as officer. Another Admin or the Super Owner must review and approve.
                      </span>
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => setRejectReportId(report.id)}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-red-400 text-xs font-bold rounded-xl transition-colors"
                    >
                      Reject with Reason
                    </button>

                    <button
                      disabled={!canApprove}
                      onClick={() => handleApproveReport(report.id)}
                      className={`px-4 py-1.5 rounded-xl font-heading font-bold text-xs uppercase tracking-wider flex items-center gap-1 transition-all ${
                        canApprove
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                          : 'bg-zinc-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve & Disburse Points</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: MATCH MANAGER */}
      {activeTab === 'matches' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Live & Scheduled Tournaments ({tournaments.length})
            </h3>
            <button
              onClick={() => setIsCreatingMatch(true)}
              className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold uppercase transition-all shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Match</span>
            </button>
          </div>

          <div className="flex flex-col gap-2.5">
            {tournaments.map((t) => (
              <div
                key={t.id}
                className="bg-[#10121c] border border-white/10 rounded-2xl p-3.5 flex flex-col gap-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-zinc-800 text-slate-300">
                    {t.mode.replace('_', ' ')} · {t.status}
                  </span>
                  <span className="text-xs font-mono text-slate-300">
                    {new Date(t.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h4 className="font-heading font-bold text-sm text-white">
                      {t.title}
                    </h4>
                    <span className="text-[11px] text-slate-400">
                      Slots: {t.slotsFilled}/{t.maxPlayers} · Officer: {t.assignedOfficerName || 'None'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Delay match 10m button */}
                    <button
                      onClick={async () => {
                        await api.updateTournament(t.id, { delayMinutes: 10 });
                        showToast('Delayed match start by 10 minutes', 'info');
                        await fetchAllData();
                      }}
                      className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-slate-300 rounded-lg text-[10px] font-semibold"
                    >
                      +10m Delay
                    </button>

                    {/* Change status toggle */}
                    <button
                      onClick={async () => {
                        const nextStatus =
                          t.status === 'REGISTRATION_OPEN' ? 'REGISTRATION_CLOSED' : 'REGISTRATION_OPEN';
                        await api.updateTournament(t.id, { status: nextStatus });
                        showToast(`Status changed to ${nextStatus}`, 'info');
                        await fetchAllData();
                      }}
                      className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-amber-400 rounded-lg text-[10px] font-semibold"
                    >
                      {t.status === 'REGISTRATION_OPEN' ? 'Close Reg' : 'Open Reg'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: USERS & OFFICERS MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Platform Accounts & Officer Assignments
            </h3>
            <span className="text-xs text-slate-400">
              {officersList.length} Active Officers
            </span>
          </div>

          <div className="flex flex-col gap-2">
            {usersList.map((u) => {
              const isOwner = u.role === 'owner';

              return (
                <div
                  key={u.id}
                  className="bg-[#10121c] border border-white/10 rounded-2xl p-3 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <img
                      src={u.avatar}
                      alt={u.username}
                      className="w-9 h-9 rounded-full object-cover border border-white/10 shrink-0"
                    />
                    <div className="flex flex-col overflow-hidden">
                      <div className="flex items-center gap-1.5">
                        <span className="font-heading font-bold text-xs text-white truncate">
                          {u.inGameName}
                        </span>
                        <span
                          className={`text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded ${
                            u.role === 'owner'
                              ? 'bg-red-600 text-white'
                              : u.role === 'admin'
                              ? 'bg-amber-600 text-white'
                              : u.role === 'officer'
                              ? 'bg-blue-600 text-white'
                              : 'bg-zinc-800 text-slate-400'
                          }`}
                        >
                          {u.role}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono truncate">
                        {u.tournamentUid} · {u.inGameUid}
                      </span>
                    </div>
                  </div>

                  {/* Role Change Controls */}
                  {!isOwner ? (
                    <div className="flex items-center gap-1 shrink-0">
                      <select
                        value={u.role}
                        onChange={(e) => handleChangeRole(u.id, e.target.value as UserRole)}
                        className="bg-black/60 border border-white/20 rounded-lg px-2 py-1 text-[11px] text-white focus:outline-none"
                      >
                        <option value="player">Player</option>
                        <option value="officer">Officer</option>
                        <option value="admin">Admin</option>
                      </select>
                    </div>
                  ) : (
                    <span className="text-[10px] font-bold text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-800/40 shrink-0">
                      Owner Protected
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: BLACKLIST & APPEALS */}
      {activeTab === 'blacklist' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Tournament Blacklist & Appeals ({blacklist.length})
            </h3>
            <button
              onClick={() => setIsBanning(true)}
              className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold uppercase transition-all shadow-md"
            >
              <Ban className="w-3.5 h-3.5" />
              <span>Add Ban</span>
            </button>
          </div>

          <div className="bg-black/40 border border-white/5 rounded-2xl p-3 text-[11px] text-slate-400">
            <strong>Notice:</strong> This is a GAMES MORO BD tournament-level blacklist only. It does not affect a player's official Free Fire account.
          </div>

          {blacklist.length === 0 ? (
            <div className="bg-[#10121c] border border-white/10 rounded-2xl p-8 text-center text-xs text-slate-400">
              Blacklist is currently empty.
            </div>
          ) : (
            blacklist.map((entry) => (
              <div
                key={entry.id}
                className="bg-[#10121c] border border-red-600/40 rounded-2xl p-3.5 flex flex-col gap-2.5 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-heading font-extrabold text-sm text-red-400">
                      {entry.username} (UID: {entry.inGameUid})
                    </h4>
                    <span className="text-[10px] text-slate-400">
                      Banned by {entry.bannedByAdminName} on{' '}
                      {new Date(entry.bannedAt).toLocaleDateString()} · Duration: {entry.duration}
                    </span>
                  </div>

                  <button
                    onClick={() => handleUnban(entry.inGameUid)}
                    className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-emerald-400 rounded-lg text-xs font-bold transition-colors"
                  >
                    Lift Ban
                  </button>
                </div>

                <p className="text-xs text-slate-300 bg-black/40 p-2 rounded-xl">
                  <strong>Reason:</strong> {entry.reason}
                </p>

                {/* Appeal section if submitted */}
                {entry.appealStatus === 'PENDING' && (
                  <div className="bg-amber-950/40 border border-amber-600/40 rounded-xl p-2.5 flex flex-col gap-2">
                    <span className="text-[11px] font-bold text-amber-300">
                      Pending Ban Appeal:
                    </span>
                    <p className="text-xs text-slate-300 italic">
                      "{entry.appealReason}"
                    </p>
                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        onClick={() =>
                          handleReviewAppeal(
                            entry.inGameUid,
                            'REJECT',
                            'Evidence of violation confirmed by admin panel.'
                          )
                        }
                        className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-red-400 rounded-lg text-xs font-bold"
                      >
                        Reject Appeal
                      </button>
                      <button
                        onClick={() =>
                          handleReviewAppeal(
                            entry.inGameUid,
                            'APPROVE',
                            'Handcam review accepted. Warning issued.'
                          )
                        }
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold"
                      >
                        Approve & Unban
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 5: SCORING SETTINGS */}
      {activeTab === 'scoring' && scoringConfig && (
        <form
          onSubmit={handleSaveScoring}
          className="bg-[#10121c] border border-white/10 rounded-2xl p-4 flex flex-col gap-4 shadow-md"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Tournament Scoring Engine Configuration
            </h3>
            <span className="text-[10px] text-amber-400 font-mono">
              Points only (TP)
            </span>
          </div>

          {/* BR Rank Config */}
          <div className="space-y-2">
            <span className="font-heading font-bold text-xs text-red-400 uppercase tracking-wide">
              BR Rank (Solo 48) - Top 5 Placements
            </span>
            <div className="grid grid-cols-5 gap-2 text-xs">
              <div>
                <label className="text-[10px] text-slate-400">1st (Booyah)</label>
                <input
                  type="number"
                  value={scoringConfig.brRank.rank1}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: { ...scoringConfig.brRank, rank1: parseInt(e.target.value) || 0 },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-amber-400 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">2nd Place</label>
                <input
                  type="number"
                  value={scoringConfig.brRank.rank2}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: { ...scoringConfig.brRank, rank2: parseInt(e.target.value) || 0 },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-slate-200 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">3rd Place</label>
                <input
                  type="number"
                  value={scoringConfig.brRank.rank3}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: { ...scoringConfig.brRank, rank3: parseInt(e.target.value) || 0 },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-slate-200 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">4th Place</label>
                <input
                  type="number"
                  value={scoringConfig.brRank.rank4}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: { ...scoringConfig.brRank, rank4: parseInt(e.target.value) || 0 },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-slate-200 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">5th Place</label>
                <input
                  type="number"
                  value={scoringConfig.brRank.rank5}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: { ...scoringConfig.brRank, rank5: parseInt(e.target.value) || 0 },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1 text-slate-200 font-mono font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-slate-400 text-[10px] block mb-1">
                  Kill Point Value (TP per kill)
                </label>
                <input
                  type="number"
                  value={scoringConfig.brRank.killPoints}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: {
                        ...scoringConfig.brRank,
                        killPoints: parseInt(e.target.value) || 0,
                      },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-400 text-[10px] block mb-1">
                  Max Rewarded Kills Cap (e.g. 5)
                </label>
                <input
                  type="number"
                  value={scoringConfig.brRank.maxRewardedKills}
                  onChange={(e) =>
                    setScoringConfig({
                      ...scoringConfig,
                      brRank: {
                        ...scoringConfig.brRank,
                        maxRewardedKills: parseInt(e.target.value) || 0,
                      },
                    })
                  }
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-2 py-1.5 text-white font-mono"
                />
              </div>
            </div>
            <p className="text-[10px] text-slate-400 italic">
              Verification: 1st place with 6 kills receives {scoringConfig.brRank.rank1} + min(6, {scoringConfig.brRank.maxRewardedKills}) × {scoringConfig.brRank.killPoints} = {scoringConfig.brRank.rank1 + Math.min(6, scoringConfig.brRank.maxRewardedKills) * scoringConfig.brRank.killPoints} TP.
            </p>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase tracking-wider transition-all shadow-md"
          >
            Save Scoring Parameters
          </button>
        </form>
      )}

      {/* TAB 6: BROADCAST ANNOUNCEMENT */}
      {activeTab === 'broadcast' && (
        <form
          onSubmit={handleBroadcast}
          className="bg-[#10121c] border border-white/10 rounded-2xl p-4 flex flex-col gap-3 shadow-md"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Send className="w-4 h-4 text-red-500" />
              Broadcast In-App Announcement
            </h3>
            <span className="text-[10px] text-slate-400">Pushed to all active players</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Announcement Title</label>
              <input
                type="text"
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="e.g. Daily Schedule Live: CS Rank Clash Tonight"
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Announcement Message Body</label>
              <textarea
                rows={3}
                value={broadcastMessage}
                onChange={(e) => setBroadcastMessage(e.target.value)}
                placeholder="Details, timing, special rules, or tournament notices..."
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md"
          >
            Send Push Notification Broadcast
          </button>
        </form>
      )}

      {/* TAB 6: MFS WALLET & TRANSACTIONS LEDGER */}
      {activeTab === 'wallet' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Wallet className="w-4 h-4 text-emerald-400" />
                MFS Transactions & Player Ledger
              </h3>
              <p className="text-[11px] text-slate-400">
                bKash, Nagad, Rocket deposits, withdrawals, and match entry fee debits
              </p>
            </div>
            <button
              onClick={fetchAllData}
              className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-slate-300 text-[11px] font-semibold rounded-lg transition-colors"
            >
              Refresh Ledger
            </button>
          </div>

          {/* Quick Summary Cards */}
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-[#10121c] p-2.5 rounded-xl border border-emerald-500/20">
              <span className="text-[10px] text-slate-400 font-medium">Total Deposits</span>
              <p className="font-heading text-base font-extrabold text-emerald-400 mt-0.5">
                ৳
                {walletTransactions
                  .filter((t) => t.type === 'DEPOSIT')
                  .reduce((sum, t) => sum + t.amount, 0)}
              </p>
            </div>
            <div className="bg-[#10121c] p-2.5 rounded-xl border border-red-500/20">
              <span className="text-[10px] text-slate-400 font-medium">Match Entry Fees</span>
              <p className="font-heading text-base font-extrabold text-red-400 mt-0.5">
                ৳
                {walletTransactions
                  .filter((t) => t.type === 'QUALIFY_FEE')
                  .reduce((sum, t) => sum + t.amount, 0)}
              </p>
            </div>
            <div className="bg-[#10121c] p-2.5 rounded-xl border border-amber-500/20">
              <span className="text-[10px] text-slate-400 font-medium">Total Withdrawals</span>
              <p className="font-heading text-base font-extrabold text-amber-400 mt-0.5">
                ৳
                {walletTransactions
                  .filter((t) => t.type === 'WITHDRAW')
                  .reduce((sum, t) => sum + t.amount, 0)}
              </p>
            </div>
          </div>

          {/* Transactions List */}
          {walletTransactions.length === 0 ? (
            <div className="bg-[#10121c] border border-white/10 rounded-2xl p-8 text-center text-xs text-slate-400">
              <Wallet className="w-8 h-8 text-slate-500 mx-auto mb-2" />
              No financial transactions recorded yet.
            </div>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {walletTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className="bg-[#10121c] border border-white/5 rounded-xl p-3 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                        tx.type === 'DEPOSIT'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/40'
                          : tx.type === 'WITHDRAW'
                          ? 'bg-amber-950 text-amber-400 border border-amber-700/40'
                          : 'bg-red-950 text-red-400 border border-red-700/40'
                      }`}
                    >
                      {tx.type === 'DEPOSIT' ? 'DEP' : tx.type === 'WITHDRAW' ? 'WTH' : 'PAY'}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-bold text-white">
                          {tx.userName || 'Player'}
                        </span>
                        {tx.method && (
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                              tx.method === 'bKash'
                                ? 'bg-[#E2136E]/20 text-[#E2136E]'
                                : tx.method === 'Nagad'
                                ? 'bg-[#F7941D]/20 text-[#F7941D]'
                                : 'bg-[#8C3494]/20 text-[#8C3494]'
                            }`}
                          >
                            {tx.method}
                          </span>
                        )}
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                            tx.status === 'COMPLETED'
                              ? 'bg-emerald-950 text-emerald-400'
                              : 'bg-amber-950 text-amber-400'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                        {tx.trxId && (
                          <span className="font-mono text-slate-300">TrxID: {tx.trxId}</span>
                        )}
                        {tx.receiverPhone && (
                          <span className="font-mono text-slate-300">To: {tx.receiverPhone}</span>
                        )}
                        {tx.inGameUid && (
                          <span className="font-mono text-slate-300">FF UID: {tx.inGameUid}</span>
                        )}
                        <span>{new Date(tx.createdAt || tx.timestamp).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`font-mono text-sm font-extrabold ${
                        tx.type === 'DEPOSIT'
                          ? 'text-emerald-400'
                          : tx.type === 'WITHDRAW'
                          ? 'text-amber-400'
                          : 'text-red-400'
                      }`}
                    >
                      {tx.type === 'DEPOSIT' ? '+' : '-'}৳{tx.amount}
                    </span>
                    <p className="text-[10px] text-slate-400 capitalize">
                      {tx.type.toLowerCase().replace('_', ' ')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 7: AUDIT LOGS */}
      {activeTab === 'audit' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Chronological Admin Audit Trail ({auditLogs.length})
            </h3>
            <button
              onClick={exportAuditCSV}
              className="flex items-center gap-1 px-3 py-1.5 bg-[#10121c] hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-slate-300"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Export CSV</span>
            </button>
          </div>

          <div className="space-y-1.5 max-h-[500px] overflow-y-auto">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="bg-[#10121c] border border-white/5 rounded-xl p-2.5 flex flex-col gap-1 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-red-400 font-mono text-[10px]">
                    {log.action}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-tight">
                  {log.details}
                </p>
                <span className="text-[9px] text-slate-400">
                  By {log.actorName} ({log.actorRole})
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Create Match Modal */}
      {isCreatingMatch && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e1019] border border-white/10 rounded-2xl p-5 w-full max-w-md flex flex-col gap-3 text-xs">
            <h3 className="font-heading text-base font-bold text-white">
              Create New Tournament Match
            </h3>

            <form onSubmit={handleCreateTournament} className="flex flex-col gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Match Title</label>
                <input
                  type="text"
                  placeholder="e.g. BR RANK: Evening Grand Master Showdown"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Tournament Mode</label>
                <select
                  value={newMode}
                  onChange={(e) => setNewMode(e.target.value as any)}
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                >
                  <option value="BR_RANK">BR RANK (Solo 48 Players)</option>
                  <option value="CS_RANK">CS RANK (4 vs 4 Squad)</option>
                  <option value="LONE_WOLF">LONE WOLF (1 vs 1 Duel)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Assign Officer (Overlap Protected)</label>
                <select
                  value={newOfficerId}
                  onChange={(e) => setNewOfficerId(e.target.value)}
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                >
                  <option value="">Select Officer...</option>
                  {officersList.map((off) => (
                    <option key={off.id} value={off.id}>
                      {off.username} ({off.tournamentUid})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Scheduled Start Time</label>
                <input
                  type="datetime-local"
                  value={newStartTime}
                  onChange={(e) => setNewStartTime(e.target.value)}
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreatingMatch(false)}
                  className="px-3 py-1.5 bg-zinc-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl"
                >
                  Create & Launch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject Report Modal */}
      {rejectReportId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e1019] border border-white/10 rounded-2xl p-5 w-full max-w-md flex flex-col gap-3 text-xs">
            <h3 className="font-heading text-base font-bold text-red-400">
              Reject Match Report
            </h3>
            <p className="text-slate-400">
              State the reason for rejection. The assigned officer will be notified to correct and resubmit.
            </p>
            <form onSubmit={handleRejectReport} className="flex flex-col gap-3">
              <textarea
                rows={3}
                value={rejectionNotes}
                onChange={(e) => setRejectionNotes(e.target.value)}
                placeholder="e.g. Scoreboard kills for player 2 do not match screenshot log..."
                required
                className="w-full bg-black/60 border border-white/20 rounded-xl p-2.5 text-white"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRejectReportId(null)}
                  className="px-3 py-1.5 bg-zinc-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Blacklist Modal */}
      {isBanning && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0e1019] border border-red-600/50 rounded-2xl p-5 w-full max-w-md flex flex-col gap-3 text-xs">
            <h3 className="font-heading text-base font-bold text-red-400">
              Add Tournament Blacklist Record
            </h3>
            <form onSubmit={handleBlacklistSubmit} className="flex flex-col gap-2.5">
              <div>
                <label className="text-slate-400 block mb-1">In-Game Free Fire UID</label>
                <input
                  type="text"
                  placeholder="e.g. 901283746"
                  value={banUid}
                  onChange={(e) => setBanUid(e.target.value)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Player Username / IGN</label>
                <input
                  type="text"
                  placeholder="e.g. HACKER_X"
                  value={banIgn}
                  onChange={(e) => setBanIgn(e.target.value)}
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Reason for Ban</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Confirmed teaming in BR Rank Solo match..."
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl p-2 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Duration</label>
                <select
                  value={banDuration}
                  onChange={(e) => setBanDuration(e.target.value as any)}
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                >
                  <option value="24h">24 Hours</option>
                  <option value="7d">7 Days</option>
                  <option value="30d">30 Days</option>
                  <option value="permanent">Permanent Tournament Blacklist</option>
                </select>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsBanning(false)}
                  className="px-3 py-1.5 bg-zinc-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl"
                >
                  Enforce Ban
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Evidence Viewer Lightbox */}
      {previewEvidenceUrl && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4">
          <div className="relative max-w-2xl w-full bg-[#10121c] rounded-2xl overflow-hidden border border-white/20">
            <div className="p-3 border-b border-white/10 flex items-center justify-between">
              <span className="font-heading font-bold text-xs uppercase text-white">
                Officer Scoreboard Evidence Audit
              </span>
              <button
                onClick={() => setPreviewEvidenceUrl(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1"
              >
                Close ✕
              </button>
            </div>
            <img
              src={previewEvidenceUrl}
              alt="Match Proof"
              className="w-full max-h-[70vh] object-contain bg-black"
            />
          </div>
        </div>
      )}
    </div>
  );
};
