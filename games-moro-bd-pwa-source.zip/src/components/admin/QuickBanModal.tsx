import React, { useState } from 'react';
import {
  X,
  Ban,
  AlertTriangle,
  ShieldAlert,
  Flame,
  CheckCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';

interface QuickBanModalProps {
  onClose: () => void;
  onSuccess: () => void;
  defaultUid?: string;
  defaultName?: string;
}

export const QuickBanModal: React.FC<QuickBanModalProps> = ({
  onClose,
  onSuccess,
  defaultUid,
  defaultName,
}) => {
  const { showToast } = useAuth();
  const [inGameUid, setInGameUid] = useState<string>(defaultUid || '');
  const [username, setUsername] = useState<string>(defaultName || '');
  const [cheatType, setCheatType] = useState<string>('প্যানেল হ্যাক / অটো হেডশট (Panel Hack)');
  const [reason, setReason] = useState<string>(
    'ফ্রি ফায়ার অনৈতিক প্যানেল হ্যাক ও স্ক্রিপ্ট ব্যবহারের প্রমাণ পাওয়ায় স্থায়ী ব্যান করা হলো।'
  );
  const [evidenceUrl, setEvidenceUrl] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleQuickBan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inGameUid.trim()) {
      showToast('ফ্রি ফায়ার ইউআইডি (UID) দেওয়া আবশ্যক!', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.quickBanPlayer({
        inGameUid: inGameUid.trim(),
        username: username.trim() || undefined,
        cheatType,
        reason: `${cheatType}: ${reason}`,
        evidenceUrl: evidenceUrl.trim() || undefined,
      });

      showToast(`ইউআইডি ${inGameUid} সফলভাবে স্থায়ী ব্যান করা হয়েছে!`, 'success');
      onSuccess();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'ব্যান করতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0e1019] border border-red-600/70 w-full max-w-md rounded-2xl flex flex-col overflow-hidden shadow-2xl animate-in zoom-in-95">
        {/* Header */}
        <div className="px-5 py-4 border-b border-red-900/40 bg-red-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-red-600 text-white shadow-md shadow-red-950/80 animate-pulse">
              <Ban className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading text-sm font-extrabold text-white uppercase tracking-wider">
                ডাইরেক্ট ব্যান কার্যকর করুন (Instant Ban)
              </h3>
              <p className="text-[10px] text-red-300">
                হ্যাকার ও প্যানেল ইউজারদের তৎক্ষণাৎ টুর্নামেন্ট থেকে স্থায়ী বহিষ্কার
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleQuickBan} className="p-5 flex flex-col gap-3 text-xs">
          <div className="bg-red-950/30 border border-red-600/30 rounded-xl p-2.5 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-red-200 leading-snug">
              এই অপশনটির মাধ্যমে প্লেয়ারের ফ্রি ফায়ার আইডি ব্ল্যাকলিস্টে যুক্ত হবে, সকল টুর্নামেন্ট স্লট বাতিল হবে এবং সে আর কখনোই ম্যাচে রেজিস্ট্রেশন করতে পারবে না।
            </p>
          </div>

          <div>
            <label className="text-slate-300 font-bold block mb-1">
              ফ্রি ফায়ার ইউআইডি (UID)*
            </label>
            <input
              type="text"
              value={inGameUid}
              onChange={(e) => setInGameUid(e.target.value)}
              placeholder="e.g. 789102456"
              required
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono font-bold text-xs focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="text-slate-300 font-bold block mb-1">
              খেলোয়াড়ের নাম বা ইউজারনেম
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. HACKER_OP"
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="text-slate-300 font-bold block mb-1">
              অনৈতিক কাজের ধরণ:
            </label>
            <select
              value={cheatType}
              onChange={(e) => setCheatType(e.target.value)}
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-amber-300 text-xs focus:outline-none focus:border-red-500 font-bold"
            >
              <option value="প্যানেল হ্যাক / অটো হেডশট (Panel Hack)">প্যানেল হ্যাক / অটো হেডশট (Panel Hack)</option>
              <option value="এইমবট ও নো-রিকোয়েল স্ক্রিপ্ট (Aimbot)">এইমবট ও নো-রিকোয়েল স্ক্রিপ্ট (Aimbot)</option>
              <option value="ওয়াল হ্যাক ও লোকেশন ট্র্যাকার (ESP)">ওয়াল হ্যাক ও লোকেশন ট্র্যাকার (ESP)</option>
              <option value="স্পিড হ্যাক ও ফাস্ট মুভমেন্ট">স্পিড হ্যাক ও ফাস্ট মুভমেন্ট</option>
              <option value="সোলো ম্যাচে অবৈধ টিম-আপ">সোলো ম্যাচে অবৈধ টিম-আপ (Illegal Teaming)</option>
              <option value="থার্ড-পার্টি কনফিগ ও গ্লিচ ফাইল">থার্ড-পার্টি কনফিগ ও গ্লিচ ফাইল</option>
            </select>
          </div>

          <div>
            <label className="text-slate-300 font-bold block mb-1">
              ব্যানের বিস্তারিত কারণ:*
            </label>
            <textarea
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              className="w-full bg-black/60 border border-white/15 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="text-slate-300 font-bold block mb-1">
              প্রমাণপত্র স্ক্রিনশট / ভিডিও লিংক (ঐচ্ছিক):
            </label>
            <input
              type="text"
              value={evidenceUrl}
              onChange={(e) => setEvidenceUrl(e.target.value)}
              placeholder="https://... ইমেজ বা ড্রাইভ লিঙ্ক"
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 bg-zinc-800 text-slate-300 font-bold text-xs rounded-xl"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-heading font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-red-950/80 active:scale-98 transition-all flex items-center gap-1.5"
            >
              <Ban className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'ব্যান হচ্ছে...' : 'ডাইরেক্ট ব্যান কার্যকর করুন'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
