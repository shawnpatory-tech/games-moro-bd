import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Trophy,
  Clock,
  Key,
  FileCheck,
  Upload,
  AlertCircle,
  CheckCircle,
  Plus,
  Trash2,
  Eye,
  Lock,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament, MatchReportResult } from '../../types/index.ts';
import { api } from '../../services/api.ts';
import { AbnormalPlayReportModal } from './AbnormalPlayReportModal.tsx';

export const OfficerDashboard: React.FC = () => {
  const { user, showToast } = useAuth();
  const [assignedMatches, setAssignedMatches] = useState<Tournament[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<Tournament | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Room credentials quick edit state
  const [editRoomId, setEditRoomId] = useState<string>('');
  const [editRoomPass, setEditRoomPass] = useState<string>('');
  const [editRevealed, setEditRevealed] = useState<boolean>(false);
  const [isUpdatingRoom, setIsUpdatingRoom] = useState<boolean>(false);

  // Match report modal state
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [resultsList, setResultsList] = useState<MatchReportResult[]>([]);
  const [officerNotes, setOfficerNotes] = useState<string>('');
  const [screenshotUrl, setScreenshotUrl] = useState<string>(
    '/src/assets/images/tournament_hero_banner_1793899507217.jpg'
  );
  const [isSubmittingReport, setIsSubmittingReport] = useState<boolean>(false);

  // Abnormal play / Anti-cheat incident modal state
  const [isAbnormalModalOpen, setIsAbnormalModalOpen] = useState<boolean>(false);
  const [targetMatchForReport, setTargetMatchForReport] = useState<Tournament | null>(null);

  const fetchDutyMatches = async () => {
    try {
      setIsLoading(true);
      const res = await api.getTournaments();
      // Filter matches assigned to this officer, or all active if admin/owner
      const duty = res.tournaments.filter(
        (t) =>
          t.assignedOfficerId === user?.id ||
          user?.role === 'admin' ||
          user?.role === 'owner'
      );
      setAssignedMatches(duty);
      if (duty.length > 0 && !selectedMatch) {
        setSelectedMatch(duty[0]);
      }
    } catch (err) {
      console.error('Error fetching duty matches', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDutyMatches();
  }, [user]);

  useEffect(() => {
    if (selectedMatch) {
      setEditRoomId(selectedMatch.roomDetails.roomId || '');
      setEditRoomPass(selectedMatch.roomDetails.roomPassword || '');
      setEditRevealed(selectedMatch.roomDetails.isRevealed);
    }
  }, [selectedMatch]);

  const handleUpdateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatch) return;

    try {
      setIsUpdatingRoom(true);
      await api.updateTournament(selectedMatch.id, {
        roomId: editRoomId,
        roomPassword: editRoomPass,
        isRevealed: editRevealed,
        status: editRevealed ? 'ROOM_PREPARING' : selectedMatch.status,
      });
      showToast('Room credentials updated and broadcast to players!', 'success');
      await fetchDutyMatches();
    } catch (err: any) {
      showToast(err.message || 'Failed to update room details', 'error');
    } finally {
      setIsUpdatingRoom(false);
    }
  };

  const openReportModal = (match: Tournament) => {
    setSelectedMatch(match);
    // Initialize results from registered players or standard template
    const initialResults: MatchReportResult[] =
      match.registeredPlayers.length > 0
        ? match.registeredPlayers.map((p, idx) => ({
            userId: p.userId,
            username: p.username,
            inGameName: p.inGameName,
            inGameUid: p.inGameUid,
            placement: idx + 1,
            kills: idx === 0 ? 6 : Math.max(0, 5 - idx),
            calculatedPoints: idx === 0 ? 125 : 0, // Will be computed
            teamSlot: p.teamSlot,
          }))
        : [
            {
              userId: 'user-player-1',
              username: 'MoroRaptor_BD',
              inGameName: 'RAPTOR彡BD99',
              inGameUid: '192837465',
              placement: 1,
              kills: 6,
              calculatedPoints: 125,
            },
            {
              userId: 'user-player-2',
              username: 'ViperSniper_BD',
              inGameName: 'VIPER亗HEAD',
              inGameUid: '349102834',
              placement: 2,
              kills: 3,
              calculatedPoints: 85,
            },
            {
              userId: 'user-bot-3',
              username: 'ApexGhost_BD',
              inGameName: 'GHOST亗SHADOW',
              inGameUid: '449102941',
              placement: 3,
              kills: 4,
              calculatedPoints: 70,
            },
            {
              userId: 'user-bot-4',
              username: 'DeltaForce_7',
              inGameName: 'DELTA彡KILLER',
              inGameUid: '559102942',
              placement: 4,
              kills: 2,
              calculatedPoints: 40,
            },
            {
              userId: 'user-bot-5',
              username: 'ChronoShield',
              inGameName: 'CHRONO亗DEF',
              inGameUid: '669102943',
              placement: 5,
              kills: 1,
              calculatedPoints: 25,
            },
            {
              userId: 'user-bot-6',
              username: 'SavageEliminator',
              inGameName: 'SAVAGE彡BOY',
              inGameUid: '779102944',
              placement: 6,
              kills: 5,
              calculatedPoints: 0,
            },
          ];

    setResultsList(initialResults);
    setOfficerNotes(
      `Match supervised by ${user?.username}. Validated endgame screen. No teaming detected.`
    );
    setIsReportModalOpen(true);
  };

  const calculatePreviewPoints = (placement: number, kills: number, mode: string) => {
    if (mode === 'BR_RANK') {
      let posPts = 0;
      if (placement === 1) posPts = 100;
      else if (placement === 2) posPts = 70;
      else if (placement === 3) posPts = 50;
      else if (placement === 4) posPts = 30;
      else if (placement === 5) posPts = 20;
      else return 0; // Outside Top 5 receives 0 points!

      const rewardedKills = Math.min(kills || 0, 5); // 5-kill cap
      return posPts + rewardedKills * 5;
    } else if (mode === 'CS_RANK') {
      const isWin = placement === 1;
      return (isWin ? 40 : 10) + (kills || 0) * 2;
    } else {
      return placement === 1 ? 35 : 5;
    }
  };

  const updateResultRow = (index: number, field: 'placement' | 'kills', value: number) => {
    setResultsList((prev) => {
      const updated = [...prev];
      const row = { ...updated[index], [field]: value };
      row.calculatedPoints = calculatePreviewPoints(
        row.placement,
        row.kills,
        selectedMatch?.mode || 'BR_RANK'
      );
      updated[index] = row;
      return updated;
    });
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatch) return;

    try {
      setIsSubmittingReport(true);
      await api.submitReport({
        tournamentId: selectedMatch.id,
        results: resultsList,
        evidenceScreenshotUrl: screenshotUrl,
        officerNotes,
      });

      showToast(
        'Match report submitted! Awaiting Super Admin review & point disburse.',
        'success'
      );
      setIsReportModalOpen(false);
      await fetchDutyMatches();
    } catch (err: any) {
      showToast(err.message || 'Failed to submit report', 'error');
    } finally {
      setIsSubmittingReport(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 pb-12">
      {/* Officer Header */}
      <div className="bg-gradient-to-r from-blue-950/40 via-[#10121c] to-[#10121c] border border-blue-600/30 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-500/50 flex items-center justify-center text-blue-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-heading text-base font-extrabold text-white uppercase tracking-wider">
              Officer Duty Console
            </h2>
            <span className="text-xs text-blue-300 font-mono">
              Badge: {user?.username} ({user?.tournamentUid})
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setTargetMatchForReport(selectedMatch || assignedMatches[0] || null);
              setIsAbnormalModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-md glow-red transition-all active:scale-95"
            title="কোনো খেলোয়াড় সন্দেহভাজন হ্যাক বা প্যানেল ব্যবহার করলে প্রমাণ সহ রিপোর্ট করুন"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">অ্যান্টি-চিট রিপোর্ট</span>
            <span className="sm:hidden">রিপোর্ট</span>
          </button>

          <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1.5 rounded-lg bg-blue-950 text-blue-300 border border-blue-700/50">
            On Duty
          </span>
        </div>
      </div>

      {/* Officer Guidelines */}
      <div className="bg-black/40 border border-white/5 rounded-2xl p-3 text-[11px] text-slate-400 space-y-1">
        <span className="font-bold text-slate-200 block">Duty Protocols:</span>
        <p>• Room ID and Password must be created 15 minutes before scheduled match start.</p>
        <p>• Toggle "Reveal to Players" when room is open and waiting in lobby.</p>
        <p>• Record endgame scoreboard screenshot as evidence for kill auditing.</p>
        <p className="text-amber-400 font-medium">
          • Per regulations: Officers cannot ban players or approve their own submitted reports.
        </p>
      </div>

      {/* Assigned Matches List */}
      <div className="flex flex-col gap-2.5">
        <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
          Assigned Tournament Matches ({assignedMatches.length})
        </h3>

        {isLoading ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Loading assigned matches...
          </div>
        ) : assignedMatches.length === 0 ? (
          <div className="bg-[#10121c] border border-white/10 rounded-2xl p-6 text-center text-xs text-slate-400">
            No active matches currently assigned to your badge.
          </div>
        ) : (
          <div className="flex flex-col gap-2.5">
            {assignedMatches.map((t) => {
              const isSelected = selectedMatch?.id === t.id;

              return (
                <div
                  key={t.id}
                  onClick={() => setSelectedMatch(t)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-950/30 border-blue-500/60 shadow-md'
                      : 'bg-[#10121c] border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-zinc-800 text-slate-300">
                      {t.mode.replace('_', ' ')}
                    </span>
                    <span className="text-xs font-mono text-slate-300 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-blue-400" />
                      {new Date(t.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <h4 className="font-heading font-bold text-sm text-white mt-1">
                    {t.title}
                  </h4>

                  <div className="flex items-center justify-between text-xs text-slate-400 mt-2 pt-2 border-t border-white/5">
                    <span>
                      Players: {t.slotsFilled}/{t.maxPlayers}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setTargetMatchForReport(t);
                          setIsAbnormalModalOpen(true);
                        }}
                        className="px-2 py-1 bg-red-950/70 hover:bg-red-900 border border-red-700/50 text-red-300 font-bold text-[10px] rounded-lg transition-colors flex items-center gap-1"
                        title="ফ্রি ফায়ার অনৈতিক/প্যানেল খেলা রিপোর্ট করুন"
                      >
                        <ShieldAlert className="w-3 h-3 text-red-400" />
                        <span>অস্বাভাবিক খেলা</span>
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openReportModal(t);
                        }}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1"
                      >
                        <FileCheck className="w-3 h-3" />
                        <span>স্কোরকার্ড</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Selected Match Room Manager */}
      {selectedMatch && (
        <form
          onSubmit={handleUpdateRoom}
          className="bg-[#10121c] border border-white/10 rounded-2xl p-4 flex flex-col gap-3 shadow-md"
        >
          <div className="flex items-center justify-between">
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider flex items-center gap-1.5">
              <Key className="w-4 h-4 text-amber-400" />
              Manage Match Room Credentials
            </h4>
            <span className="text-[10px] font-mono text-slate-400">
              {selectedMatch.title}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">Room ID (Custom)</label>
              <input
                type="text"
                value={editRoomId}
                onChange={(e) => setEditRoomId(e.target.value)}
                placeholder="e.g. 9812044"
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Room Password</label>
              <input
                type="text"
                value={editRoomPass}
                onChange={(e) => setEditRoomPass(e.target.value)}
                placeholder="e.g. GMBD#BERMUDA"
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-amber-300 font-mono text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Reveal Toggle */}
          <div className="flex items-center justify-between bg-black/40 p-3 rounded-xl border border-white/5">
            <div>
              <span className="text-xs font-bold text-white block">
                Unlock Room for Registered Players
              </span>
              <span className="text-[10px] text-slate-400">
                When enabled, verified players can see credentials in My Matches.
              </span>
            </div>

            <button
              type="button"
              onClick={() => setEditRevealed(!editRevealed)}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                editRevealed ? 'bg-emerald-600' : 'bg-zinc-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  editRevealed ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <button
            type="submit"
            disabled={isUpdatingRoom}
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md"
          >
            {isUpdatingRoom ? 'Updating Room...' : 'Save & Publish Room Info'}
          </button>
        </form>
      )}

      {/* Abnormal Play / Anti-Cheat Incident Modal */}
      {isAbnormalModalOpen && (
        <AbnormalPlayReportModal
          onClose={() => setIsAbnormalModalOpen(false)}
          matches={assignedMatches}
          defaultMatch={targetMatchForReport}
          onSuccess={() => fetchDutyMatches()}
        />
      )}

      {/* Match Report Modal */}
      {isReportModalOpen && selectedMatch && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-[#0e1019] border border-white/10 w-full max-w-xl rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
            <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
              <div>
                <h3 className="font-heading text-base font-bold text-white">
                  Official Match Report Submission
                </h3>
                <span className="text-xs text-slate-400">
                  {selectedMatch.title}
                </span>
              </div>
              <button
                onClick={() => setIsReportModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitReport} className="flex-1 overflow-y-auto p-5 flex flex-col gap-4 text-xs">
              {/* Scoring Rules Quick Note */}
              <div className="bg-red-950/30 border border-red-700/40 rounded-xl p-3 text-[11px] text-red-200">
                <strong>BR Scoring Reminder:</strong> Top 5 only qualify (1st: 100, 2nd: 70, 3rd: 50, 4th: 30, 5th: 20). 5 TP per kill, max 5 rewarded kills per eligible Top 5 player (e.g., 1st place with 6 kills receives 125 TP). Placements 6+ receive 0 points.
              </div>

              {/* Placements & Kills Entry Table */}
              <div className="flex flex-col gap-2">
                <span className="font-heading font-bold text-white text-xs uppercase tracking-wider">
                  Player Placements & Kill Log
                </span>

                <div className="space-y-2">
                  {resultsList.map((row, idx) => (
                    <div
                      key={idx}
                      className="bg-black/50 p-3 rounded-xl border border-white/10 grid grid-cols-12 items-center gap-2"
                    >
                      <div className="col-span-5 flex flex-col">
                        <span className="font-heading font-bold text-white truncate">
                          {row.inGameName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          UID: {row.inGameUid}
                        </span>
                      </div>

                      {/* Rank Position */}
                      <div className="col-span-3 flex flex-col">
                        <label className="text-[9px] text-slate-400">Placement</label>
                        <input
                          type="number"
                          min={1}
                          max={48}
                          value={row.placement}
                          onChange={(e) =>
                            updateResultRow(idx, 'placement', parseInt(e.target.value) || 1)
                          }
                          className="bg-zinc-900 border border-white/20 rounded-lg px-2 py-1 text-white font-mono text-center font-bold"
                        />
                      </div>

                      {/* Kills */}
                      <div className="col-span-2 flex flex-col">
                        <label className="text-[9px] text-slate-400">Kills</label>
                        <input
                          type="number"
                          min={0}
                          max={30}
                          value={row.kills}
                          onChange={(e) =>
                            updateResultRow(idx, 'kills', parseInt(e.target.value) || 0)
                          }
                          className="bg-zinc-900 border border-white/20 rounded-lg px-2 py-1 text-red-400 font-mono text-center font-bold"
                        />
                      </div>

                      {/* Calculated Preview Points */}
                      <div className="col-span-2 text-right">
                        <span className="text-[9px] text-slate-400 block">Calc TP</span>
                        <span className="font-heading font-extrabold text-sm text-amber-400 tabular-nums">
                          {row.calculatedPoints}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Evidence Screenshot URL / Upload */}
              <div className="flex flex-col gap-1.5">
                <label className="font-heading font-bold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Upload className="w-3.5 h-3.5 text-blue-400" />
                  Scoreboard Screenshot Evidence (URL / Preview)
                </label>
                <input
                  type="text"
                  value={screenshotUrl}
                  onChange={(e) => setScreenshotUrl(e.target.value)}
                  placeholder="https://... or /src/assets/images/..."
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
                />
                {screenshotUrl && (
                  <div className="mt-1 h-28 rounded-xl overflow-hidden border border-white/10 bg-black">
                    <img
                      src={screenshotUrl}
                      alt="Match Evidence"
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                )}
              </div>

              {/* Officer Notes */}
              <div className="flex flex-col gap-1">
                <label className="font-heading font-bold text-white text-xs uppercase tracking-wider">
                  Officer Remarks & Audit Notes
                </label>
                <textarea
                  rows={2}
                  value={officerNotes}
                  onChange={(e) => setOfficerNotes(e.target.value)}
                  placeholder="Explain any player disconnects, room timing, or observations..."
                  className="w-full bg-black/60 border border-white/15 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Notice */}
              <div className="text-[10px] text-slate-400 italic">
                * Note: Submitting this report sends it to the Result Approval Queue. The Super Admin or another Admin must verify and disburse points.
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsReportModalOpen(false)}
                  className="px-4 py-2 bg-zinc-800 text-slate-300 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReport}
                  className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase tracking-wider rounded-xl shadow-md"
                >
                  {isSubmittingReport ? 'Submitting...' : 'Submit Match Report'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
