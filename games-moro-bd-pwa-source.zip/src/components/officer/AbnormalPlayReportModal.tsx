import React, { useState } from 'react';
import {
  X,
  ShieldAlert,
  Upload,
  AlertTriangle,
  Video,
  Clock,
  Send,
  Eye,
  CheckCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface AbnormalPlayReportModalProps {
  onClose: () => void;
  matches: Tournament[];
  defaultMatch?: Tournament | null;
  onSuccess: () => void;
}

export const AbnormalPlayReportModal: React.FC<AbnormalPlayReportModalProps> = ({
  onClose,
  matches,
  defaultMatch,
  onSuccess,
}) => {
  const { user, showToast } = useAuth();

  const [selectedTournamentId, setSelectedTournamentId] = useState<string>(
    defaultMatch?.id || (matches.length > 0 ? matches[0].id : '')
  );

  const currentMatch =
    matches.find((m) => m.id === selectedTournamentId) || defaultMatch || matches[0];

  const [accusedPlayerName, setAccusedPlayerName] = useState<string>('');
  const [accusedPlayerUid, setAccusedPlayerUid] = useState<string>('');
  const [cheatType, setCheatType] = useState<string>('PANEL_HACK');
  const [incidentRoundOrTime, setIncidentRoundOrTime] = useState<string>('Round 2 / Final Zone');
  const [evidenceUrl, setEvidenceUrl] = useState<string>(
    'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600'
  );
  const [videoProofUrl, setVideoProofUrl] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleSelectParticipant = (name: string, uid: string) => {
    setAccusedPlayerName(name);
    setAccusedPlayerUid(uid);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accusedPlayerUid.trim()) {
      showToast('খেলোয়াড়ের ফ্রি ফায়ার ইউআইডি (UID) দেওয়া বাধ্যতামূলক!', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      await api.submitAbnormalReport({
        tournamentId: selectedTournamentId,
        accusedPlayerName: accusedPlayerName.trim() || 'Suspect Player',
        accusedPlayerUid: accusedPlayerUid.trim(),
        cheatType,
        incidentRoundOrTime,
        evidenceUrl,
        videoProofUrl,
        description,
      });

      showToast('অস্বাভাবিক গেমপ্লে রিপোর্ট ও প্রমাণ সফলভাবে অ্যাডমিন প্যানেলে জমা দেওয়া হয়েছে!', 'success');
      onSuccess();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'রিপোর্ট জমা দিতে ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-red-600/40 w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-red-950/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-red-600 text-white shadow-md shadow-red-950/60">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <span>অস্বাভাবিক গেমপ্লে / হ্যাকিং রিপোর্ট</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-red-900/60 text-red-200">
                  ANTI-CHEAT
                </span>
              </h3>
              <p className="text-[10px] text-red-200/80">
                অফিসার ডিউটি: স্ক্রিনশট বা ভিডিও প্রমাণসহ অ্যাডমিনের কাছে জমা দিন
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 flex flex-col gap-3.5 text-xs">
          {/* Match Selector */}
          <div>
            <label className="text-slate-300 font-bold block mb-1">
              ১. কোন ম্যাচে এই ঘটনা ঘটেছে?
            </label>
            <select
              value={selectedTournamentId}
              onChange={(e) => setSelectedTournamentId(e.target.value)}
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500 font-semibold"
            >
              {matches.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.title} ({m.mode})
                </option>
              ))}
            </select>
          </div>

          {/* Quick Participant Picker if players exist */}
          {currentMatch && currentMatch.registeredPlayers.length > 0 && (
            <div className="bg-black/40 border border-white/10 rounded-2xl p-3 flex flex-col gap-1.5">
              <span className="text-[11px] font-bold text-slate-400">
                এই ম্যাচের প্লেয়ার তালিকা থেকে দ্রুত সিলেক্ট করুন:
              </span>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pt-1">
                {currentMatch.registeredPlayers.map((p) => (
                  <button
                    key={p.id || p.inGameUid}
                    type="button"
                    onClick={() => handleSelectParticipant(p.inGameName, p.inGameUid)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                      accusedPlayerUid === p.inGameUid
                        ? 'bg-red-600 text-white shadow-sm'
                        : 'bg-zinc-800 text-slate-300 hover:bg-zinc-700'
                    }`}
                  >
                    {p.inGameName} ({p.inGameUid})
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Accused Player Inputs */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-slate-300 font-bold block mb-1">
                ফ্রি ফায়ার ইউআইডি (UID)*
              </label>
              <input
                type="text"
                value={accusedPlayerUid}
                onChange={(e) => setAccusedPlayerUid(e.target.value)}
                placeholder="e.g. 789102456"
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">
                খেলোয়াড়ের নাম (IGN)
              </label>
              <input
                type="text"
                value={accusedPlayerName}
                onChange={(e) => setAccusedPlayerName(e.target.value)}
                placeholder="e.g. BD_HACKER_99"
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          {/* Violation / Cheat Classification */}
          <div>
            <label className="text-slate-300 font-bold block mb-1">
              ২. অনৈতিক খেলার ধরণ / হ্যাকের প্রকারভেদ:*
            </label>
            <select
              value={cheatType}
              onChange={(e) => setCheatType(e.target.value)}
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-amber-300 text-xs focus:outline-none focus:border-red-500 font-bold"
            >
              <option value="PANEL_HACK">প্যানেল হ্যাক / ১০০% অটো হেডশট (Panel User)</option>
              <option value="AIMBOT_HEADSHOT">অটো এইমবট / নো-রিকোয়েল স্ক্রিপ্ট (Aimbot)</option>
              <option value="WALLHACK_ESP">ওয়াল হ্যাক / লোকেশন ট্রেস (ESP / Wallhack)</option>
              <option value="SPEED_HACK">স্পিড হ্যাক / অস্বাভাবিক গতি (Speed Hack)</option>
              <option value="ILLEGAL_TEAMING">সোলো টুর্নামেন্টে অবৈধ টিম-আপ (Teaming)</option>
              <option value="CONFIG_MOD">অ্যান্টেনা / কনফিগ ফাইল মড (Config / Mod)</option>
            </select>
          </div>

          {/* Round / Timestamp */}
          <div>
            <label className="text-slate-300 font-bold block mb-1">
              ঘটনার সময় বা রাউন্ড নম্বর:
            </label>
            <div className="relative">
              <Clock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={incidentRoundOrTime}
                onChange={(e) => setIncidentRoundOrTime(e.target.value)}
                placeholder="e.g. Round 3 (02:14) অথবা শেষ জোনে"
                className="w-full bg-black/60 border border-white/15 rounded-xl pl-8 pr-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          {/* Evidence Screenshot URL */}
          <div>
            <label className="text-slate-300 font-bold block mb-1 flex items-center justify-between">
              <span>স্ক্রিনশট প্রমাণ (URL / ইমেজ প্রিভিউ):</span>
              <span className="text-[10px] text-slate-400">প্রমাণ লিঙ্ক</span>
            </label>
            <div className="relative">
              <Upload className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={evidenceUrl}
                onChange={(e) => setEvidenceUrl(e.target.value)}
                placeholder="https://... ইমেজ লিঙ্ক"
                className="w-full bg-black/60 border border-white/15 rounded-xl pl-8 pr-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
              />
            </div>
            {evidenceUrl && (
              <div className="mt-1 h-24 rounded-xl overflow-hidden border border-white/10 bg-black">
                <img
                  src={evidenceUrl}
                  alt="Incident Proof"
                  className="w-full h-full object-cover object-center"
                />
              </div>
            )}
          </div>

          {/* Video Proof Link */}
          <div>
            <label className="text-slate-300 font-bold block mb-1 flex items-center gap-1.5">
              <Video className="w-3.5 h-3.5 text-red-400" />
              <span>ভিডিও প্রমাণপত্র লিঙ্ক (YouTube / Google Drive / Streamable):</span>
            </label>
            <input
              type="text"
              value={videoProofUrl}
              onChange={(e) => setVideoProofUrl(e.target.value)}
              placeholder="e.g. https://youtu.be/... অথবা গুগল ড্রাইভ ভিডিও লিঙ্ক"
              className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Detailed Observations */}
          <div>
            <label className="text-slate-300 font-bold block mb-1">
              অফিসার পর্যবেক্ষণ ও বিস্তারিত বিবরণ:*
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="প্লেয়ার কিভাবে অনৈতিক খেলা খেলেছে তা পরিষ্কারভাবে লিখুন (যেমন: জাম্প শটেই সব কিল, দেওয়ালের ওপাশ থেকে সরাসরি নক করা ইত্যাদি)..."
              required
              className="w-full bg-black/60 border border-white/15 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-zinc-800 text-slate-300 font-bold text-xs rounded-xl"
            >
              বাতিল
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-red-950/60 active:scale-98 transition-all flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'জমা হচ্ছে...' : 'প্রমাণসহ রিপোর্ট জমা দিন'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
