import React, { useState, useEffect } from 'react';
import {
  X,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  History,
  Copy,
  Check,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Send,
  HelpCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { WalletTransaction } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface WalletModalProps {
  onClose: () => void;
  initialTab?: 'deposit' | 'withdraw' | 'history';
}

export const WalletModal: React.FC<WalletModalProps> = ({
  onClose,
  initialTab = 'deposit',
}) => {
  const { user, walletBalance, deposit, withdraw, showToast } = useAuth();
  const [tab, setTab] = useState<'deposit' | 'withdraw' | 'history'>(initialTab);

  // Deposit state
  const [depositMethod, setDepositMethod] = useState<'bKash' | 'Nagad' | 'Rocket'>('bKash');
  const [depositAmount, setDepositAmount] = useState<number>(100);
  const [senderPhone, setSenderPhone] = useState<string>('017');
  const [trxId, setTrxId] = useState<string>('');
  const [isDepositing, setIsDepositing] = useState<boolean>(false);
  const [copiedNumber, setCopiedNumber] = useState<boolean>(false);

  // Withdraw state
  const [withdrawMethod, setWithdrawMethod] = useState<'bKash' | 'Nagad' | 'Rocket'>('bKash');
  const [withdrawAmount, setWithdrawAmount] = useState<number>(100);
  const [receiverPhone, setReceiverPhone] = useState<string>(user?.phone || '017');
  const [isWithdrawing, setIsWithdrawing] = useState<boolean>(false);

  // History state
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(false);

  const adminNumber = '01711000001';

  const copyAdminNumber = () => {
    navigator.clipboard.writeText(adminNumber);
    setCopiedNumber(true);
    showToast('অফিসিয়াল পেমেন্ট নম্বর কপি করা হয়েছে!', 'success');
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const fetchHistory = async () => {
    try {
      setIsLoadingHistory(true);
      const res = await api.getWalletData();
      setTransactions(res.transactions);
    } catch (err) {
      console.error('Error fetching transactions', err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (tab === 'history') {
      fetchHistory();
    }
  }, [tab]);

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trxId.trim()) {
      showToast('অনুগ্রহ করে সঠিক TrxID লিখুন', 'error');
      return;
    }
    try {
      setIsDepositing(true);
      await deposit(depositMethod, depositAmount, senderPhone, trxId);
      setTrxId('');
      setTab('history');
    } catch (err) {
    } finally {
      setIsDepositing(false);
    }
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (withdrawAmount > walletBalance) {
      showToast('অপর্যাপ্ত ব্যালেন্স! আপনার একাউন্টে পর্যাপ্ত টাকা নেই।', 'error');
      return;
    }
    try {
      setIsWithdrawing(true);
      await withdraw(withdrawMethod, withdrawAmount, receiverPhone);
      setTab('history');
    } catch (err) {
    } finally {
      setIsWithdrawing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header with Balance */}
        <div className="p-4 border-b border-white/10 bg-gradient-to-r from-red-950/40 via-[#121420] to-[#121420] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-red-950 border border-red-600/40 flex items-center justify-center text-red-400">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                আপনার ওয়ালেট ব্যালেন্স
              </span>
              <h3 className="font-heading font-extrabold text-xl text-white flex items-center gap-1 leading-tight">
                ৳{walletBalance} <span className="text-xs text-amber-400 font-sans font-bold">BDT</span>
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-3 border-b border-white/10 text-xs font-bold bg-black/40">
          <button
            onClick={() => setTab('deposit')}
            className={`py-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 ${
              tab === 'deposit'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>ডিপোজিট</span>
          </button>
          <button
            onClick={() => setTab('withdraw')}
            className={`py-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 ${
              tab === 'withdraw'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ArrowUpCircle className="w-3.5 h-3.5" />
            <span>উইথড্র</span>
          </button>
          <button
            onClick={() => setTab('history')}
            className={`py-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 ${
              tab === 'history'
                ? 'border-red-500 text-red-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>হিস্ট্রি</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 text-xs text-slate-300">
          {/* TAB 1: DEPOSIT */}
          {tab === 'deposit' && (
            <form onSubmit={handleDepositSubmit} className="flex flex-col gap-3.5">
              {/* Step 1: Select Method */}
              <div>
                <label className="text-[11px] font-bold text-white block mb-1.5">
                  ১. পেমেন্ট মেথড নির্বাচন করুন
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'bKash', label: 'বিকাশ (bKash)', color: 'bg-pink-950/60 border-pink-600/50 text-pink-300' },
                    { id: 'Nagad', label: 'নগদ (Nagad)', color: 'bg-orange-950/60 border-orange-600/50 text-orange-300' },
                    { id: 'Rocket', label: 'রকেট (Rocket)', color: 'bg-purple-950/60 border-purple-600/50 text-purple-300' },
                  ].map((m) => {
                    const isSelected = depositMethod === m.id;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setDepositMethod(m.id as any)}
                        className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all ${
                          isSelected
                            ? 'bg-red-600 text-white border-red-500 shadow-md scale-[1.02]'
                            : 'bg-black/50 text-slate-400 border-white/10 hover:border-white/20'
                        }`}
                      >
                        {m.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Send Money Details Box */}
              <div className="bg-black/60 border border-amber-600/40 rounded-2xl p-3.5 flex flex-col gap-2">
                <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5" />
                  ২. সেন্ড মানি (Send Money) নির্দেশনা
                </span>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  আপনার {depositMethod} অ্যাপ থেকে নিচের নম্বরে <strong>Send Money</strong> করুন:
                </p>

                <div className="flex items-center justify-between bg-zinc-900/90 p-2.5 rounded-xl border border-white/10">
                  <span className="font-mono text-sm font-extrabold text-white tracking-wider">
                    {adminNumber} <span className="text-[10px] text-amber-400 font-sans font-normal">(Personal)</span>
                  </span>
                  <button
                    type="button"
                    onClick={copyAdminNumber}
                    className="flex items-center gap-1 px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-[10px] font-bold transition-all"
                  >
                    {copiedNumber ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedNumber ? 'কপি হয়েছে' : 'নম্বর কপি'}</span>
                  </button>
                </div>
              </div>

              {/* Step 3: Quick Amount Selection */}
              <div>
                <label className="text-[11px] font-bold text-white block mb-1">
                  ৩. ডিপোজিটের পরিমাণ (টাকা)
                </label>
                <div className="grid grid-cols-5 gap-1.5 mb-2">
                  {[50, 100, 200, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setDepositAmount(amt)}
                      className={`py-1.5 rounded-lg font-mono font-bold text-xs border transition-all ${
                        depositAmount === amt
                          ? 'bg-emerald-600 text-white border-emerald-500'
                          : 'bg-black/40 text-slate-300 border-white/10'
                      }`}
                    >
                      ৳{amt}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min={20}
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(Number(e.target.value) || 0)}
                  required
                  placeholder="অন্য পরিমাণ লিখুন"
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Step 4: Sender Phone & TrxID */}
              <div className="space-y-2">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">
                    প্রেরকের মোবাইল নম্বর (Sender Phone)
                  </label>
                  <input
                    type="tel"
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    required
                    placeholder="যেই নম্বর থেকে টাকা পাঠিয়েছেন"
                    className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">
                    ট্রানজেকশন আইডি (TrxID)
                  </label>
                  <input
                    type="text"
                    value={trxId}
                    onChange={(e) => setTrxId(e.target.value)}
                    required
                    placeholder="যেমন: BKH9281045"
                    className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-amber-300 font-mono font-bold text-xs uppercase focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isDepositing}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-heading font-extrabold text-sm uppercase tracking-wider rounded-xl transition-all shadow-md active:scale-98 mt-1"
              >
                {isDepositing ? 'যাচাই করা হচ্ছে...' : `৳${depositAmount} ডিপোজিট সাবমিট করুন`}
              </button>
            </form>
          )}

          {/* TAB 2: WITHDRAW */}
          {tab === 'withdraw' && (
            <form onSubmit={handleWithdrawSubmit} className="flex flex-col gap-3.5">
              <div className="bg-amber-950/30 border border-amber-600/30 rounded-xl p-3 text-[11px] text-amber-300">
                <strong>উইথড্র নিয়মাবলী:</strong> সর্বনিম্ন উইথড্র ৫০ টাকা। রিকোয়েস্ট করার ৫-১৫ মিনিটের মধ্যে আপনার বিকাশ বা নগদ নম্বরে টাকা ক্যাশ-আউট হয়ে যাবে।
              </div>

              <div>
                <label className="text-[11px] font-bold text-white block mb-1.5">
                  পেমেন্ট মাধ্যম
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWithdrawMethod('bKash')}
                    className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all ${
                      withdrawMethod === 'bKash'
                        ? 'bg-red-600 text-white border-red-500'
                        : 'bg-black/50 text-slate-400 border-white/10'
                    }`}
                  >
                    বিকাশ (bKash)
                  </button>
                  <button
                    type="button"
                    onClick={() => setWithdrawMethod('Nagad')}
                    className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all ${
                      withdrawMethod === 'Nagad'
                        ? 'bg-amber-600 text-white border-amber-500'
                        : 'bg-black/50 text-slate-400 border-white/10'
                    }`}
                  >
                    নগদ (Nagad)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-white block mb-1">
                  উইথড্র পরিমাণ (টাকা)
                </label>
                <input
                  type="number"
                  min={50}
                  max={walletBalance}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(Number(e.target.value) || 0)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-amber-500"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  সর্বোচ্চ তুলতে পারবেন: ৳{walletBalance}
                </span>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">
                  আপনার {withdrawMethod} মোবাইল নম্বর
                </label>
                <input
                  type="tel"
                  value={receiverPhone}
                  onChange={(e) => setReceiverPhone(e.target.value)}
                  required
                  placeholder="01XXXXXXXXX"
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <button
                type="submit"
                disabled={isWithdrawing || walletBalance < 50}
                className={`w-full py-2.5 font-heading font-extrabold text-sm uppercase tracking-wider rounded-xl transition-all shadow-md ${
                  walletBalance >= 50
                    ? 'bg-amber-600 hover:bg-amber-500 text-white'
                    : 'bg-zinc-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isWithdrawing ? 'প্রসেসিং হচ্ছে...' : `৳${withdrawAmount} উইথড্র কনফার্ম করুন`}
              </button>
            </form>
          )}

          {/* TAB 3: TRANSACTION HISTORY */}
          {tab === 'history' && (
            <div className="flex flex-col gap-2.5">
              <span className="text-[11px] font-bold text-white">
                আপনার সাম্প্রতিক লেনদেন তালিকা
              </span>

              {isLoadingHistory ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  হিস্ট্রি লোড হচ্ছে...
                </div>
              ) : transactions.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs">
                  কোনো লেনদেন রেকর্ড পাওয়া যায়নি।
                </div>
              ) : (
                <div className="space-y-2">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="bg-black/50 p-3 rounded-2xl border border-white/5 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                            tx.type === 'DEPOSIT'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/40'
                              : tx.type === 'WITHDRAW'
                              ? 'bg-amber-950 text-amber-400 border border-amber-700/40'
                              : 'bg-red-950 text-red-400 border border-red-700/40'
                          }`}
                        >
                          {tx.type === 'DEPOSIT' ? '+' : '-'}
                        </div>

                        <div className="flex flex-col">
                          <span className="font-heading font-bold text-xs text-white">
                            {tx.type === 'DEPOSIT'
                              ? `ডিপোজিট (${tx.method || 'MFS'})`
                              : tx.type === 'WITHDRAW'
                              ? `উইথড্র (${tx.method || 'MFS'})`
                              : 'ম্যাচ এন্ট্রি ফি'}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {tx.trxId ? `Trx: ${tx.trxId}` : tx.matchTitle || 'কোয়ালিফিকেশন ফি'}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span
                          className={`font-heading font-extrabold text-sm tabular-nums ${
                            tx.type === 'DEPOSIT' ? 'text-emerald-400' : 'text-slate-200'
                          }`}
                        >
                          {tx.type === 'DEPOSIT' ? `+৳${tx.amount}` : `-৳${tx.amount}`}
                        </span>
                        <span className="text-[9px] font-bold block text-emerald-400">
                          {tx.status === 'APPROVED' ? 'সম্পন্ন' : tx.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
