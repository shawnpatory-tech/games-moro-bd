import React from 'react';
import { X, Bell, CheckCircle, Trophy, Key, AlertTriangle, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { AppNotification } from '../../types/index.ts';

interface NotificationsDrawerProps {
  onClose: () => void;
  onSelectTournamentId?: (id: string) => void;
}

export const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({
  onClose,
  onSelectTournamentId,
}) => {
  const { notifications, markNotificationsAsRead } = useAuth();

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'ROOM_ALERT':
        return <Key className="w-4 h-4 text-amber-400" />;
      case 'RESULT_READY':
        return <Trophy className="w-4 h-4 text-emerald-400" />;
      case 'REGISTRATION':
        return <CheckCircle className="w-4 h-4 text-blue-400" />;
      case 'SYSTEM_ALERT':
        return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default:
        return <Bell className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
      <div className="bg-[#0e1019] border-l border-white/10 w-full max-w-sm h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-red-500" />
            <h3 className="font-heading font-extrabold text-sm text-white uppercase tracking-wider">
              Notification Center
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => markNotificationsAsRead()}
              className="text-[10px] text-red-400 hover:text-red-300 font-semibold"
            >
              Mark Read
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-2.5">
          {notifications.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              No notifications yet.
            </div>
          ) : (
            notifications.map((notif) => (
              <div
                key={notif.id}
                onClick={() => {
                  if (notif.tournamentId && onSelectTournamentId) {
                    onSelectTournamentId(notif.tournamentId);
                    onClose();
                  }
                }}
                className={`p-3 rounded-2xl border transition-all text-xs ${
                  notif.isRead
                    ? 'bg-[#10121c] border-white/5 opacity-80'
                    : 'bg-red-950/30 border-red-600/40 shadow-sm'
                } ${notif.tournamentId ? 'cursor-pointer hover:border-red-500' : ''}`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-black/60 shrink-0 mt-0.5">
                    {getIcon(notif.type)}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-heading font-bold text-xs text-white">
                        {notif.title}
                      </h4>
                      <span className="text-[9px] font-mono text-slate-500">
                        {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                      {notif.message}
                    </p>

                    {notif.tournamentId && (
                      <span className="inline-block mt-2 text-[10px] text-red-400 font-bold hover:underline">
                        Tap to View Match Room →
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
