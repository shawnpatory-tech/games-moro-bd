import React from 'react';
import { X, Trophy, ShieldAlert, Swords, Users, Crosshair, CheckCircle2 } from 'lucide-react';

interface RulesModalProps {
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <h3 className="font-heading font-extrabold text-base text-white uppercase tracking-wider">
              অফিসিয়াল টুর্নামেন্ট নিয়মাবলী (Tournament Rules)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Rules Content in Bengali */}
        <div className="flex-1 overflow-y-auto p-5 text-xs text-slate-300 space-y-4">
          {/* Section 1: BR RANK 48 SOLO */}
          <div className="bg-[#10121c] border border-red-600/30 rounded-2xl p-4">
            <h4 className="font-heading font-extrabold text-sm text-red-400 uppercase tracking-wide flex items-center gap-1.5 mb-2">
              <Crosshair className="w-4 h-4" />
              ১. বিআর র‍্যাংক (BR RANK): সোলো ৪৮ প্লেয়ার নিয়মাবলী
            </h4>
            <div className="space-y-1.5 text-[11px] leading-relaxed">
              <p>• <strong>এক জীবন নিয়ম (One Life Only):</strong> কাস্টম রুমে কোনো রিভাইভ পয়েন্ট, রিভাইভ ভেন্ডিং মেশিন বা রিভাইভ কার্ড থাকবে না। একবার এলিমিনেট হলেই আপনার ম্যাচ সরাসরি শেষ।</p>
              <p>• <strong>টপ ৫ কোয়ালিফিকেশন:</strong> শুধুমাত্র ১ম থেকে ৫ম স্থান অর্জনকারী প্লেয়াররা অফিশিয়াল টুর্নামেন্ট পয়েন্ট (TP) ও পুরস্কারের জন্য বিবেচিত হবে। ৬ষ্ঠ থেকে ৪৮তম স্থান অর্জনকারীরা ০ পয়েন্ট পাবে।</p>
              <p>• <strong>পজিশন পয়েন্ট বণ্টন তালিকা:</strong></p>
              <div className="grid grid-cols-5 gap-1 text-center font-mono font-bold text-xs py-1">
                <div className="bg-amber-950/70 p-1.5 rounded border border-amber-600/40 text-amber-300">১ম: ১০০</div>
                <div className="bg-zinc-900 p-1.5 rounded text-slate-200">২য়: ৭০</div>
                <div className="bg-zinc-900 p-1.5 rounded text-slate-200">৩য়: ৫০</div>
                <div className="bg-zinc-900 p-1.5 rounded text-slate-200">৪র্থ: ৩০</div>
                <div className="bg-zinc-900 p-1.5 rounded text-slate-200">৫ম: ২০</div>
              </div>
              <p>• <strong>কিল পয়েন্ট ও ৫-কিল ক্যাপ (Kill Cap):</strong> প্রতিটি কনফার্ম কিলের জন্য ৫ পয়েন্ট দেওয়া হবে। তবে টপ ৫ প্লেয়ারদের জন্য সর্বোচ্চ ৫টি কিল পর্যন্ত পয়েন্ট গণনা করা হবে (সর্বোচ্চ কিল বোনাস ২৫ পয়েন্ট)।</p>
              <p className="bg-black/50 p-2 rounded-lg text-amber-300 font-medium">
                <em>উদাহরণ: ১ম স্থান (Booyah) অর্জনকারী যদি ৬টি কিল করে, তবে সে পাবে ১০০ (পজিশন) + (৫ × ৫) = ১২৫ পয়েন্ট।</em>
              </p>
              <p>• <strong>পয়েন্ট সংক্রান্ত তথ্য:</strong> টুর্নামেন্ট পয়েন্ট (TP) দিয়ে আপনি লিডারবোর্ডে র‍্যাংক অর্জন করবেন। এটি ক্যাশ ব্যালেন্স নয়।</p>
            </div>
          </div>

          {/* Section 2: CS RANK 4v4 */}
          <div className="bg-[#10121c] border border-amber-600/30 rounded-2xl p-4">
            <h4 className="font-heading font-extrabold text-sm text-amber-400 uppercase tracking-wide flex items-center gap-1.5 mb-2">
              <Users className="w-4 h-4" />
              ২. সিএস র‍্যাংক (CS RANK): স্কোয়াড ৪ বনাম ৪ নিয়মাবলী
            </h4>
            <div className="space-y-1.5 text-[11px] leading-relaxed">
              <p>• <strong>ফরম্যাট:</strong> মোট ৮ জন প্লেয়ার দুটি স্কোয়াডে বিভক্ত হবে (স্কোয়াড আলফা বনাম স্কোয়াড ব্র্যাভো)।</p>
              <p>• <strong>ম্যাচ সেটিং:</strong> স্ট্যান্ডার্ড কম্পিটিটিভ ৭ রাউন্ড জয়ী স্কোয়াড বিজয়ী হবে। ক্যারেক্টার একটিভ স্কিল চালু থাকবে, তবে গানের স্কিন অ্যাট্রিবিউট সম্পূর্ণ বন্ধ থাকবে।</p>
              <p>• <strong>গ্রেনেড সীমাবদ্ধতা:</strong> প্রতি রাউন্ডে একজন প্লেয়ার সর্বোচ্চ ১টি হ্যান্ড গ্রেনেড ব্যবহার করতে পারবে।</p>
              <p>• <strong>পয়েন্ট:</strong> বিজয়ী স্কোয়াডের প্রতিটি প্লেয়ার ৪০ টিপি পাবে এবং ম্যাচের এমভিপি (MVP) অতিরিক্ত ১৫ টিপি বোনাস পাবে।</p>
            </div>
          </div>

          {/* Section 3: LONE WOLF 1v1 */}
          <div className="bg-[#10121c] border border-blue-600/30 rounded-2xl p-4">
            <h4 className="font-heading font-extrabold text-sm text-blue-400 uppercase tracking-wide flex items-center gap-1.5 mb-2">
              <Swords className="w-4 h-4" />
              ৩. লোন উলফ (LONE WOLF): ১ বনাম ১ ডুয়েল নিয়মাবলী
            </h4>
            <div className="space-y-1.5 text-[11px] leading-relaxed">
              <p>• <strong>ফরম্যাট:</strong> আয়রন কেজ (Iron Cage) ম্যাপে ১ বনাম ১ পিউর স্কিল শোডাউন।</p>
              <p>• <strong>বিজয়ী নির্ধারণ:</strong> প্রথম ৫টি রাউন্ড জয়লাভকারী প্লেয়ার বিজয়ী ঘোষিত হবে (৩৫ টিপি)। রানার-আপ পাবে ৫ টিপি।</p>
              <p>• <strong>অস্ত্র নির্বাচন:</strong> উভয় প্লেয়ার পর্যায়ক্রমে একই অস্ত্র পছন্দ করার সুযোগ পাবে।</p>
            </div>
          </div>

          {/* Section 4: Anti-Cheat & Blacklist */}
          <div className="bg-[#10121c] border border-red-900/40 rounded-2xl p-4">
            <h4 className="font-heading font-extrabold text-sm text-red-400 uppercase tracking-wide flex items-center gap-1.5 mb-2">
              <ShieldAlert className="w-4 h-4" />
              ৪. আচরণবিধি, অ্যান্টি-টিমিং ও ব্ল্যাকলিস্ট
            </h4>
            <div className="space-y-1 text-[11px] leading-relaxed">
              <p>• <strong>অ্যান্টি-টিমিং (Anti-Teaming):</strong> সোলো ম্যাচে কোনো ধরনের টিমিং বা সমঝোতা ধরা পড়লে সাথে সাথে টুর্নামেন্ট ব্ল্যাকলিস্ট করা হবে।</p>
              <p>• <strong>হ্যাক ও স্ক্রিপ্ট নিষেধাজ্ঞা:</strong> কোনো ধরনের অটো-এইম, হেডশট স্ক্রিপ্ট, থার্ড পার্টি অ্যাপ বা পিসি এমুলেটর সম্পূর্ণ নিষিদ্ধ।</p>
              <p>• <strong>রুম এন্ট্রি টাইম:</strong> ম্যাচ শুরুর অন্তত ৫ মিনিট পূর্বে রুম আইডি ও পাসওয়ার্ড দিয়ে কাস্টম রুমে প্রবেশ করতে হবে। বিলম্বে রুম শুরু হলে প্লেয়ার বাদ পড়বে।</p>
              <p>• <strong>ব্ল্যাকলিস্ট নীতি:</strong> এই ব্ল্যাকলিস্ট শুধুমাত্র GAMES MORO BD টুর্নামেন্ট প্ল্যাটফর্মের জন্য প্রযোজ্য, এটি অফিসিয়াল গ্যারিনা ফ্রি ফায়ার একাউন্টে কোনো প্রভাব ফেলে না।</p>
            </div>
          </div>
        </div>

        {/* Footer CTA */}
        <div className="p-4 border-t border-white/10 bg-black/60 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-medium">
            ফেয়ার প্লে নিশ্চিত করা আমাদের অঙ্গীকার
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase rounded-xl transition-all shadow-md glow-red"
          >
            নিয়মাবলী পড়েছি ও সম্মত
          </button>
        </div>
      </div>
    </div>
  );
};
