import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  QrCode,
  Sparkles,
  ExternalLink,
  MessageCircle,
  Send,
  Facebook,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface ShareAppModalProps {
  onClose: () => void;
  customShareUrl?: string;
  customMessage?: string;
}

export const ShareAppModal: React.FC<ShareAppModalProps> = ({
  onClose,
  customShareUrl,
  customMessage,
}) => {
  const { showToast } = useAuth();
  const [copied, setCopied] = useState<boolean>(false);
  const [showQr, setShowQr] = useState<boolean>(false);

  const appUrl =
    customShareUrl ||
    (typeof window !== 'undefined' && window.location.origin.includes('localhost')
      ? 'https://ais-pre-fhurq62rycleyxepuemvjb-724385708307.asia-northeast1.run.app'
      : window.location.origin);

  const shareText =
    customMessage ||
    'GAMES MORO BD - বাংলাদেশের প্রিমিয়ার ফ্রি ফায়ার এস্পোর্টস টুর্নামেন্ট অ্যাপ! এখনি রেজিস্টার করে BR Rank, CS Rank ও Lone Wolf ম্যাচে খেলুন এবং জিতে নিন আকর্ষণীয় পুরস্কার!';

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    showToast('অ্যাপের লিঙ্ক কপি করা হয়েছে!', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleCopyFullText = () => {
    navigator.clipboard.writeText(`${shareText}\n\nঅ্যাপ লিঙ্ক: ${appUrl}`);
    setCopied(true);
    showToast('সম্পূর্ণ মেসেজ ও লিঙ্ক কপি করা হয়েছে!', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'GAMES MORO BD - Esports Tournament Management',
          text: shareText,
          url: appUrl,
        });
        showToast('ধন্যবাদ অ্যাপটি শেয়ার করার জন্য!', 'success');
      } catch (err) {
        // Dismissed by user
      }
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsappShare = () => {
    const text = encodeURIComponent(`${shareText}\n\n👉 এখনি জয়েন করতে ক্লিক করো: ${appUrl}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleTelegramShare = () => {
    const text = encodeURIComponent(shareText);
    const url = encodeURIComponent(appUrl);
    window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank');
  };

  const handleFacebookShare = () => {
    const url = encodeURIComponent(appUrl);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-red-600/20 text-red-400 border border-red-500/30">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
                অ্যাপ শেয়ার করুন (Share App)
              </h3>
              <p className="text-[10px] text-slate-400">
                বন্ধুদের সাথে শেয়ার করে একসাথে স্কোয়াড ম্যাচ খেলুন
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4 text-xs">
          {/* Hero Banner Preview */}
          <div className="relative rounded-2xl overflow-hidden border border-red-600/30 bg-gradient-to-r from-red-950 via-[#15111b] to-black p-4 flex items-center gap-3 shadow-lg">
            <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-red-500/50 shrink-0 shadow-md">
              <img
                src="/src/assets/images/tournament_badge_logo_1793899506853.jpg"
                alt="GAMES MORO BD"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-heading font-extrabold text-sm text-white">
                  GAMES MORO <span className="text-red-500">BD</span>
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  OFFICIAL
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">
                {shareText}
              </p>
            </div>
          </div>

          {/* Quick 1-Click Copy Link Box */}
          <div className="bg-black/60 border border-white/10 rounded-2xl p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span className="font-medium text-slate-300">অফিশিয়াল অ্যাপ লিঙ্ক</span>
              <span className="text-[10px] text-emerald-400">সবার জন্য উন্মুক্ত</span>
            </div>

            <div className="flex items-center gap-2 bg-zinc-900/90 border border-white/10 rounded-xl p-2">
              <span className="font-mono text-xs text-slate-300 truncate flex-1 select-all px-1">
                {appUrl}
              </span>
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs transition-all shrink-0 active:scale-95 shadow-md"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'কপি হয়েছে' : 'কপি করুন'}</span>
              </button>
            </div>
          </div>

          {/* Social Share Buttons Grid */}
          <div className="flex flex-col gap-2">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
              সোশ্যাল মিডিয়ায় সরাসরি শেয়ার করুন:
            </span>

            <div className="grid grid-cols-2 gap-2">
              {/* WhatsApp */}
              <button
                onClick={handleWhatsappShare}
                className="flex items-center justify-center gap-2 p-3 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-600/40 text-emerald-300 font-bold transition-all active:scale-98"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>হোয়াটসঅ্যাপ</span>
              </button>

              {/* Facebook */}
              <button
                onClick={handleFacebookShare}
                className="flex items-center justify-center gap-2 p-3 rounded-xl bg-blue-950/60 hover:bg-blue-900/70 border border-blue-600/40 text-blue-300 font-bold transition-all active:scale-98"
              >
                <Facebook className="w-4 h-4 text-blue-400" />
                <span>ফেসবুক</span>
              </button>

              {/* Telegram */}
              <button
                onClick={handleTelegramShare}
                className="flex items-center justify-center gap-2 p-3 rounded-xl bg-sky-950/60 hover:bg-sky-900/70 border border-sky-600/40 text-sky-300 font-bold transition-all active:scale-98"
              >
                <Send className="w-4 h-4 text-sky-400" />
                <span>টেলিগ্রাম</span>
              </button>

              {/* QR Code Toggle */}
              <button
                onClick={() => setShowQr(!showQr)}
                className="flex items-center justify-center gap-2 p-3 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 border border-white/10 text-slate-200 font-bold transition-all active:scale-98"
              >
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>{showQr ? 'কিউআর বন্ধ' : 'QR কোড'}</span>
              </button>
            </div>
          </div>

          {/* QR Code Section (if toggled) */}
          {showQr && (
            <div className="bg-black/70 border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center gap-2 animate-in fade-in">
              <span className="text-[11px] font-bold text-slate-300">
                অন্য ফোন দিয়ে স্ক্যান করে অ্যাপে প্রবেশ করুন
              </span>
              <div className="p-3 bg-white rounded-xl shadow-lg">
                {/* Clean inline QR Code depiction */}
                <div className="w-32 h-32 flex flex-col items-center justify-center border-4 border-black p-1 text-center font-mono">
                  <div className="grid grid-cols-5 gap-1 w-full h-full p-1 bg-black text-white text-[8px] font-bold place-content-center">
                    <span className="bg-white text-black p-1">GM</span>
                    <span className="bg-white text-black p-1">BD</span>
                    <span className="bg-white text-black p-1">FF</span>
                    <span className="bg-white text-black p-1">2026</span>
                    <span className="bg-white text-black p-1">ES</span>
                  </div>
                </div>
              </div>
              <span className="text-[10px] text-slate-400 font-mono mt-1">
                Scan to join GAMES MORO BD
              </span>
            </div>
          )}

          {/* Native Android Share Sheet Button */}
          <button
            onClick={handleNativeShare}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-heading font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-red-950/60 active:scale-98 transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>ডিভাইস শেয়ার মেন্যু খুলুন (Share Sheet)</span>
          </button>

          <button
            onClick={handleCopyFullText}
            className="w-full py-2.5 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors border border-white/5"
          >
            <Copy className="w-3.5 h-3.5 text-slate-400" />
            <span>ক্যাপশন সহ সম্পূর্ণ মেসেজ কপি করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
