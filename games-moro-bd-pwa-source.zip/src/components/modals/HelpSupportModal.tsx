import React, { useState, useEffect } from 'react';
import {
  X,
  HelpCircle,
  MessageSquare,
  Send,
  CheckCircle,
  ExternalLink,
  Phone,
  Shield,
  ChevronDown,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { SupportTicket } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface HelpSupportModalProps {
  onClose: () => void;
}

export const HelpSupportModal: React.FC<HelpSupportModalProps> = ({ onClose }) => {
  const { user, showToast } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [subject, setSubject] = useState<string>('');
  const [category, setCategory] = useState<string>('Match Dispute');
  const [message, setMessage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const fetchTickets = async () => {
    try {
      const res = await api.getSupportTickets();
      setTickets(res.tickets);
    } catch (err) {}
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    try {
      setIsSubmitting(true);
      await api.createSupportTicket({
        subject,
        category,
        message,
      });
      showToast('Support ticket dispatched to operations team!', 'success');
      setSubject('');
      setMessage('');
      await fetchTickets();
    } catch (err: any) {
      showToast(err.message || 'Failed to submit ticket', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const faqs = [
    {
      q: 'How do I obtain the Room ID and Password after registering?',
      a: 'Go to "My Matches". When the assigned officer prepares the room (typically 10 minutes prior to scheduled start), the Room ID and Password will unlock with a 1-tap copy button for your clipboard.',
    },
    {
      q: 'How does the BR Rank Top 5 kill cap scoring work?',
      a: 'Only participants in the Top 5 receive points. You receive position points (1st: 100, 2nd: 70, 3rd: 50, 4th: 30, 5th: 20) plus 5 TP per kill, capped at a maximum of 5 rewarded kills. For example, a 1st place player with 6 kills receives 100 + (5 × 5) = 125 TP.',
    },
    {
      q: 'What should I do if my in-game teammate or opponent cheats?',
      a: 'Record your screen or take a screenshot of the kill log, and submit a ticket under "Match Dispute" or notify your assigned match officer in the lobby.',
    },
    {
      q: 'Are Tournament Points (TP) redeemable for cash or bKash?',
      a: 'No. Per Bangladesh regulations and GAMES MORO BD terms, Tournament Points are strictly competitive ranking score units for our seasonal leaderboard.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-amber-500" />
            <h3 className="font-heading font-extrabold text-base text-white uppercase tracking-wider">
              Help Center & Support Desk
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 text-xs text-slate-300 space-y-5">
          {/* Official Helplines */}
          <div className="grid grid-cols-2 gap-2 text-center">
            <a
              href="https://wa.me/8801700000000"
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-600/30 text-emerald-300 font-semibold hover:bg-emerald-900/50 transition-colors flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>WhatsApp Helpline</span>
            </a>
            <div className="p-2.5 rounded-xl bg-blue-950/50 border border-blue-600/30 text-blue-300 font-semibold flex items-center justify-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              <span>24/7 Referee Desk</span>
            </div>
          </div>

          {/* FAQs Accordion */}
          <div>
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider mb-2">
              Frequently Asked Questions
            </h4>
            <div className="space-y-2">
              {faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className="bg-[#10121c] border border-white/10 rounded-xl overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    className="w-full p-3 text-left font-semibold text-xs text-white flex items-center justify-between gap-2"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-400 transition-transform ${
                        openFaq === idx ? 'rotate-180 text-amber-400' : ''
                      }`}
                    />
                  </button>
                  {openFaq === idx && (
                    <div className="px-3 pb-3 text-[11px] text-slate-400 leading-relaxed border-t border-white/5 pt-2">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Submit Support Ticket Form */}
          <form
            onSubmit={handleSubmitTicket}
            className="bg-[#10121c] border border-white/10 rounded-2xl p-4 flex flex-col gap-3"
          >
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-red-500" />
              Submit Official Support Ticket
            </h4>

            <div>
              <label className="text-slate-400 block mb-1">Issue Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs"
              >
                <option value="Match Dispute">Match Dispute / Score Audit</option>
                <option value="Room Access">Room Password Not Unlocking</option>
                <option value="Registration">Registration or Slot Error</option>
                <option value="Report Player">Report Suspected Teaming or Hack</option>
                <option value="Other">General Inquiries</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Subject</label>
              <input
                type="text"
                placeholder="Brief summary of issue"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Detailed Message</label>
              <textarea
                rows={3}
                placeholder="Include match ID, room number, or player UID..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md"
            >
              {isSubmitting ? 'Sending Ticket...' : 'Dispatch Ticket to Support'}
            </button>
          </form>

          {/* Past Tickets */}
          {tickets.length > 0 && (
            <div>
              <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider mb-2">
                Your Support Tickets ({tickets.length})
              </h4>
              <div className="space-y-2">
                {tickets.map((t) => (
                  <div
                    key={t.id}
                    className="bg-black/40 border border-white/10 rounded-xl p-3 flex flex-col gap-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{t.subject}</span>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                          t.status === 'RESOLVED'
                            ? 'bg-emerald-950 text-emerald-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {t.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{t.message}</p>
                    {t.adminReply && (
                      <div className="bg-zinc-900 p-2 rounded-lg text-[11px] text-emerald-300 mt-1">
                        <strong>Admin Reply:</strong> {t.adminReply}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
