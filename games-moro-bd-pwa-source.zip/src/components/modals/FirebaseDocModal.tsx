import React, { useState } from 'react';
import { X, Layers, Database, Shield, Server, Copy, Check, Terminal } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface FirebaseDocModalProps {
  onClose: () => void;
}

export const FirebaseDocModal: React.FC<FirebaseDocModalProps> = ({ onClose }) => {
  const { showToast } = useAuth();
  const [activeTab, setActiveTab] = useState<'schema' | 'rules' | 'functions' | 'deploy'>('schema');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyCode = (code: string, label: string) => {
    navigator.clipboard.writeText(code);
    setCopiedKey(label);
    showToast(`Copied ${label} to clipboard!`, 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const firestoreRulesSnippet = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helper functions for Role-Based Access Control
    function isAuthenticated() {
      return request.auth != null;
    }

    function getUserData() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data;
    }

    function isOfficer() {
      return isAuthenticated() && getUserData().role in ['officer', 'admin', 'owner'];
    }

    function isAdmin() {
      return isAuthenticated() && getUserData().role in ['admin', 'owner'];
    }

    function isOwner() {
      return isAuthenticated() && getUserData().role == 'owner';
    }

    // 1. Users Collection
    match /users/{userId} {
      allow read: if isAuthenticated();
      allow create: if isAuthenticated() && request.auth.uid == userId;
      // Protect owner account from modification by standard admins
      allow update: if isOwner() || (isAdmin() && resource.data.role != 'owner') || (request.auth.uid == userId && !request.resource.data.diff(resource.data).affectedKeys().hasAny(['role', 'isBanned']));
      allow delete: if isOwner() && resource.data.role != 'owner';
    }

    // 2. Tournaments Collection
    match /tournaments/{tournamentId} {
      allow read: if isAuthenticated();
      allow create, delete: if isAdmin();
      allow update: if isAdmin() || (isOfficer() && request.auth.uid == resource.data.assignedOfficerId);

      // Room Credentials Subcollection: Restrict to registered players & assigned officers
      match /roomCredentials/{credId} {
        allow read: if isAdmin() 
          || (isOfficer() && request.auth.uid == get(/databases/$(database)/documents/tournaments/$(tournamentId)).data.assignedOfficerId)
          || (isAuthenticated() && request.auth.uid in get(/databases/$(database)/documents/tournaments/$(tournamentId)).data.registeredPlayerUids);
        allow write: if isAdmin() || (isOfficer() && request.auth.uid == get(/databases/$(database)/documents/tournaments/$(tournamentId)).data.assignedOfficerId);
      }
    }

    // 3. Match Reports Collection
    match /matchReports/{reportId} {
      allow read: if isAuthenticated();
      allow create: if isOfficer();
      // CRITICAL: Officers cannot approve their own submitted report!
      allow update: if (isAdmin() && request.auth.uid != resource.data.submittedByOfficerId) || isOwner();
      allow delete: if isOwner();
    }

    // 4. Blacklist Collection
    match /blacklist/{blacklistId} {
      allow read: if isAuthenticated();
      allow write: if isAdmin(); // Officers cannot ban or unban
    }

    // 5. Audit Logs
    match /auditLogs/{logId} {
      allow read: if isAdmin();
      allow create: if isAuthenticated();
      allow update, delete: if false; // Append-only audit trail
    }
  }
}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-2xl rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-500" />
            <div>
              <h3 className="font-heading font-extrabold text-base text-white uppercase tracking-wider">
                Production Firebase & Architecture Blueprint
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">
                Full-Stack Cloud Firestore · Auth · Storage · Cloud Functions
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 px-5 border-b border-white/10 text-xs">
          <button
            onClick={() => setActiveTab('schema')}
            className={`py-2.5 px-3 font-bold border-b-2 transition-colors ${
              activeTab === 'schema'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Firestore Schema
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`py-2.5 px-3 font-bold border-b-2 transition-colors ${
              activeTab === 'rules'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            firestore.rules
          </button>
          <button
            onClick={() => setActiveTab('functions')}
            className={`py-2.5 px-3 font-bold border-b-2 transition-colors ${
              activeTab === 'functions'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Cloud Functions & Triggers
          </button>
          <button
            onClick={() => setActiveTab('deploy')}
            className={`py-2.5 px-3 font-bold border-b-2 transition-colors ${
              activeTab === 'deploy'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Deployment & Credentials
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-5 text-xs text-slate-300">
          {activeTab === 'schema' && (
            <div className="space-y-4">
              <div className="bg-black/50 p-3.5 rounded-xl border border-white/10 font-mono text-[11px] space-y-3">
                <div>
                  <span className="text-amber-400 font-bold block">1. Collection: /users/{'{userId}'}</span>
                  <pre className="text-slate-300 overflow-x-auto mt-1">{`{
  id: string,
  email: string,
  phone: string,
  username: string,
  inGameName: string,
  inGameUid: string,        // Free Fire Numeric UID
  tournamentUid: string,    // "GMBD-74892"
  role: "player" | "officer" | "admin" | "owner",
  avatar: string,
  isBanned: boolean,
  stats: {
    matchesPlayed: number,
    wins: number,
    kills: number,
    top5Count: number,
    tournamentPoints: number
  }
}`}</pre>
                </div>

                <div>
                  <span className="text-amber-400 font-bold block">2. Collection: /tournaments/{'{tournamentId}'}</span>
                  <pre className="text-slate-300 overflow-x-auto mt-1">{`{
  id: string,
  title: string,
  mode: "BR_RANK" | "CS_RANK" | "LONE_WOLF",
  maxPlayers: 48 | 8 | 2,
  slotsFilled: number,
  startTime: Timestamp,
  status: "REGISTRATION_OPEN" | "ROOM_PREPARING" | "LIVE" | "COMPLETED",
  assignedOfficerId: string,
  roomDetails: {
    roomId: string,
    roomPassword: string,
    isRevealed: boolean
  },
  registeredPlayers: Array<{ userId, inGameName, inGameUid, teamSlot }>
}`}</pre>
                </div>

                <div>
                  <span className="text-amber-400 font-bold block">3. Collection: /matchReports/{'{reportId}'}</span>
                  <pre className="text-slate-300 overflow-x-auto mt-1">{`{
  id: string,
  tournamentId: string,
  submittedByOfficerId: string,
  status: "PENDING_APPROVAL" | "APPROVED" | "REJECTED",
  evidenceScreenshotUrl: string, // Firebase Storage URL
  results: Array<{ userId, placement, kills, calculatedPoints }>,
  reviewedByAdminId: string
}`}</pre>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'rules' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-heading font-bold text-white text-xs uppercase">
                  Production Cloud Firestore Security Rules
                </span>
                <button
                  onClick={() => copyCode(firestoreRulesSnippet, 'Firestore Rules')}
                  className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-bold"
                >
                  {copiedKey === 'Firestore Rules' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'Firestore Rules' ? 'Copied' : 'Copy Rules'}</span>
                </button>
              </div>

              <div className="bg-black/70 p-3 rounded-xl border border-white/10 font-mono text-[10px] text-slate-300 overflow-x-auto max-h-[380px]">
                <pre>{firestoreRulesSnippet}</pre>
              </div>
            </div>
          )}

          {activeTab === 'functions' && (
            <div className="space-y-3 text-xs leading-relaxed">
              <h4 className="font-heading font-bold text-white text-sm uppercase">
                Server-Authoritative Cloud Functions
              </h4>
              <div className="bg-black/50 p-3.5 rounded-xl border border-white/10 space-y-2">
                <div>
                  <strong className="text-amber-400">1. onScheduleGenerate (Cron */30m):</strong>
                  <p className="text-slate-400 text-[11px]">
                    Runs daily between 08:00 and 24:00. Automatically generates tournament documents in Firestore for CS Rank (every 30m), Lone Wolf (every 30m), and BR Rank (every 40m).
                  </p>
                </div>
                <div>
                  <strong className="text-amber-400">2. validateOfficerAssignment:</strong>
                  <p className="text-slate-400 text-[11px]">
                    Checks that the officer is not assigned to another active tournament within ±45 minutes of the start time. Blocks assignment if an overlap is detected.
                  </p>
                </div>
                <div>
                  <strong className="text-amber-400">3. approveMatchReportTrigger:</strong>
                  <p className="text-slate-400 text-[11px]">
                    Enforces server-side that <code>request.auth.uid != report.submittedByOfficerId</code>. Executes a Firestore Batch Transaction to disburse Tournament Points and update player season stats atomically.
                  </p>
                </div>
                <div>
                  <strong className="text-amber-400">4. pushNotificationFCM:</strong>
                  <p className="text-slate-400 text-[11px]">
                    Sends Firebase Cloud Messaging push alerts to Android devices when room credentials unlock or results are published.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'deploy' && (
            <div className="space-y-3 text-xs leading-relaxed">
              <h4 className="font-heading font-bold text-white text-sm uppercase">
                Required External Credentials & Services
              </h4>

              <div className="bg-red-950/30 border border-red-700/40 rounded-xl p-3 text-[11px] text-red-200">
                <strong>Mandatory Configuration for Production:</strong>
                <p className="mt-1">
                  1. <strong>Firebase Project ID:</strong> Create project in Firebase Console (e.g. <code>games-moro-bd-esports</code>).
                </p>
                <p>
                  2. <strong>Firebase Authentication:</strong> Enable Email/Password, Google OAuth Client ID, and Phone Number (SMS Gateway / Twilio).
                </p>
                <p>
                  3. <strong>Firebase Cloud Messaging (FCM):</strong> Download <code>google-services.json</code> for the Android app manifest.
                </p>
                <p>
                  4. <strong>Authorized Payment Provider:</strong> Keep financial module disabled until Bangladesh Bank / MFS licensing is officially integrated.
                </p>
              </div>

              <div className="bg-black/50 p-3.5 rounded-xl border border-white/10 space-y-2 font-mono text-[11px]">
                <span className="text-slate-300 font-bold block">Android Build Steps (Flutter / Web Wrapper):</span>
                <p className="text-slate-400">1. flutter create --org com.gamesmorobd app</p>
                <p className="text-slate-400">2. cp google-services.json android/app/</p>
                <p className="text-slate-400">3. flutter build apk --release</p>
                <p className="text-slate-400">4. Distribute APK to registered Bangladesh tournament players.</p>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-white/10 bg-black/60 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase rounded-xl transition-all shadow-md"
          >
            Close Blueprint
          </button>
        </div>
      </div>
    </div>
  );
};
