import React, { useState } from 'react';
import {
  X,
  Mail,
  Phone,
  Shield,
  Key,
  CheckCircle,
  ArrowRight,
  Flame,
  User as UserIcon,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { UserRole } from '../../types/index.ts';

interface AuthModalProps {
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose }) => {
  const {
    loginWithGoogle,
    sendPhoneOtp,
    verifyPhoneOtp,
    registerPlayer,
    switchRole,
    showToast,
  } = useAuth();

  const [tab, setTab] = useState<'login' | 'otp' | 'register' | 'recover'>('login');

  // Google / Email form
  const [email, setEmail] = useState<string>('player@gamesmorobd.com');

  // Phone OTP form
  const [phone, setPhone] = useState<string>('+880 1712 345678');
  const [otpCode, setOtpCode] = useState<string>('');
  const [isOtpSent, setIsOtpSent] = useState<boolean>(false);
  const [otpTestHint, setOtpTestHint] = useState<string>('');

  // Register form
  const [regUsername, setRegUsername] = useState<string>('');
  const [regIgn, setRegIgn] = useState<string>('');
  const [regUid, setRegUid] = useState<string>('');
  const [regPhone, setRegPhone] = useState<string>('+880 1700 112233');

  // Fast demo role switcher
  const handleQuickRole = async (r: UserRole) => {
    await switchRole(r);
    onClose();
  };

  const handleGoogleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    await loginWithGoogle(email);
    onClose();
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const hint = await sendPhoneOtp(phone);
      setIsOtpSent(true);
      setOtpTestHint(hint);
      setOtpCode(hint); // Auto-fill test code for ultra-smooth testing
    } catch (err) {}
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await verifyPhoneOtp(phone, otpCode);
      onClose();
    } catch (err) {}
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await registerPlayer({
        username: regUsername,
        inGameName: regIgn,
        inGameUid: regUid,
        phone: regPhone,
      });
      onClose();
    } catch (err) {}
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-red-500 fill-red-500" />
            <h3 className="font-heading font-extrabold text-base text-white uppercase tracking-wider">
              Player Authentication
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Role Tester Strip */}
        <div className="bg-red-950/30 border-b border-red-900/30 px-4 py-2.5 flex flex-col gap-1.5">
          <span className="text-[10px] font-bold uppercase text-red-300 tracking-wider">
            Quick Perspective Switcher (Evaluator Mode):
          </span>
          <div className="grid grid-cols-4 gap-1 text-[11px]">
            <button
              onClick={() => handleQuickRole('player')}
              className="py-1 bg-black/50 hover:bg-black/80 text-slate-200 border border-white/10 rounded-lg font-semibold"
            >
              Player
            </button>
            <button
              onClick={() => handleQuickRole('officer')}
              className="py-1 bg-blue-950/60 hover:bg-blue-900/80 text-blue-300 border border-blue-700/40 rounded-lg font-semibold"
            >
              Officer
            </button>
            <button
              onClick={() => handleQuickRole('admin')}
              className="py-1 bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-700/40 rounded-lg font-semibold"
            >
              Admin
            </button>
            <button
              onClick={() => handleQuickRole('owner')}
              className="py-1 bg-red-900/60 hover:bg-red-800/80 text-red-200 border border-red-600/40 rounded-lg font-semibold"
            >
              Owner
            </button>
          </div>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-3 border-b border-white/10 text-xs text-center font-bold">
          <button
            onClick={() => setTab('login')}
            className={`py-3 transition-colors border-b-2 ${
              tab === 'login'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Email Login
          </button>
          <button
            onClick={() => setTab('otp')}
            className={`py-3 transition-colors border-b-2 ${
              tab === 'otp'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Phone OTP
          </button>
          <button
            onClick={() => setTab('register')}
            className={`py-3 transition-colors border-b-2 ${
              tab === 'register'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            New Player
          </button>
        </div>

        <div className="p-5 overflow-y-auto text-xs">
          {tab === 'login' && (
            <form onSubmit={handleGoogleLogin} className="flex flex-col gap-3.5">
              <div>
                <label className="text-slate-400 block mb-1">Gmail or Registered Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full bg-black/60 border border-white/15 rounded-xl pl-9 pr-3 py-2.5 text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-heading font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md glow-red"
              >
                Sign In with Google Account
              </button>

              <button
                type="button"
                onClick={() => setTab('otp')}
                className="text-center text-[11px] text-slate-400 hover:text-slate-200 mt-2"
              >
                Prefer Phone OTP Login? Switch to Phone Verification
              </button>
            </form>
          )}

          {tab === 'otp' && (
            <div className="flex flex-col gap-3.5">
              {!isOtpSent ? (
                <form onSubmit={handleSendOtp} className="flex flex-col gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">
                      Bangladesh Phone Number (+880)
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        required
                        className="w-full bg-black/60 border border-white/15 rounded-xl pl-9 pr-3 py-2.5 text-white font-mono"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase rounded-xl shadow-md"
                  >
                    Send 4-Digit OTP Code
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="flex flex-col gap-3">
                  <div className="bg-amber-950/30 p-2.5 rounded-xl border border-amber-600/30 text-[11px] text-amber-300">
                    OTP sent to <strong>{phone}</strong>. For instant test access, code is: <strong>{otpTestHint}</strong>
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1">Enter Verification Code</label>
                    <input
                      type="text"
                      maxLength={6}
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      required
                      className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2.5 text-white font-mono text-center text-lg tracking-widest"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-heading font-bold text-xs uppercase rounded-xl shadow-md"
                  >
                    Verify & Authenticate
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsOtpSent(false)}
                    className="text-center text-[11px] text-slate-400 hover:text-white"
                  >
                    Change phone number
                  </button>
                </form>
              )}
            </div>
          )}

          {tab === 'register' && (
            <form onSubmit={handleRegister} className="flex flex-col gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Account Username</label>
                <input
                  type="text"
                  placeholder="e.g. ShadowHunter_BD"
                  value={regUsername}
                  onChange={(e) => setRegUsername(e.target.value)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Free Fire In-Game Name (IGN)</label>
                <input
                  type="text"
                  placeholder="e.g. SHADOW亗KILL"
                  value={regIgn}
                  onChange={(e) => setRegIgn(e.target.value)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">In-Game Free Fire UID (Numeric)</label>
                <input
                  type="text"
                  placeholder="e.g. 192837465"
                  value={regUid}
                  onChange={(e) => setRegUid(e.target.value)}
                  required
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">WhatsApp / Phone</label>
                <input
                  type="text"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-heading font-bold text-xs uppercase tracking-wider rounded-xl shadow-md mt-1"
              >
                Create Tournament Account
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
