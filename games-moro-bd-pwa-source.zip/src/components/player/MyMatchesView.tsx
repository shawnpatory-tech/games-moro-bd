import React, { useState, useEffect } from 'react';
import {
  Swords,
  Trophy,
  Clock,
  Key,
  Copy,
  Check,
  ChevronRight,
  Shield,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament, MatchReport } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface MyMatchesViewProps {
  onSelectTournament: (tournament: Tournament) => void;
  onExploreTournaments: () => void;
}

export const MyMatchesView: React.FC<MyMatchesViewProps> = ({
  onSelectTournament,
  onExploreTournaments,
}) => {
  const { user, showToast } = useAuth();
  const [activeTab, setActiveTab] = useState<'registered' | 'history'>('registered');
  const [registeredMatches, setRegisteredMatches] = useState<Tournament[]>([]);
  const [matchHistory, setMatchHistory] = useState<MatchReport[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setIsLoading(true);
      const [tournRes, reportRes] = await Promise.all([
        api.getTournaments(),
        api.getReports('APPROVED'),
      ]);

      const myTourns = tournRes.tournaments.filter((t) =>
        t.registeredPlayers.some((p) => p.userId === user?.id)
      );
      setRegisteredMatches(myTourns);

      // Find reports where current user has results
      const myReports = reportRes.reports.filter((r) =>
        r.results.some((res) => res.userId === user?.id || res.inGameUid === user?.inGameUid)
      );
      setMatchHistory(myReports);
    } catch (err) {
      console.error('Error fetching my matches', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const copyRoomPassword = (pwd: string, id: string) => {
    navigator.clipboard.writeText(pwd);
    setCopiedId(id);
    showToast('Room password copied to clipboard!', 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 pb-12">
      <div>
        <h2 className="font-heading text-xl font-extrabold text-white uppercase tracking-wider">
          My Esports Matches
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Active Registrations, Room Credentials & Match History
        </p>
      </div>

      {/* Segmented View Switcher */}
      <div className="flex items-center p-1 bg-[#10121c] rounded-2xl border border-white/5">
        <button
          onClick={() => setActiveTab('registered')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'registered'
              ? 'bg-red-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Registered Matches ({registeredMatches.length})
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'history'
              ? 'bg-red-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Match History ({matchHistory.length})
        </button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-400 text-xs">
          Loading your matches...
        </div>
      ) : activeTab === 'registered' ? (
        registeredMatches.length === 0 ? (
          <div className="bg-[#10121c] border border-white/10 rounded-2xl p-8 text-center flex flex-col items-center justify-center gap-3">
            <Swords className="w-10 h-10 text-slate-500" />
            <h4 className="font-heading text-base font-bold text-white">
              No Active Registrations
            </h4>
            <p className="text-xs text-slate-400 max-w-xs">
              You haven't joined any upcoming tournament match. Browse the tournament arena and register for free slots.
            </p>
            <button
              onClick={onExploreTournaments}
              className="mt-2 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase transition-all shadow-md"
            >
              Browse Tournaments
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {registeredMatches.map((t) => {
              const myParticipant = t.registeredPlayers.find((p) => p.userId === user?.id);
              const isRoomReady = t.roomDetails.isRevealed;

              return (
                <div
                  key={t.id}
                  className="bg-[#10121c] border border-red-600/30 rounded-2xl p-4 flex flex-col gap-3 shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                        t.mode === 'BR_RANK'
                          ? 'bg-red-950 text-red-300 border border-red-800/40'
                          : 'bg-amber-950 text-amber-300 border border-amber-800/40'
                      }`}
                    >
                      {t.mode.replace('_', ' ')}
                    </span>
                    <span className="text-xs font-mono text-amber-400 font-semibold flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {new Date(t.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-heading font-extrabold text-base text-white">
                      {t.title}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>Map: {t.roomDetails.customMap || 'Bermuda'}</span>
                      {myParticipant?.teamSlot && (
                        <span>· Team: {myParticipant.teamSlot}</span>
                      )}
                    </div>
                  </div>

                  {/* Room Credentials Card */}
                  <div className="bg-black/50 p-3 rounded-xl border border-white/10 flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                        <Key className="w-3.5 h-3.5 text-amber-400" />
                        Room ID: <strong className="text-white">{t.roomDetails.roomId}</strong>
                      </span>
                      {isRoomReady && t.roomDetails.roomPassword && (
                        <button
                          onClick={() => copyRoomPassword(t.roomDetails.roomPassword || '', t.id)}
                          className="flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 bg-amber-950/60 px-2 py-1 rounded-lg border border-amber-600/30"
                        >
                          {copiedId === t.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                          <span>Pass: {t.roomDetails.roomPassword}</span>
                        </button>
                      )}
                    </div>

                    {!isRoomReady && (
                      <p className="text-[10px] text-slate-500 italic">
                        Password unlocks automatically 10m before match start.
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-slate-400">
                      Officer on duty: {t.assignedOfficerName || 'Assigned'}
                    </span>
                    <button
                      onClick={() => onSelectTournament(t)}
                      className="text-xs font-bold text-red-400 hover:text-red-300 flex items-center gap-1"
                    >
                      <span>Match Room Sheet</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : (
        /* Match History */
        matchHistory.length === 0 ? (
          <div className="bg-[#10121c] border border-white/10 rounded-2xl p-8 text-center flex flex-col items-center justify-center gap-2">
            <Trophy className="w-10 h-10 text-slate-500" />
            <h4 className="font-heading text-base font-bold text-white">
              No Finished Matches Yet
            </h4>
            <p className="text-xs text-slate-400 max-w-xs">
              When tournament officers submit and Admins approve official results, your rank, kills, and earned Tournament Points will appear here.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {matchHistory.map((report) => {
              const myRes = report.results.find(
                (r) => r.userId === user?.id || r.inGameUid === user?.inGameUid
              );
              const placement = myRes?.placement || 1;
              const kills = myRes?.kills || 0;
              const points = myRes?.calculatedPoints || 0;

              return (
                <div
                  key={report.id}
                  className="bg-[#10121c] border border-white/10 rounded-2xl p-4 flex flex-col gap-2.5 shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      {report.tournamentTitle}
                    </span>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-700/40">
                      VERIFIED RESULT
                    </span>
                  </div>

                  <div className="flex items-center justify-between bg-black/40 p-3 rounded-xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-heading font-extrabold text-base ${
                          placement === 1
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                            : placement <= 5
                            ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                            : 'bg-zinc-800 text-slate-400'
                        }`}
                      >
                        #{placement}
                      </div>

                      <div className="flex flex-col">
                        <span className="font-heading font-bold text-sm text-white">
                          {placement === 1
                            ? 'BOOYAH! 1st Place'
                            : placement <= 5
                            ? `Top 5 Rank (#${placement})`
                            : `Placed #${placement}`}
                        </span>
                        <span className="text-xs text-slate-400">
                          {kills} Kills Confirmed
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">
                        Awarded
                      </span>
                      <p className="font-heading text-lg font-extrabold text-amber-400 tabular-nums">
                        +{points} <span className="text-xs font-normal">TP</span>
                      </p>
                    </div>
                  </div>

                  <div className="text-[10px] text-slate-500 italic">
                    Audited & Approved by {report.reviewedByAdminName || 'Admin Ops'}
                  </div>
                </div>
              );
            })}
          </div>
        )
      )}
    </div>
  );
};
