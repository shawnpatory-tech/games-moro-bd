import React, { useState, useEffect } from 'react';
import {
  Medal,
  Trophy,
  Download,
  Flame,
  Award,
  Crown,
  Search,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';

export const LeaderboardView: React.FC = () => {
  const { user, showToast } = useAuth();
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [period, setPeriod] = useState<'all' | 'season1' | 'weekly'>('all');
  const [search, setSearch] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchLeaderboard = async () => {
    try {
      setIsLoading(true);
      const res = await api.getLeaderboard();
      setLeaderboard(res.leaderboard);
    } catch (err) {
      console.error('Error fetching leaderboard', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const exportCSV = () => {
    if (leaderboard.length === 0) return;
    const headers = [
      'Rank',
      'Player Name',
      'Tournament UID',
      'In-Game UID',
      'Tournament Points (TP)',
      'Matches Played',
      'Wins',
      'Total Kills',
      'Win Rate %',
      'K/D Ratio',
    ];
    const rows = leaderboard.map((p) => [
      p.rank,
      `"${p.inGameName}"`,
      p.tournamentUid,
      p.inGameUid,
      p.tournamentPoints,
      p.matchesPlayed,
      p.wins,
      p.kills,
      `${p.winRate}%`,
      p.kda,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GAMES_MORO_BD_Leaderboard_${period}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast('Leaderboard CSV exported successfully!', 'success');
  };

  const filtered = leaderboard.filter((p) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      p.username.toLowerCase().includes(q) ||
      p.inGameName.toLowerCase().includes(q) ||
      p.tournamentUid.toLowerCase().includes(q) ||
      p.inGameUid.includes(q)
    );
  });

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-xl font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
            <Medal className="w-5 h-5 text-amber-500" />
            Seasonal Standings
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Top Bangladesh Free Fire Tournament Competitors
          </p>
        </div>

        <button
          onClick={exportCSV}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#10121c] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-300 transition-colors"
          title="Download official rankings CSV"
        >
          <Download className="w-3.5 h-3.5 text-amber-400" />
          <span className="hidden sm:inline">Export CSV</span>
        </button>
      </div>

      {/* Period Selector Tabs */}
      <div className="flex items-center p-1 bg-[#10121c] rounded-2xl border border-white/5 text-xs">
        <button
          onClick={() => setPeriod('all')}
          className={`flex-1 py-1.5 font-bold rounded-xl transition-all ${
            period === 'all'
              ? 'bg-red-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All-Time Elite
        </button>
        <button
          onClick={() => setPeriod('season1')}
          className={`flex-1 py-1.5 font-bold rounded-xl transition-all ${
            period === 'season1'
              ? 'bg-red-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Season 1 Clash
        </button>
        <button
          onClick={() => setPeriod('weekly')}
          className={`flex-1 py-1.5 font-bold rounded-xl transition-all ${
            period === 'weekly'
              ? 'bg-red-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Weekly Top
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search player, in-game name, or UID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-[#10121c] border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500"
        />
      </div>

      {/* Top 3 Podium Cards */}
      {filtered.length >= 3 && !search && (
        <div className="grid grid-cols-3 gap-2 pt-2 pb-1 items-end">
          {/* Rank 2 (Silver) */}
          <div className="bg-gradient-to-t from-[#10121c] to-zinc-900/60 border border-slate-700/40 rounded-2xl p-3 flex flex-col items-center text-center relative pt-4">
            <span className="w-5 h-5 rounded-full bg-slate-300 text-black text-[11px] font-extrabold flex items-center justify-center font-mono absolute -top-2">
              2
            </span>
            <img
              src={filtered[1].avatar}
              alt={filtered[1].username}
              className="w-10 h-10 rounded-full object-cover border border-slate-400 mb-1"
            />
            <h4 className="font-heading font-extrabold text-xs text-white truncate max-w-full">
              {filtered[1].inGameName}
            </h4>
            <span className="text-[10px] text-amber-400 font-bold tabular-nums">
              {filtered[1].tournamentPoints} TP
            </span>
            <span className="text-[9px] text-slate-400 mt-0.5">
              {filtered[1].wins} Wins
            </span>
          </div>

          {/* Rank 1 (Gold Booyah Champion) */}
          <div className="bg-gradient-to-t from-red-950/40 via-[#121422] to-amber-950/30 border border-amber-500/50 rounded-2xl p-3 flex flex-col items-center text-center relative pt-5 shadow-lg glow-gold">
            <Crown className="w-5 h-5 text-amber-400 absolute -top-3" />
            <img
              src={filtered[0].avatar}
              alt={filtered[0].username}
              className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 mb-1"
            />
            <h4 className="font-heading font-extrabold text-sm text-white truncate max-w-full">
              {filtered[0].inGameName}
            </h4>
            <span className="text-xs text-amber-300 font-extrabold tabular-nums">
              {filtered[0].tournamentPoints} TP
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold mt-0.5">
              {filtered[0].wins} Wins · {filtered[0].kills} Kills
            </span>
          </div>

          {/* Rank 3 (Bronze) */}
          <div className="bg-gradient-to-t from-[#10121c] to-amber-950/20 border border-amber-900/40 rounded-2xl p-3 flex flex-col items-center text-center relative pt-4">
            <span className="w-5 h-5 rounded-full bg-amber-700 text-white text-[11px] font-extrabold flex items-center justify-center font-mono absolute -top-2">
              3
            </span>
            <img
              src={filtered[2].avatar}
              alt={filtered[2].username}
              className="w-10 h-10 rounded-full object-cover border border-amber-700 mb-1"
            />
            <h4 className="font-heading font-extrabold text-xs text-white truncate max-w-full">
              {filtered[2].inGameName}
            </h4>
            <span className="text-[10px] text-amber-400 font-bold tabular-nums">
              {filtered[2].tournamentPoints} TP
            </span>
            <span className="text-[9px] text-slate-400 mt-0.5">
              {filtered[2].wins} Wins
            </span>
          </div>
        </div>
      )}

      {/* Leaderboard Table List */}
      <div className="flex flex-col gap-1.5">
        <div className="grid grid-cols-12 text-[10px] uppercase font-bold text-slate-400 px-3 py-1">
          <span className="col-span-2">Rank</span>
          <span className="col-span-6">Player Details</span>
          <span className="col-span-4 text-right">Points / Wins</span>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Calculating rankings...
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            No players found matching query.
          </div>
        ) : (
          filtered.map((player) => {
            const isMe = player.id === user?.id;

            return (
              <div
                key={player.id}
                className={`grid grid-cols-12 items-center p-3 rounded-2xl border transition-all ${
                  isMe
                    ? 'bg-red-950/40 border-red-600/60 shadow-sm'
                    : 'bg-[#10121c] border-white/5 hover:border-white/10'
                }`}
              >
                {/* Rank */}
                <div className="col-span-2 flex items-center gap-1.5">
                  <span
                    className={`font-heading font-extrabold text-sm font-mono ${
                      player.rank === 1
                        ? 'text-amber-400 text-base'
                        : player.rank === 2
                        ? 'text-slate-300'
                        : player.rank === 3
                        ? 'text-amber-600'
                        : 'text-slate-400'
                    }`}
                  >
                    #{player.rank}
                  </span>
                </div>

                {/* Player details */}
                <div className="col-span-6 flex items-center gap-2 overflow-hidden">
                  <img
                    src={player.avatar}
                    alt={player.username}
                    className="w-8 h-8 rounded-full object-cover border border-white/10 shrink-0"
                  />
                  <div className="flex flex-col overflow-hidden">
                    <span className="font-heading font-bold text-xs text-white truncate">
                      {player.inGameName}
                      {isMe && <span className="text-[9px] text-red-400 ml-1 font-sans">(You)</span>}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono truncate">
                      {player.tournamentUid} · {player.inGameUid}
                    </span>
                  </div>
                </div>

                {/* Points / Wins */}
                <div className="col-span-4 text-right flex flex-col justify-center">
                  <span className="font-heading font-extrabold text-sm text-amber-400 tabular-nums">
                    {player.tournamentPoints} <span className="text-[10px] font-normal">TP</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {player.wins}W · {player.kills}K
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
