import React, { useState } from 'react';
import {
  User as UserIcon,
  Shield,
  Edit3,
  AlertTriangle,
  Award,
  BookOpen,
  HelpCircle,
  FileText,
  LogOut,
  Send,
  CheckCircle,
  ExternalLink,
  Layers,
  Copy,
  Check,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../services/api.ts';

interface ProfileViewProps {
  onOpenRules: () => void;
  onOpenHelp: () => void;
  onOpenFirebaseDoc: () => void;
  onOpenAuth: () => void;
  onOpenWallet: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onOpenRules,
  onOpenHelp,
  onOpenFirebaseDoc,
  onOpenAuth,
  onOpenWallet,
}) => {
  const { user, walletBalance, updateProfile, logout, showToast, refreshUser } = useAuth();
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [inGameName, setInGameName] = useState<string>(user?.inGameName || '');
  const [inGameUid, setInGameUid] = useState<string>(user?.inGameUid || '');
  const [phone, setPhone] = useState<string>(user?.phone || '');
  const [copiedUid, setCopiedUid] = useState<boolean>(false);

  // Appeal state
  const [isAppealing, setIsAppealing] = useState<boolean>(false);
  const [appealText, setAppealText] = useState<string>('');
  const [isSubmittingAppeal, setIsSubmittingAppeal] = useState<boolean>(false);

  if (!user) return null;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateProfile({
        inGameName,
        inGameUid,
        phone,
      });
      setIsEditing(false);
      showToast('Profile updated successfully!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update profile', 'error');
    }
  };

  const handleAppealSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!appealText.trim()) return;

    try {
      setIsSubmittingAppeal(true);
      await api.submitAppeal(user.inGameUid, appealText);
      showToast('Ban appeal submitted to Admin review queue.', 'success');
      setIsAppealing(false);
      setAppealText('');
      await refreshUser();
    } catch (err: any) {
      showToast(err.message || 'Failed to submit appeal', 'error');
    } finally {
      setIsSubmittingAppeal(false);
    }
  };

  const copyUid = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUid(true);
    showToast('Copied Tournament UID!', 'success');
    setTimeout(() => setCopiedUid(false), 2000);
  };

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 pb-12">
      {/* Profile Card */}
      <div className="relative rounded-2xl bg-gradient-to-b from-[#161825] to-[#0f111c] border border-white/10 p-4 shadow-xl overflow-hidden">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.username}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-red-500 shadow-md"
              />
              <span
                className={`absolute -bottom-1 -right-1 text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded-md ${
                  user.role === 'owner'
                    ? 'bg-red-600 text-white'
                    : user.role === 'admin'
                    ? 'bg-amber-600 text-white'
                    : user.role === 'officer'
                    ? 'bg-blue-600 text-white'
                    : 'bg-zinc-700 text-slate-300'
                }`}
              >
                {user.role}
              </span>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <h3 className="font-heading font-extrabold text-base text-white">
                  {user.inGameName}
                </h3>
              </div>
              <span className="text-xs text-slate-400">@{user.username}</span>
              <div className="flex items-center gap-2 mt-1">
                <button
                  onClick={() => copyUid(user.tournamentUid)}
                  className="flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-black/40 text-red-400 border border-red-900/40 hover:bg-black/70 transition-colors"
                >
                  <span>{user.tournamentUid}</span>
                  {copiedUid ? <Check className="w-2.5 h-2.5" /> : <Copy className="w-2.5 h-2.5" />}
                </button>
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              setInGameName(user.inGameName);
              setInGameUid(user.inGameUid);
              setPhone(user.phone);
              setIsEditing(!isEditing);
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors"
            title="Edit Profile"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        </div>

        {/* Detailed UID & Contact info */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-white/5 text-[11px]">
          <div>
            <span className="text-slate-400 text-[10px]">Free Fire UID:</span>
            <p className="font-mono font-bold text-white mt-0.5">{user.inGameUid}</p>
          </div>
          <div>
            <span className="text-slate-400 text-[10px]">Phone Number:</span>
            <p className="font-mono font-medium text-slate-300 mt-0.5">{user.phone}</p>
          </div>
        </div>
      </div>

      {/* Account Wallet (ডিপোজিট ও উইথড্র) Card */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/60 via-[#101915] to-[#0d1217] border border-emerald-500/40 p-4 shadow-xl flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                অ্যাপ ওয়ালেট ব্যালেন্স
              </span>
              <h4 className="font-heading text-xl font-extrabold text-white">
                ৳{walletBalance} <span className="text-xs font-normal text-emerald-300">BDT</span>
              </h4>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-300 bg-black/40 px-2.5 py-1 rounded-lg border border-white/5">
            <span className="text-[#E2136E]">bKash</span> ·{' '}
            <span className="text-[#F7941D]">Nagad</span> ·{' '}
            <span className="text-[#8C3494]">Rocket</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            onClick={onOpenWallet}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-heading font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-emerald-950/50 active:scale-98"
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>ডিপোজিট করুন</span>
          </button>
          <button
            onClick={onOpenWallet}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-slate-200 border border-white/10 font-heading font-bold text-xs uppercase tracking-wider transition-all active:scale-98"
          >
            <ArrowUpRight className="w-4 h-4 text-amber-400" />
            <span>উইথড্র করুন</span>
          </button>
        </div>
      </div>

      {/* Edit Profile Form (Inline Expansion) */}
      {isEditing && (
        <form
          onSubmit={handleSaveProfile}
          className="bg-[#10121c] border border-red-600/40 rounded-2xl p-4 flex flex-col gap-3 animate-in fade-in"
        >
          <div className="flex items-center justify-between">
            <h4 className="font-heading font-bold text-sm text-white">
              Edit Player Credentials
            </h4>
            <span className="text-[10px] text-slate-400">Updates sync instantly</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">In-Game Name (IGN)</label>
              <input
                type="text"
                value={inGameName}
                onChange={(e) => setInGameName(e.target.value)}
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">In-Game Free Fire UID (Number)</label>
              <input
                type="text"
                value={inGameUid}
                onChange={(e) => setInGameUid(e.target.value)}
                required
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Phone / WhatsApp</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-black/60 border border-white/15 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-3 py-1.5 rounded-xl bg-zinc-800 text-slate-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-sm"
            >
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Account Status Card & Ban Appeal Workflow */}
      {user.isBanned ? (
        <div className="bg-red-950/80 border border-red-600/70 rounded-2xl p-4 flex flex-col gap-3 shadow-lg glow-red">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-heading font-extrabold text-sm text-red-200 uppercase tracking-wide">
                Tournament Blacklist Active
              </h4>
              <p className="text-xs text-red-300/90 mt-1 leading-relaxed">
                <strong>Reason:</strong> {user.banDetails?.reason}
              </p>
              <div className="text-[11px] text-red-400/80 mt-1 font-mono">
                Duration: {user.banDetails?.duration} · Banned by: {user.banDetails?.bannedByName}
              </div>
            </div>
          </div>

          {/* Appeal Status / Action */}
          {user.banDetails?.appealStatus === 'PENDING' ? (
            <div className="bg-black/40 p-3 rounded-xl border border-white/10 text-xs text-slate-300">
              <span className="font-bold text-amber-400 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" />
                Appeal Under Review
              </span>
              <p className="text-[11px] text-slate-400 mt-1">
                Your appeal statement was logged on{' '}
                {new Date(user.banDetails.appealSubmittedAt || Date.now()).toLocaleDateString()}. The Super Admin will review your recording/evidence.
              </p>
            </div>
          ) : user.banDetails?.appealStatus === 'REJECTED' ? (
            <div className="bg-black/40 p-3 rounded-xl border border-white/10 text-xs text-slate-300">
              <span className="font-bold text-red-400">Appeal Rejected</span>
              <p className="text-[11px] text-slate-400 mt-1">
                The administrative board upheld the penalty based on referee kill logs.
              </p>
            </div>
          ) : (
            <div>
              {!isAppealing ? (
                <button
                  onClick={() => setIsAppealing(true)}
                  className="w-full py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase rounded-xl transition-all shadow-md"
                >
                  Submit Ban Appeal
                </button>
              ) : (
                <form onSubmit={handleAppealSubmit} className="flex flex-col gap-2 pt-1">
                  <label className="text-[11px] font-bold text-white">
                    Explain why your blacklist should be lifted:
                  </label>
                  <textarea
                    rows={3}
                    value={appealText}
                    onChange={(e) => setAppealText(e.target.value)}
                    placeholder="Provide context, handcam recording link, or tournament room details..."
                    required
                    className="w-full bg-black/60 border border-white/20 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-red-500"
                  />
                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAppealing(false)}
                      className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmittingAppeal}
                      className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-sm"
                    >
                      {isSubmittingAppeal ? 'Submitting...' : 'Send Appeal'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="bg-[#10121c] border border-emerald-600/30 rounded-2xl p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="font-bold text-xs text-white">Verified Competitor</span>
              <p className="text-[10px] text-slate-400">Good Standing · Fair Play Certified</p>
            </div>
          </div>
          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/40">
            Active
          </span>
        </div>
      )}

      {/* Esports Career Statistics */}
      <div className="bg-[#10121c] border border-white/10 rounded-2xl p-4 flex flex-col gap-3">
        <h4 className="font-heading font-extrabold text-sm text-white uppercase tracking-wider flex items-center gap-1.5">
          <Award className="w-4 h-4 text-amber-500" />
          Career Statistics
        </h4>

        <div className="grid grid-cols-3 gap-2.5 text-center">
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 font-medium">Points (TP)</span>
            <p className="font-heading text-lg font-extrabold text-amber-400 tabular-nums">
              {user.stats.tournamentPoints}
            </p>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 font-medium">Booyah Wins</span>
            <p className="font-heading text-lg font-extrabold text-emerald-400 tabular-nums">
              {user.stats.wins}
            </p>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 font-medium">Total Matches</span>
            <p className="font-heading text-lg font-extrabold text-white tabular-nums">
              {user.stats.matchesPlayed}
            </p>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 font-medium">Confirmed Kills</span>
            <p className="font-heading text-lg font-extrabold text-red-400 tabular-nums">
              {user.stats.kills}
            </p>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 font-medium">Top 5 Placements</span>
            <p className="font-heading text-lg font-extrabold text-amber-300 tabular-nums">
              {user.stats.top5Count}
            </p>
          </div>
          <div className="bg-black/40 p-2.5 rounded-xl border border-white/5">
            <span className="text-[10px] text-slate-400 font-medium">Win Rate</span>
            <p className="font-heading text-lg font-extrabold text-blue-400 tabular-nums">
              {user.stats.winRate}%
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Links & Modals */}
      <div className="bg-[#10121c] border border-white/10 rounded-2xl overflow-hidden divide-y divide-white/5 text-xs">
        <button
          onClick={onOpenRules}
          className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-4 h-4 text-red-400" />
            <span className="font-medium text-white">Official Tournament Rules</span>
          </div>
          <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
        </button>

        <button
          onClick={onOpenHelp}
          className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span className="font-medium text-white">Help Center & Support Desk</span>
          </div>
          <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
        </button>

        <button
          onClick={onOpenFirebaseDoc}
          className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Layers className="w-4 h-4 text-blue-400" />
            <span className="font-medium text-white">Firebase & Production Deployment Guide</span>
          </div>
          <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
        </button>

        <button
          onClick={onOpenAuth}
          className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <UserIcon className="w-4 h-4 text-emerald-400" />
            <span className="font-medium text-white">Sign In / Switch Account</span>
          </div>
          <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
        </button>
      </div>

      {/* Wallet / Financial Module Legal Status */}
      <div className="bg-black/40 border border-white/5 rounded-2xl p-3.5 text-[11px] text-slate-400">
        <span className="font-bold text-slate-300 block mb-1">
          ওয়ালেট ও আর্থিক নিরাপত্তা নীতিমালা
        </span>
        <p className="leading-relaxed">
          GAMES MORO BD-তে সকল টুর্নামেন্ট এন্ট্রি ফি ও প্রাইজমানি লেনদেন বিকাশ, নগদ ও রকেটের মাধ্যমে স্বয়ংক্রিয়ভাবে প্রক্রিয়াজাত করা হয়। প্রতিটি টুর্নামেন্টে অংশ নিতে পর্যাপ্ত অ্যাপ ব্যালেন্স এবং সঠিক Free Fire UID প্রদান বাধ্যতামূলক।
        </p>
      </div>

      {/* Logout button */}
      <button
        onClick={logout}
        className="w-full py-3 rounded-2xl bg-zinc-900 hover:bg-zinc-800 text-red-400 border border-white/5 font-bold text-xs uppercase flex items-center justify-center gap-2 transition-colors"
      >
        <LogOut className="w-4 h-4" />
        <span>End Session / Log Out</span>
      </button>
    </div>
  );
};
