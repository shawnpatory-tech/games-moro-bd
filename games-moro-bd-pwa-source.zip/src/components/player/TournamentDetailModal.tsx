import React, { useState } from 'react';
import {
  X,
  Trophy,
  Users,
  Clock,
  Shield,
  Key,
  Copy,
  Check,
  AlertTriangle,
  Flame,
  CheckCircle,
  HelpCircle,
  Lock,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface TournamentDetailModalProps {
  tournament: Tournament;
  onClose: () => void;
  onRefresh: () => void;
  onPayQualify?: (tournament: Tournament) => void;
}

export const TournamentDetailModal: React.FC<TournamentDetailModalProps> = ({
  tournament,
  onClose,
  onRefresh,
  onPayQualify,
}) => {
  const { user, showToast } = useAuth();
  const [activeTab, setActiveTab] = useState<'info' | 'slots' | 'room' | 'rules'>('info');
  const [selectedTeam, setSelectedTeam] = useState<'Alpha' | 'Bravo'>('Alpha');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const isRegistered = tournament.registeredPlayers.some((p) => p.userId === user?.id);
  const isFull = tournament.slotsFilled >= tournament.maxPlayers;
  const isClosed = tournament.status === 'REGISTRATION_CLOSED' || tournament.status === 'COMPLETED';

  const handleRegister = async () => {
    if (!user) {
      showToast('Please sign in or select a player profile to register.', 'error');
      return;
    }

    if (user.isBanned) {
      showToast('Your tournament account is blacklisted. Registration rejected.', 'error');
      return;
    }

    if (onPayQualify) {
      onPayQualify(tournament);
      return;
    }

    try {
      setIsSubmitting(true);
      await api.registerTournament(tournament.id, tournament.mode === 'CS_RANK' ? selectedTeam : undefined);
      showToast(`Successfully registered for ${tournament.title}!`, 'success');
      onRefresh();
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUnregister = async () => {
    try {
      setIsSubmitting(true);
      await api.unregisterTournament(tournament.id);
      showToast('Cancelled tournament registration', 'info');
      onRefresh();
    } catch (err: any) {
      showToast(err.message || 'Failed to cancel registration', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    showToast(`Copied ${fieldName} to clipboard!`, 'success');
    setTimeout(() => setCopiedField(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                tournament.mode === 'BR_RANK'
                  ? 'bg-red-950 text-red-300 border border-red-800/40'
                  : tournament.mode === 'CS_RANK'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800/40'
                  : 'bg-blue-950 text-blue-300 border border-blue-800/40'
              }`}
            >
              {tournament.mode.replace('_', ' ')}
            </span>
            <span className="text-xs font-semibold text-slate-300">
              {tournament.slotsFilled}/{tournament.maxPlayers} Slots
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tournament Hero Snippet */}
        <div className="px-5 pt-4 pb-2">
          <h2 className="font-heading text-lg font-bold text-white leading-tight">
            {tournament.title}
          </h2>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Map: {tournament.roomDetails.customMap || 'Bermuda'}</span>
            <span>·</span>
            <span>Region: {tournament.roomDetails.serverRegion || 'Bangladesh'}</span>
            <span>·</span>
            <span className="text-amber-400 font-semibold">{tournament.pointsPrizePool} TP Pool</span>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 px-5 border-b border-white/10 text-xs">
          <button
            onClick={() => setActiveTab('info')}
            className={`py-2.5 px-3 font-semibold border-b-2 transition-colors ${
              activeTab === 'info'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('room')}
            className={`py-2.5 px-3 font-semibold border-b-2 transition-colors flex items-center gap-1 ${
              activeTab === 'room'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            Room Access
          </button>
          <button
            onClick={() => setActiveTab('slots')}
            className={`py-2.5 px-3 font-semibold border-b-2 transition-colors ${
              activeTab === 'slots'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Participants ({tournament.registeredPlayers.length})
          </button>
          <button
            onClick={() => setActiveTab('rules')}
            className={`py-2.5 px-3 font-semibold border-b-2 transition-colors ${
              activeTab === 'rules'
                ? 'border-red-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Rules & Scoring
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-5 text-xs text-slate-300">
          {activeTab === 'info' && (
            <div className="flex flex-col gap-4">
              {/* Match Timing & Officer */}
              <div className="grid grid-cols-2 gap-3 bg-black/40 p-3.5 rounded-2xl border border-white/5">
                <div>
                  <span className="text-[10px] text-slate-400 font-medium">Start Time</span>
                  <p className="text-xs font-mono font-bold text-white mt-0.5">
                    {new Date(tournament.startTime).toLocaleString()}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-medium">Assigned Officer</span>
                  <p className="text-xs font-semibold text-blue-400 mt-0.5">
                    {tournament.assignedOfficerName || 'Assigned prior to match'}
                  </p>
                </div>
              </div>

              {/* Free Entry & TP Notice */}
              <div className="bg-amber-950/30 border border-amber-600/30 rounded-xl p-3 flex items-start gap-2.5">
                <Trophy className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-amber-200 text-xs">
                    Official Competitive Qualifier
                  </h4>
                  <p className="text-[11px] text-amber-300/80 mt-0.5">
                    This match awards official Tournament Points (TP) for the GAMES MORO BD Bangladesh seasonal rankings. Points are purely competitive score values.
                  </p>
                </div>
              </div>

              {/* Summary Rules */}
              <div>
                <h4 className="font-heading font-bold text-white text-xs uppercase tracking-wider mb-2">
                  Match Format Specifics
                </h4>
                <div className="space-y-1.5">
                  {tournament.rulesSummary.map((rule, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-[11px] text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                      <span>{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Team Slot Picker if CS Rank */}
              {tournament.mode === 'CS_RANK' && !isRegistered && (
                <div className="bg-black/40 p-3.5 rounded-2xl border border-white/5">
                  <h4 className="font-heading font-bold text-white text-xs uppercase tracking-wider mb-2">
                    Choose Squad Slot
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedTeam('Alpha')}
                      className={`p-2 rounded-xl text-center font-bold text-xs transition-all ${
                        selectedTeam === 'Alpha'
                          ? 'bg-red-600 text-white shadow-md'
                          : 'bg-zinc-800 text-slate-300 hover:bg-zinc-700'
                      }`}
                    >
                      Squad Alpha (Red)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedTeam('Bravo')}
                      className={`p-2 rounded-xl text-center font-bold text-xs transition-all ${
                        selectedTeam === 'Bravo'
                          ? 'bg-amber-600 text-white shadow-md'
                          : 'bg-zinc-800 text-slate-300 hover:bg-zinc-700'
                      }`}
                    >
                      Squad Bravo (Gold)
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'room' && (
            <div className="flex flex-col gap-4">
              <div className="bg-black/50 p-4 rounded-2xl border border-white/10 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="font-heading text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-amber-400" />
                    Custom Room Credentials
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    Status: {tournament.status}
                  </span>
                </div>

                {isRegistered || user?.role === 'admin' || user?.role === 'owner' || user?.id === tournament.assignedOfficerId ? (
                  tournament.roomDetails.isRevealed ? (
                    <div className="flex flex-col gap-3">
                      {/* Room ID */}
                      <div className="flex items-center justify-between bg-zinc-900/90 p-3 rounded-xl border border-white/10">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-mono">Room ID</span>
                          <p className="font-mono text-base font-extrabold text-white mt-0.5 tracking-wider">
                            {tournament.roomDetails.roomId}
                          </p>
                        </div>
                        <button
                          onClick={() => copyToClipboard(tournament.roomDetails.roomId || '', 'Room ID')}
                          className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold transition-all"
                        >
                          {copiedField === 'Room ID' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedField === 'Room ID' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>

                      {/* Room Password */}
                      <div className="flex items-center justify-between bg-zinc-900/90 p-3 rounded-xl border border-white/10">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-mono">Password</span>
                          <p className="font-mono text-base font-extrabold text-amber-400 mt-0.5 tracking-wider">
                            {tournament.roomDetails.roomPassword}
                          </p>
                        </div>
                        <button
                          onClick={() => copyToClipboard(tournament.roomDetails.roomPassword || '', 'Password')}
                          className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold transition-all"
                        >
                          {copiedField === 'Password' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedField === 'Password' ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>

                      <p className="text-[11px] text-slate-400 italic">
                        Open Free Fire → Custom Room → Search Room ID → Enter Password. Be in the room 5 minutes before scheduled match start.
                      </p>
                    </div>
                  ) : (
                    <div className="bg-zinc-900 p-4 rounded-xl text-center flex flex-col items-center justify-center gap-1.5">
                      <Lock className="w-6 h-6 text-amber-400" />
                      <h4 className="font-bold text-white text-xs">Room Preparing</h4>
                      <p className="text-[11px] text-slate-400">
                        You are registered! The room ID and password will unlock automatically 10 minutes prior to match launch.
                      </p>
                    </div>
                  )
                ) : (
                  <div className="bg-zinc-900 p-4 rounded-xl text-center flex flex-col items-center justify-center gap-1.5">
                    <Lock className="w-6 h-6 text-red-400" />
                    <h4 className="font-bold text-white text-xs">Credentials Locked</h4>
                    <p className="text-[11px] text-slate-400">
                      Room ID and Password are strictly restricted to registered participants and assigned match officers.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'slots' && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span>Player</span>
                <span>In-Game UID / Team</span>
              </div>

              {tournament.registeredPlayers.length === 0 ? (
                <div className="p-6 text-center text-slate-500 text-xs">
                  No participants registered yet. Be the first to claim a slot!
                </div>
              ) : (
                <div className="space-y-1.5">
                  {tournament.registeredPlayers.map((p, idx) => (
                    <div
                      key={p.id || idx}
                      className="bg-black/30 p-2.5 rounded-xl border border-white/5 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-slate-500 w-5">
                          #{idx + 1}
                        </span>
                        <div>
                          <span className="font-heading font-bold text-white">
                            {p.inGameName}
                          </span>
                          <span className="text-[10px] text-slate-400 ml-1.5">
                            (@{p.username})
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="font-mono text-[11px] text-slate-300">
                          {p.inGameUid}
                        </span>
                        {p.teamSlot && (
                          <span className="ml-1.5 text-[9px] font-bold px-1.5 py-0.5 rounded bg-zinc-800 text-amber-300">
                            {p.teamSlot}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'rules' && (
            <div className="flex flex-col gap-3">
              <div className="bg-red-950/30 border border-red-700/40 rounded-xl p-3">
                <h4 className="font-heading font-bold text-red-200 text-xs uppercase tracking-wider">
                  BR Rank ৪৮ সোলো অফিশিয়াল নিয়মাবলী
                </h4>
                <ul className="list-disc pl-4 mt-1.5 space-y-1.5 text-[11px] text-red-200/90 leading-relaxed">
                  <li><strong>এক জীবন (One Life Only):</strong> কোনো রিভাইভ পয়েন্ট, রিভাইভ কার্ড বা ভেন্ডিং মেশিন কাজ করবে না।</li>
                  <li><strong>এলিমিনেশন মানেই আউট:</strong> ম্যাচে একবার নিহত হলে আপনি তৎক্ষণাৎ টুর্নামেন্ট থেকে বাদ পড়বেন।</li>
                  <li><strong>টপ ৫ কোয়ালিফাই ও রিওয়ার্ড:</strong> শুধুমাত্র ১ম থেকে ৫ম স্থান অর্জনকারী খেলোয়াড়রা পয়েন্ট/পুরস্কার পাওয়ার যোগ্য হবেন। ৬ষ্ঠ থেকে ৪৮তম স্থানধারীরা কোনো পয়েন্ট পাবেন না।</li>
                  <li><strong>পজিশন পয়েন্ট বণ্টন:</strong> ১ম স্থান: ১০০ পয়েন্ট, ২য় স্থান: ৭০ পয়েন্ট, ৩য় স্থান: ৫০ পয়েন্ট, ৪র্থ স্থান: ৩০ পয়েন্ট, ৫ম স্থান: ২০ পয়েন্ট।</li>
                  <li><strong>কিল পয়েন্ট ও ক্যাপ:</strong> প্রতি কিলে ৫ পয়েন্ট। তবে শুধুমাত্র টপ ৫-এ থাকা খেলোয়াড়দের সর্বোচ্চ ৫টি কিলের পয়েন্ট গণনা করা হবে (সর্বোচ্চ ২৫ কিল বোনাস)।</li>
                  <li><strong>উদাহরণ:</strong> ১ম স্থান পেয়ে ৬টি কিল করলেও ৫-কিল ক্যাপের কারণে মোট ১২৫ পয়েন্ট পাবেন।</li>
                  <li><strong>অ্যান্টি-চিটিং ও টিম-আপ নিষেধ:</strong> সোলো ম্যাচে কোনো ধরনের টিম-আপ, হ্যাক বা স্ক্রিপ্ট ব্যবহার করলে সাথে সাথে স্থায়ী ব্ল্যাকলিস্ট করা হবে।</li>
                </ul>
              </div>

              <div className="bg-amber-950/30 border border-amber-700/40 rounded-xl p-3">
                <h4 className="font-heading font-bold text-amber-200 text-xs uppercase tracking-wider">
                  CS Rank ৪v৪ এবং Lone Wolf ১v১ নিয়মাবলী
                </h4>
                <ul className="list-disc pl-4 mt-1.5 space-y-1.5 text-[11px] text-amber-200/90 leading-relaxed">
                  <li><strong>CS Rank (৪ বনাম ৪):</strong> বিজয়ী দলের প্রত্যেক সদস্য ৪০ পয়েন্ট করে পাবেন। গান অ্যাট্রিবিউট অফ থাকবে। প্রতি রাউন্ডে সর্বোচ্চ ১টি গ্রেনেড ব্যবহার করা যাবে।</li>
                  <li><strong>Lone Wolf (১ বনাম ১):</strong> প্রথমে ৫ রাউন্ড বিজয়ী খেলোয়াড় বিজয়ী ঘোষিত হবেন এবং ৩৫ পয়েন্ট পাবেন। কোনো রূপ এমুলেটর বা থার্ড-পার্টি টুলস সম্পূর্ণ নিষিদ্ধ।</li>
                </ul>
              </div>

              <div className="bg-blue-950/30 border border-blue-700/40 rounded-xl p-3">
                <h4 className="font-heading font-bold text-blue-200 text-xs uppercase tracking-wider">
                  রুম কোড ও ম্যাচ জয়েনিং নিয়ম
                </h4>
                <p className="text-[11px] text-blue-200/80 leading-relaxed mt-1">
                  ম্যাচ শুরুর ঠিক ১০ মিনিট আগে রেজিস্টার্ড খেলোয়াড়দের এই স্ক্রিনে কাস্টম রুম আইডি ও পাসওয়ার্ড দেওয়া হবে। নির্ধারিত সময়ের ৫ মিনিট আগে রুমে প্রবেশ করতে হবে।
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer CTAs */}
        <div className="p-4 border-t border-white/10 bg-black/60 flex items-center justify-between gap-3">
          {isRegistered ? (
            <div className="flex items-center justify-between w-full">
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <CheckCircle className="w-4 h-4" />
                আপনি এই ম্যাচে কোয়ালিফাইড ও রেজিস্টার্ড আছেন
              </span>
              <button
                disabled={isSubmitting}
                onClick={handleUnregister}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-red-400 text-xs font-semibold rounded-xl border border-white/10 transition-colors"
              >
                বাতিল করুন
              </button>
            </div>
          ) : isFull ? (
            <div className="w-full text-center py-2 text-slate-400 text-xs font-semibold">
              টুর্নামেন্টের সব স্লট পূর্ণ হয়ে গেছে (All slots filled)
            </div>
          ) : (
            <button
              disabled={isSubmitting || user?.isBanned}
              onClick={handleRegister}
              className={`w-full py-3 rounded-2xl font-heading font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg ${
                user?.isBanned
                  ? 'bg-zinc-800 text-slate-500 cursor-not-allowed'
                  : 'bg-red-600 hover:bg-red-500 text-white shadow-red-950/50 glow-red active:scale-98'
              }`}
            >
              <Flame className="w-4 h-4 fill-white" />
              <span>
                {isSubmitting
                  ? 'প্রসেসিং হচ্ছে...'
                  : `PAY ৳${tournament.entryFee || 50} কোয়ালিফাই করুন`}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
