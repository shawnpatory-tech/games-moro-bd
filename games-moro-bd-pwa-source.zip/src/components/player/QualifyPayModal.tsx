import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Flame,
  Key,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface QualifyPayModalProps {
  tournament: Tournament;
  onClose: () => void;
  onSuccess: () => void;
  onOpenDeposit?: () => void;
  onOpenWallet?: () => void;
}

export const QualifyPayModal: React.FC<QualifyPayModalProps> = ({
  tournament,
  onClose,
  onSuccess,
  onOpenDeposit,
  onOpenWallet,
}) => {
  const triggerDeposit = onOpenWallet || onOpenDeposit || (() => {});
  const { user, walletBalance, refreshUser, showToast } = useAuth();
  const requiredFee = tournament.entryFee !== undefined ? tournament.entryFee : 50;

  const [inGameUid, setInGameUid] = useState<string>(user?.inGameUid || '');
  const [inGameName, setInGameName] = useState<string>(user?.inGameName || '');
  const [balancePaymentInput, setBalancePaymentInput] = useState<number>(requiredFee);
  const [agreeRules, setAgreeRules] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const hasSufficientBalance = walletBalance >= requiredFee;

  const handleConfirmQualify = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!inGameUid.trim() || inGameUid.trim().length < 5) {
      showToast('অনুগ্রহ করে আপনার সঠিক ফ্রি ফায়ার একাউন্ট ইউআইডি (UID) লিখুন।', 'error');
      return;
    }

    if (!hasSufficientBalance) {
      showToast(
        `অপর্যাপ্ত ব্যালেন্স! আপনার ব্যালেন্স ৳${walletBalance} কিন্তু এন্ট্রি ফি ৳${requiredFee}। অনুগ্রহ করে আগে ডিপোজিট করুন।`,
        'error'
      );
      return;
    }

    if (balancePaymentInput < requiredFee) {
      showToast(`ম্যাচে কোয়ালিফাই করার জন্য ন্যূনতম ৳${requiredFee} ব্যালেন্স দিতে হবে।`, 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.qualifyAndPay({
        tournamentId: tournament.id,
        inGameUid: inGameUid.trim(),
        paymentAmount: balancePaymentInput,
      });

      showToast(res.message, 'success');
      await refreshUser();
      onSuccess();
      onClose();
    } catch (err: any) {
      showToast(err.message || 'কোয়ালিফিকেশন ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-[#0e1019] border border-white/10 w-full max-w-md rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6">
        {/* Header */}
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-red-950/60 via-[#121420] to-[#121420]">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-red-500 fill-red-500" />
            <div>
              <h3 className="font-heading font-extrabold text-base text-white uppercase tracking-wider">
                ম্যাচ কোয়ালিফিকেশন ও এন্ট্রি ফি
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">
                {tournament.mode.replace('_', ' ')} · {tournament.title}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleConfirmQualify} className="p-5 flex-1 overflow-y-auto flex flex-col gap-4 text-xs">
          {/* Required Fee Badge Banner */}
          <div className="bg-[#121422] border border-red-600/40 rounded-2xl p-4 flex items-center justify-between shadow-md">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                ম্যাচে খেলার এন্ট্রি ফি
              </span>
              <h4 className="font-heading font-extrabold text-2xl text-red-400 flex items-center gap-1 mt-0.5">
                PAY ৳{requiredFee} <span className="text-xs font-sans text-amber-400">টাকা</span>
              </h4>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                আপনার ওয়ালেট ব্যালেন্স
              </span>
              <p className={`font-heading font-extrabold text-lg mt-0.5 tabular-nums ${
                hasSufficientBalance ? 'text-emerald-400' : 'text-red-400'
              }`}>
                ৳{walletBalance} BDT
              </p>
            </div>
          </div>

          {/* Insufficient Balance Notice if low balance */}
          {!hasSufficientBalance && (
            <div className="bg-red-950/70 border border-red-600/60 rounded-xl p-3 flex flex-col gap-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <p className="text-[11px] text-red-200 leading-snug">
                  আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই! ম্যাচে খেলার জন্য ৳{requiredFee} প্রয়োজন, তবে আপনার ব্যালেন্স ৳{walletBalance}।
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  triggerDeposit();
                }}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-all shadow-md flex items-center justify-center gap-1.5"
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>বিকাশ / নগদ দিয়ে এখনই ডিপোজিট করুন</span>
              </button>
            </div>
          )}

          {/* Step 1: Free Fire Account UID Input */}
          <div className="bg-black/50 border border-white/10 rounded-2xl p-3.5 flex flex-col gap-2">
            <label className="text-[11px] font-bold text-white flex items-center justify-between">
              <span>১. ফ্রি ফায়ার একাউন্ট ইউআইডি (UID) দিন:</span>
              <span className="text-[10px] text-red-400 font-mono">*বাধ্যতামূলক</span>
            </label>
            <p className="text-[10px] text-slate-400 leading-tight -mt-1">
              যেই ফ্রি ফায়ার আইডি দিয়ে আপনি কাস্টম রুমে প্রবেশ করে খেলবেন ওইটির সঠিক নাম্বার ইউআইডি দিন।
            </p>
            <input
              type="text"
              value={inGameUid}
              onChange={(e) => setInGameUid(e.target.value)}
              placeholder="e.g. 192837465"
              required
              className="w-full bg-black/80 border border-white/20 rounded-xl px-3 py-2 text-amber-300 font-mono font-bold text-sm tracking-wider focus:outline-none focus:border-red-500"
            />
          </div>

          {/* Step 2: Payment Amount from App Balance Input */}
          <div className="bg-black/50 border border-white/10 rounded-2xl p-3.5 flex flex-col gap-2">
            <label className="text-[11px] font-bold text-white block">
              ২. অ্যাপ ব্যালেন্স থেকে পরিশোধের পরিমাণ লিখুন:
            </label>
            <p className="text-[10px] text-slate-400 leading-tight -mt-1">
              আপনার ওয়ালেট ব্যালেন্স (৳{walletBalance}) থেকে এই পরিমাণ টাকা কেটে নেওয়া হবে।
            </p>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400">৳</span>
              <input
                type="number"
                min={requiredFee}
                value={balancePaymentInput}
                onChange={(e) => setBalancePaymentInput(Number(e.target.value) || 0)}
                required
                className="w-full bg-black/80 border border-white/20 rounded-xl pl-8 pr-3 py-2 text-white font-mono font-extrabold text-base focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          {/* Step 3: Rules agreement checkbox */}
          <label className="flex items-start gap-2 cursor-pointer text-[11px] text-slate-300 select-none">
            <input
              type="checkbox"
              checked={agreeRules}
              onChange={(e) => setAgreeRules(e.target.checked)}
              className="mt-0.5 rounded accent-red-600"
            />
            <span>
              আমি ফ্রি ফায়ার আইডি ও GAMES MORO BD-এর সকল টুর্নামেন্ট নিয়মাবলী মেনে খেলতে সম্মত আছি।
            </span>
          </label>

          {/* Confirm Button */}
          <button
            type="submit"
            disabled={isSubmitting || !hasSufficientBalance || !agreeRules}
            className={`w-full py-3 rounded-2xl font-heading font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg ${
              hasSufficientBalance && agreeRules
                ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-950/60 glow-red active:scale-98 cursor-pointer'
                : 'bg-zinc-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {isSubmitting
                ? 'কোয়ালিফিকেশন সম্পন্ন হচ্ছে...'
                : `ঠিক আছে / ওকে — কোয়ালিফাই করুন (PAY ৳${requiredFee})`}
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};
