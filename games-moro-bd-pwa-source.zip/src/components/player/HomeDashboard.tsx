import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Swords,
  Crosshair,
  Users,
  Flame,
  ArrowRight,
  Clock,
  CheckCircle,
  AlertTriangle,
  Play,
  Key,
  Shield,
  Sparkles,
  Wallet,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament, TournamentMode } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface HomeDashboardProps {
  onSelectTournament: (tournament: Tournament) => void;
  onNavigateTab: (tab: string) => void;
  onFilterMode: (mode: TournamentMode) => void;
  onOpenRules: () => void;
  onPayQualify: (tournament: Tournament) => void;
  onOpenWallet: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onSelectTournament,
  onNavigateTab,
  onFilterMode,
  onOpenRules,
  onPayQualify,
  onOpenWallet,
}) => {
  const { user, walletBalance, showToast } = useAuth();
  const [upcomingMatches, setUpcomingMatches] = useState<Tournament[]>([]);
  const [liveMatches, setLiveMatches] = useState<Tournament[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchMatches = async () => {
    try {
      setIsLoading(true);
      const res = await api.getTournaments();
      const list = res.tournaments;
      setLiveMatches(
        list.filter((t) => t.status === 'LIVE' || t.status === 'ROOM_PREPARING')
      );
      setUpcomingMatches(
        list.filter(
          (t) =>
            t.status === 'REGISTRATION_OPEN' ||
            t.status === 'REGISTRATION_CLOSED' ||
            t.status === 'UPCOMING'
        )
      );
    } catch (err: any) {
      console.error('Error fetching matches', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMatches();
    const timer = setInterval(fetchMatches, 15000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (dateString: string) => {
    const diff = new Date(dateString).getTime() - Date.now();
    if (diff <= 0) return 'Starting Now';
    const mins = Math.floor(diff / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    if (mins >= 60) {
      const hours = Math.floor(mins / 60);
      return `${hours}h ${mins % 60}m`;
    }
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="flex flex-col gap-5 px-4 pt-4 pb-8">
      {/* Blacklist Warning Banner if user is banned */}
      {user?.isBanned && (
        <div className="bg-red-950/90 border border-red-600/60 rounded-2xl p-4 flex items-start gap-3 glow-red">
          <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-bold text-red-200">
              Tournament Account Blacklisted
            </h4>
            <p className="text-xs text-red-300/80 mt-1">
              Reason: {user.banDetails?.reason || 'Rule violation'}. Tournament registration is suspended.
            </p>
            <button
              onClick={() => onNavigateTab('profile')}
              className="mt-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-500 px-3 py-1.5 rounded-lg transition-colors inline-block"
            >
              View Appeal Status
            </button>
          </div>
        </div>
      )}

      {/* Hero Tournament Banner */}
      <div className="relative rounded-2xl overflow-hidden border border-red-900/40 bg-zinc-950 shadow-xl group">
        <div className="relative h-48 sm:h-56 w-full overflow-hidden">
          <img
            src="/src/assets/images/tournament_hero_banner_1793899507217.jpg"
            alt="Esports Arena"
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 brightness-90"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#090a0f] via-[#090a0f]/60 to-transparent" />
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5 flex flex-col justify-end">
          <div className="flex items-center gap-2 text-xs text-red-400 font-semibold uppercase tracking-wider mb-1">
            <Flame className="w-3.5 h-3.5 fill-red-500 text-red-500 animate-pulse" />
            <span>Bangladesh Official Qualifier</span>
            <span>·</span>
            <span className="text-amber-400">Daily 8:00 AM - Midnight</span>
          </div>

          <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-white tracking-wide leading-tight uppercase">
            Bermuda <span className="text-red-500">Championship</span> 2026
          </h2>

          <p className="text-xs text-slate-300 mt-1 line-clamp-1">
            BR Rank Solo 48 · One Life No Revive · Top 5 Qualify · 5-Kill Reward Cap
          </p>

          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={() => onNavigateTab('tournaments')}
              className="flex items-center gap-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase px-4 py-2 rounded-xl transition-all shadow-md shadow-red-950/40 glow-red active:scale-95"
            >
              <span>Explore Matches</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onOpenRules}
              className="flex items-center gap-1 bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold px-3 py-2 rounded-xl border border-white/10 transition-colors"
            >
              <span>View Rules</span>
            </button>
          </div>
        </div>
      </div>

      {/* Player Stats Bar */}
      {user && (
        <div className="bg-[#10121c] border border-white/10 rounded-2xl p-3.5 shadow-md">
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div className="flex items-center gap-2.5">
              <img
                src={user.avatar}
                alt={user.username}
                className="w-10 h-10 rounded-full object-cover border border-red-500/50"
              />
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-heading font-bold text-sm text-white">
                    {user.inGameName}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/40">
                    {user.tournamentUid}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">
                  IGN UID: {user.inGameUid}
                </span>
              </div>
            </div>

            <div className="flex flex-col items-end">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
                Tournament Points
              </span>
              <span className="font-heading text-lg font-extrabold text-amber-300 tabular-nums">
                {user.stats.tournamentPoints} <span className="text-xs text-amber-400 font-normal">TP</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-5 gap-1.5 pt-3 text-center items-center">
            <div className="flex flex-col">
              <span className="text-[10px] font-medium text-slate-400">ব্যালেন্স</span>
              <button
                onClick={onOpenWallet}
                className="text-xs font-mono font-bold text-emerald-400 hover:underline tabular-nums"
                title="ডিপোজিট / উইথড্র"
              >
                ৳{walletBalance}
              </button>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-medium text-slate-400">ম্যাচ</span>
              <span className="text-sm font-bold text-white tabular-nums">
                {user.stats.matchesPlayed}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-medium text-slate-400">জয় (Wins)</span>
              <span className="text-sm font-bold text-emerald-400 tabular-nums">
                {user.stats.wins}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-medium text-slate-400">মোট কিল</span>
              <span className="text-sm font-bold text-red-400 tabular-nums">
                {user.stats.kills}
              </span>
            </div>
            <div className="flex flex-col">
              <button
                onClick={onOpenWallet}
                className="px-2 py-1 rounded-lg bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 font-bold text-[10px] hover:bg-emerald-900/80 transition-colors"
              >
                + ডিপোজিট
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tournament Modes Grid */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <h3 className="font-heading text-base font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <Crosshair className="w-4 h-4 text-red-500" />
            Tournament Modes
          </h3>
          <span className="text-[11px] text-slate-400 font-medium">Free Fire Format</span>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          {/* BR RANK */}
          <button
            onClick={() => onFilterMode('BR_RANK')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#11131e] hover:bg-[#161928] border border-red-900/30 hover:border-red-600/50 transition-all text-center group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-red-950/70 border border-red-700/50 flex items-center justify-center text-red-400 group-hover:scale-110 transition-transform mb-1.5">
              <Trophy className="w-4 h-4 text-red-400" />
            </div>
            <span className="font-heading font-extrabold text-xs text-white uppercase tracking-wide">
              BR RANK
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5">Solo · 48 Slots</span>
            <span className="text-[9px] text-red-400 font-medium mt-1">Every 40m</span>
          </button>

          {/* CS RANK */}
          <button
            onClick={() => onFilterMode('CS_RANK')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#11131e] hover:bg-[#161928] border border-amber-900/30 hover:border-amber-600/50 transition-all text-center group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-950/70 border border-amber-700/50 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform mb-1.5">
              <Users className="w-4 h-4 text-amber-400" />
            </div>
            <span className="font-heading font-extrabold text-xs text-white uppercase tracking-wide">
              CS RANK
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5">Squad · 4 vs 4</span>
            <span className="text-[9px] text-amber-400 font-medium mt-1">Every 30m</span>
          </button>

          {/* LONE WOLF */}
          <button
            onClick={() => onFilterMode('LONE_WOLF')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#11131e] hover:bg-[#161928] border border-blue-900/30 hover:border-blue-600/50 transition-all text-center group cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-950/70 border border-blue-700/50 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform mb-1.5">
              <Swords className="w-4 h-4 text-blue-400" />
            </div>
            <span className="font-heading font-extrabold text-xs text-white uppercase tracking-wide">
              LONE WOLF
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5">Duel · 1 vs 1</span>
            <span className="text-[9px] text-blue-400 font-medium mt-1">Every 30m</span>
          </button>
        </div>
      </div>

      {/* Live / Room Preparing Section */}
      {liveMatches.length > 0 && (
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
              </span>
              Live & Room Preparing
            </h3>
            <span className="text-[11px] text-red-400 font-bold uppercase tracking-wider">
              {liveMatches.length} Matches Live
            </span>
          </div>

          <div className="flex flex-col gap-2.5">
            {liveMatches.map((match) => {
              const isRegistered = match.registeredPlayers.some((p) => p.userId === user?.id);

              return (
                <div
                  key={match.id}
                  onClick={() => onSelectTournament(match)}
                  className="bg-gradient-to-r from-red-950/40 via-[#10121c] to-[#10121c] border border-red-600/40 rounded-2xl p-3.5 flex flex-col gap-2.5 cursor-pointer hover:border-red-500 transition-all shadow-md group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-red-600 text-white shadow-xs">
                      {match.status === 'ROOM_PREPARING' ? 'Room Ready' : 'Match Live'}
                    </span>
                    <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-red-400" />
                      {formatCountdown(match.startTime)}
                    </span>
                  </div>

                  <div className="flex items-start justify-between gap-2">
                    <div className="flex flex-col">
                      <h4 className="font-heading font-extrabold text-sm text-white group-hover:text-red-300 transition-colors">
                        {match.title}
                      </h4>
                      <span className="text-[11px] text-slate-400">
                        Officer on duty: {match.assignedOfficerName || 'Assigned'}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 bg-black/60 px-2.5 py-1.5 rounded-xl border border-white/10 text-xs">
                      <Key className="w-3.5 h-3.5 text-amber-400" />
                      <span className="font-mono font-semibold text-slate-200">
                        {isRegistered
                          ? match.roomDetails.isRevealed
                            ? 'Room Unlocked'
                            : 'Room Pending'
                          : 'Registered Only'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5">
                    <span className="text-slate-400 text-[11px]">
                      {match.mode.replace('_', ' ')} · {match.slotsFilled}/{match.maxPlayers} Players
                    </span>
                    <span className="text-red-400 font-semibold flex items-center gap-1 text-[11px] group-hover:translate-x-1 transition-transform">
                      {isRegistered ? 'View Room Info' : 'View Match Details'} →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Upcoming Tournaments Feed */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <h3 className="font-heading text-base font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-500" />
            Upcoming Tournaments
          </h3>
          <button
            onClick={() => onNavigateTab('tournaments')}
            className="text-[11px] text-red-400 hover:text-red-300 font-bold uppercase tracking-wider"
          >
            View All ({upcomingMatches.length})
          </button>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            Loading scheduled matches...
          </div>
        ) : upcomingMatches.length === 0 ? (
          <div className="bg-[#10121c] border border-white/10 rounded-2xl p-6 text-center text-slate-400 text-xs">
            No upcoming tournaments right now.
          </div>
        ) : (
          <div className="flex flex-col gap-2.5">
            {upcomingMatches.slice(0, 4).map((match) => {
              const isRegistered = match.registeredPlayers.some((p) => p.userId === user?.id);
              const percentage = Math.round((match.slotsFilled / match.maxPlayers) * 100);

              return (
                <div
                  key={match.id}
                  onClick={() => onSelectTournament(match)}
                  className="bg-[#10121c] border border-white/10 hover:border-red-600/50 rounded-2xl p-3.5 flex flex-col gap-2.5 cursor-pointer transition-all shadow-sm group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                          match.mode === 'BR_RANK'
                            ? 'bg-red-950 text-red-300 border border-red-800/40'
                            : match.mode === 'CS_RANK'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800/40'
                            : 'bg-blue-950 text-blue-300 border border-blue-800/40'
                        }`}
                      >
                        {match.mode.replace('_', ' ')}
                      </span>
                      <span className="text-[11px] text-slate-400 font-medium">
                        {match.entryType}
                      </span>
                    </div>

                    <span className="text-xs font-mono text-slate-300 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-red-400" />
                      Starts in {formatCountdown(match.startTime)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <div className="flex flex-col flex-1">
                      <h4 className="font-heading font-extrabold text-sm text-white group-hover:text-red-400 transition-colors truncate">
                        {match.title}
                      </h4>
                      <span className="text-[11px] text-slate-400">
                        Map: {match.roomDetails.customMap || 'Bermuda'} · Prize: {match.pointsPrizePool} TP
                      </span>
                    </div>

                    {isRegistered ? (
                      <span className="shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-600/40 text-emerald-300 text-xs font-bold">
                        <CheckCircle className="w-3.5 h-3.5" />
                        কোয়ালিফাইড
                      </span>
                    ) : match.slotsFilled >= match.maxPlayers ? (
                      <span className="shrink-0 px-2.5 py-1.5 rounded-xl bg-zinc-800 text-slate-400 text-xs font-bold">
                        স্লট পূর্ণ
                      </span>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onPayQualify(match);
                        }}
                        className="shrink-0 px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-heading font-black text-xs uppercase tracking-wider transition-all shadow-md glow-red flex items-center gap-1 active:scale-95 cursor-pointer"
                      >
                        <span>PAY ৳{match.entryFee !== undefined ? match.entryFee : 50}</span>
                      </button>
                    )}
                  </div>

                  {/* Slot progress bar */}
                  <div className="flex flex-col gap-1 pt-1">
                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
                      <span>Slots: {match.slotsFilled}/{match.maxPlayers}</span>
                      <span>{percentage}% Filled</span>
                    </div>
                    <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          percentage >= 90
                            ? 'bg-red-500'
                            : percentage >= 50
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Fair Play & Anti-Cheat Esports Guarantee Card */}
      <div className="rounded-2xl border border-white/10 bg-[#0c0e17] p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-red-950/80 border border-red-700/50 flex items-center justify-center shrink-0">
          <Shield className="w-5 h-5 text-red-400" />
        </div>
        <div className="flex flex-col">
          <h4 className="font-heading font-bold text-sm text-white">
            Official Anti-Cheat & Fair Play
          </h4>
          <p className="text-[11px] text-slate-400 leading-tight mt-0.5">
            Every match is supervised by an assigned officer. Screenshots and kill logs are audited by Admins.
          </p>
        </div>
      </div>
    </div>
  );
};
