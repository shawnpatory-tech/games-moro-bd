import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Search,
  Filter,
  Clock,
  Users,
  CheckCircle,
  Key,
  Shield,
  Flame,
  Calendar,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';
import type { Tournament, TournamentMode, TournamentStatus } from '../../types/index.ts';
import { api } from '../../services/api.ts';

interface TournamentFeedProps {
  initialMode?: TournamentMode;
  onSelectTournament: (tournament: Tournament) => void;
  onPayQualify: (tournament: Tournament) => void;
}

export const TournamentFeed: React.FC<TournamentFeedProps> = ({
  initialMode,
  onSelectTournament,
  onPayQualify,
}) => {
  const { user } = useAuth();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedMode, setSelectedMode] = useState<string>(initialMode || 'ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchTournaments = async () => {
    try {
      setIsLoading(true);
      const res = await api.getTournaments({
        mode: selectedMode !== 'ALL' ? selectedMode : undefined,
        status: selectedStatus !== 'ALL' ? selectedStatus : undefined,
        search: searchQuery.trim() || undefined,
      });
      setTournaments(res.tournaments);
    } catch (err) {
      console.error('Error fetching tournaments', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTournaments();
  }, [selectedMode, selectedStatus, searchQuery]);

  const modeFilters = [
    { id: 'ALL', label: 'All Modes' },
    { id: 'BR_RANK', label: 'BR Rank (Solo 48)' },
    { id: 'CS_RANK', label: 'CS Rank (4v4)' },
    { id: 'LONE_WOLF', label: 'Lone Wolf (1v1)' },
  ];

  const statusFilters = [
    { id: 'ALL', label: 'All Status' },
    { id: 'REGISTRATION_OPEN', label: 'Open' },
    { id: 'ROOM_PREPARING', label: 'Room Ready' },
    { id: 'LIVE', label: 'Live' },
    { id: 'COMPLETED', label: 'Completed' },
  ];

  const getStatusBadge = (status: TournamentStatus) => {
    switch (status) {
      case 'REGISTRATION_OPEN':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700/40">OPEN</span>;
      case 'REGISTRATION_CLOSED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">FULL</span>;
      case 'ROOM_PREPARING':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700/40 animate-pulse">ROOM READY</span>;
      case 'LIVE':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-600 text-white font-mono">LIVE MATCH</span>;
      case 'REPORT_PENDING':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-700/40">VERIFYING</span>;
      case 'COMPLETED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-900 text-slate-400">FINISHED</span>;
      default:
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-800 text-slate-300">SCHEDULED</span>;
    }
  };

  return (
    <div className="flex flex-col gap-4 px-4 pt-4 pb-12">
      {/* Page Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-xl font-extrabold text-white uppercase tracking-wider">
            Tournament Arena
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real Free Fire BR, CS & Lone Wolf Competitive Rooms
          </p>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search tournaments, maps or modes..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-[#10121c] border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
          >
            Clear
          </button>
        )}
      </div>

      {/* Mode Filters (Segmented Buttons) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {modeFilters.map((m) => {
          const isActive = selectedMode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => setSelectedMode(m.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                isActive
                  ? 'bg-red-600 text-white shadow-sm shadow-red-950/40'
                  : 'bg-[#10121c] text-slate-400 hover:text-slate-200 border border-white/5'
              }`}
            >
              {m.label}
            </button>
          );
        })}
      </div>

      {/* Status Secondary Filter */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[11px]">
        {statusFilters.map((s) => {
          const isActive = selectedStatus === s.id;
          return (
            <button
              key={s.id}
              onClick={() => setSelectedStatus(s.id)}
              className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? 'bg-zinc-800 text-amber-300 font-bold border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {s.label}
            </button>
          );
        })}
      </div>

      {/* Tournament Cards List */}
      {isLoading ? (
        <div className="p-12 text-center text-slate-400 text-xs">
          Loading tournaments...
        </div>
      ) : tournaments.length === 0 ? (
        <div className="bg-[#10121c] border border-white/10 rounded-2xl p-8 text-center flex flex-col items-center justify-center gap-2">
          <Trophy className="w-8 h-8 text-slate-500" />
          <h4 className="font-heading text-base font-bold text-white">
            No Tournaments Found
          </h4>
          <p className="text-xs text-slate-400 max-w-xs">
            No matches match your current filter settings. Try clearing search or resetting mode filters.
          </p>
          <button
            onClick={() => {
              setSelectedMode('ALL');
              setSelectedStatus('ALL');
              setSearchQuery('');
            }}
            className="mt-2 text-xs font-semibold text-red-400 hover:text-red-300 underline"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {tournaments.map((t) => {
            const isRegistered = t.registeredPlayers.some((p) => p.userId === user?.id);
            const percentage = Math.round((t.slotsFilled / t.maxPlayers) * 100);
            const isFull = t.slotsFilled >= t.maxPlayers;
            const startTimeDate = new Date(t.startTime);

            return (
              <div
                key={t.id}
                onClick={() => onSelectTournament(t)}
                className="bg-[#10121c] border border-white/10 hover:border-red-600/50 rounded-2xl p-4 flex flex-col gap-3 cursor-pointer transition-all shadow-sm group"
              >
                {/* Header: Mode Badge + Status + Entry Type */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded ${
                        t.mode === 'BR_RANK'
                          ? 'bg-red-950 text-red-300 border border-red-800/40'
                          : t.mode === 'CS_RANK'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800/40'
                          : 'bg-blue-950 text-blue-300 border border-blue-800/40'
                      }`}
                    >
                      {t.mode.replace('_', ' ')}
                    </span>
                    {getStatusBadge(t.status)}
                  </div>

                  <span className="text-[11px] font-mono text-slate-300 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-red-400" />
                    {startTimeDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Match Title & Map Details */}
                <div>
                  <h3 className="font-heading font-extrabold text-base text-white group-hover:text-red-400 transition-colors leading-tight">
                    {t.title}
                  </h3>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                    <span>Map: {t.roomDetails.customMap || 'Bermuda'}</span>
                    <span>·</span>
                    <span>Region: {t.roomDetails.serverRegion || 'Bangladesh'}</span>
                    <span>·</span>
                    <span className="text-amber-400 font-semibold">{t.pointsPrizePool} TP Pool</span>
                  </div>
                </div>

                {/* Slots meter */}
                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-slate-500" />
                      Participants: {t.slotsFilled}/{t.maxPlayers}
                    </span>
                    <span className="font-mono text-xs">{percentage}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        percentage >= 90
                          ? 'bg-red-500'
                          : percentage >= 50
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>

                {/* Action CTA & Officer Indicator */}
                <div className="flex items-center justify-between pt-2 border-t border-white/5">
                  <span className="text-[10px] text-slate-400">
                    Officer: {t.assignedOfficerName || 'Assigned on Match Start'}
                  </span>

                  {isRegistered ? (
                    <span className="flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-xl border border-emerald-600/30">
                      <CheckCircle className="w-3.5 h-3.5" />
                      কোয়ালিফাইড
                    </span>
                  ) : isFull ? (
                    <span className="text-xs font-semibold text-slate-500 bg-zinc-900 px-2.5 py-1 rounded-xl">
                      স্লট পূর্ণ
                    </span>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPayQualify(t);
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-heading font-black text-xs uppercase tracking-wider transition-all shadow-md glow-red flex items-center gap-1 active:scale-95 cursor-pointer"
                    >
                      <span>PAY ৳{t.entryFee !== undefined ? t.entryFee : 50}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
