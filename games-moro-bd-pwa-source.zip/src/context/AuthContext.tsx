import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, UserRole, AppNotification } from '../types/index.ts';
import { api } from '../services/api.ts';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AuthContextType {
  user: User | null;
  role: UserRole;
  isLoading: boolean;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  switchRole: (role: UserRole, userId?: string) => Promise<void>;
  registerPlayer: (data: {
    username: string;
    inGameName: string;
    inGameUid: string;
    email?: string;
    phone?: string;
  }) => Promise<void>;
  sendPhoneOtp: (phone: string) => Promise<string>;
  verifyPhoneOtp: (phone: string, otp: string) => Promise<void>;
  loginWithGoogle: (email: string) => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  notifications: AppNotification[];
  unreadNotifsCount: number;
  refreshNotifications: () => Promise<void>;
  markNotificationsAsRead: () => Promise<void>;
  walletBalance: number;
  deposit: (method: 'bKash' | 'Nagad' | 'Rocket', amount: number, senderPhone: string, trxId: string) => Promise<void>;
  withdraw: (method: 'bKash' | 'Nagad' | 'Rocket', amount: number, receiverPhone: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const refreshUser = async () => {
    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch (err) {
      console.error('Failed to load user session', err);
    }
  };

  const refreshNotifications = async () => {
    try {
      const res = await api.getNotifications();
      setNotifications(res.notifications);
    } catch (err) {
      console.error('Failed to load notifications', err);
    }
  };

  const markNotificationsAsRead = async () => {
    try {
      await api.markNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch (err) {
      console.error('Error marking notifications read', err);
    }
  };

  useEffect(() => {
    async function init() {
      setIsLoading(true);
      await Promise.allSettled([refreshUser(), refreshNotifications()]);
      setIsLoading(false);
    }
    init();

    const interval = setInterval(() => {
      refreshNotifications();
    }, 20000);

    return () => clearInterval(interval);
  }, []);

  const switchRole = async (targetRole: UserRole, userId?: string) => {
    try {
      setIsLoading(true);
      const res = await api.switchRole(targetRole, userId);
      setUser(res.user);
      await refreshNotifications();
      showToast(`Switched perspective to ${targetRole.toUpperCase()}: ${res.user.username}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to switch role', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const registerPlayer = async (data: {
    username: string;
    inGameName: string;
    inGameUid: string;
    email?: string;
    phone?: string;
  }) => {
    try {
      setIsLoading(true);
      const res = await api.register(data);
      setUser(res.user);
      showToast(`Welcome ${res.user.username}! Tournament UID assigned: ${res.user.tournamentUid}`, 'success');
      await refreshNotifications();
    } catch (err: any) {
      showToast(err.message || 'Registration failed', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const sendPhoneOtp = async (phone: string) => {
    try {
      const res = await api.sendOtp(phone);
      showToast(res.message, 'info');
      return res.testOtp;
    } catch (err: any) {
      showToast(err.message || 'Failed to send OTP', 'error');
      throw err;
    }
  };

  const verifyPhoneOtp = async (phone: string, otp: string) => {
    try {
      setIsLoading(true);
      const res = await api.verifyOtp(phone, otp);
      setUser(res.user);
      showToast(`Verified! Logged in as ${res.user.username}`, 'success');
      await refreshNotifications();
    } catch (err: any) {
      showToast(err.message || 'Invalid OTP code', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async (email: string) => {
    try {
      setIsLoading(true);
      // Simulate OAuth pop-up login with Google account
      const mockUsername = email.split('@')[0] || 'Gamer';
      const res = await api.register({
        email,
        username: mockUsername,
        inGameName: `${mockUsername.toUpperCase()}亗BD`,
        inGameUid: `${Math.floor(100000000 + Math.random() * 900000000)}`,
      });
      setUser(res.user);
      showToast(`Google Sign-in successful as ${res.user.email}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Google Sign-in failed', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (data: Partial<User>) => {
    try {
      const res = await api.updateProfile(data);
      setUser(res.user);
      showToast('Profile updated successfully', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update profile', 'error');
      throw err;
    }
  };

  const logout = () => {
    // Switch to a guest player or reset
    switchRole('player');
    showToast('Logged out of session', 'info');
  };

  const deposit = async (
    method: 'bKash' | 'Nagad' | 'Rocket',
    amount: number,
    senderPhone: string,
    trxId: string
  ) => {
    try {
      setIsLoading(true);
      const res = await api.depositMoney({ method, amount, senderPhone, trxId });
      if (user) {
        setUser({ ...user, walletBalance: res.balance });
      }
      showToast(res.message, 'success');
      await refreshUser();
    } catch (err: any) {
      showToast(err.message || 'ডিপোজিট ব্যর্থ হয়েছে', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const withdraw = async (
    method: 'bKash' | 'Nagad' | 'Rocket',
    amount: number,
    receiverPhone: string
  ) => {
    try {
      setIsLoading(true);
      const res = await api.withdrawMoney({ method, amount, receiverPhone });
      if (user) {
        setUser({ ...user, walletBalance: res.balance });
      }
      showToast(res.message, 'success');
      await refreshUser();
    } catch (err: any) {
      showToast(err.message || 'উইথড্র ব্যর্থ হয়েছে', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;
  const walletBalance = user?.walletBalance || 0;

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user?.role || 'player',
        isLoading,
        toasts,
        showToast,
        removeToast,
        switchRole,
        registerPlayer,
        sendPhoneOtp,
        verifyPhoneOtp,
        loginWithGoogle,
        updateProfile,
        logout,
        refreshUser,
        notifications,
        unreadNotifsCount,
        refreshNotifications,
        markNotificationsAsRead,
        walletBalance,
        deposit,
        withdraw,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
