export type UserRole = 'player' | 'officer' | 'admin' | 'owner';

export interface UserStats {
  matchesPlayed: number;
  wins: number;
  kills: number;
  top5Count: number;
  tournamentPoints: number;
  winRate: number;
  kda: number;
}

export interface BanDetails {
  reason: string;
  evidenceUrl?: string;
  bannedAt: string;
  bannedByName: string;
  duration: '24h' | '7d' | '30d' | 'permanent';
  appealStatus?: 'NONE' | 'PENDING' | 'APPROVED' | 'REJECTED';
  appealReason?: string;
  appealSubmittedAt?: string;
}

export interface User {
  id: string;
  email: string;
  phone: string;
  username: string;
  inGameName: string;
  inGameUid: string;
  tournamentUid: string;
  role: UserRole;
  avatar: string;
  isBanned: boolean;
  banDetails?: BanDetails;
  createdAt: string;
  stats: UserStats;
  walletBalance: number; // In BDT (৳)
}

export type TournamentMode = 'BR_RANK' | 'CS_RANK' | 'LONE_WOLF';

export type TournamentStatus =
  | 'UPCOMING'
  | 'REGISTRATION_OPEN'
  | 'REGISTRATION_CLOSED'
  | 'ROOM_PREPARING'
  | 'LIVE'
  | 'REPORT_PENDING'
  | 'COMPLETED'
  | 'CANCELLED';

export interface Participant {
  id: string;
  userId: string;
  username: string;
  inGameName: string;
  inGameUid: string;
  registeredAt: string;
  teamName?: string;
  teamSlot?: 'Alpha' | 'Bravo';
  placement?: number;
  kills?: number;
  pointsAwarded?: number;
}

export interface RoomDetails {
  roomId?: string;
  roomPassword?: string;
  isRevealed: boolean;
  customMap?: string;
  serverRegion?: string;
}

export interface Tournament {
  id: string;
  title: string;
  mode: TournamentMode;
  maxPlayers: number;
  slotsFilled: number;
  startTime: string;
  endTime?: string;
  status: TournamentStatus;
  entryType: 'Free Official Qualifier' | 'Championship Slot' | 'Weekly Clash';
  entryFee: number; // Entry fee in BDT (৳), e.g. 50, 30, 20
  roomDetails: RoomDetails;
  assignedOfficerId?: string;
  assignedOfficerName?: string;
  backupOfficerId?: string;
  backupOfficerName?: string;
  pointsPrizePool: number;
  rulesSummary: string[];
  registeredPlayers: Participant[];
  createdAt: string;
}

export type PaymentMethod = 'bKash' | 'Nagad' | 'Rocket';

export type TransactionType = 'DEPOSIT' | 'WITHDRAW' | 'MATCH_ENTRY_FEE' | 'QUALIFY_FEE' | 'PRIZE_REWARD';

export interface WalletTransaction {
  id: string;
  userId: string;
  username: string;
  userName?: string;
  type: TransactionType;
  amount: number;
  method?: PaymentMethod;
  senderPhone?: string;
  receiverPhone?: string;
  trxId?: string;
  inGameUid?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED';
  timestamp: string;
  createdAt?: string;
  matchId?: string;
  matchTitle?: string;
  adminNotes?: string;
}

export interface MatchReportResult {
  userId: string;
  username: string;
  inGameName: string;
  inGameUid: string;
  placement: number;
  kills: number;
  calculatedPoints: number;
  teamSlot?: 'Alpha' | 'Bravo';
}

export interface MatchReport {
  id: string;
  tournamentId: string;
  tournamentTitle: string;
  mode: TournamentMode;
  submittedByOfficerId: string;
  submittedByOfficerName: string;
  submittedAt: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  results: MatchReportResult[];
  evidenceScreenshotUrl: string;
  officerNotes: string;
  reviewedByAdminId?: string;
  reviewedByAdminName?: string;
  reviewedAt?: string;
  rejectionReason?: string;
}

export interface ScoringConfig {
  brRank: {
    rank1: number;
    rank2: number;
    rank3: number;
    rank4: number;
    rank5: number;
    killPoints: number;
    maxRewardedKills: number; // Cap, e.g. 5
  };
  csRank: {
    winTeamPoints: number;
    loseTeamPoints: number;
    mvpBonusPoints: number;
    killPoint: number;
  };
  loneWolf: {
    winPoints: number;
    losePoints: number;
    flawlessBonus: number;
  };
}

export interface BlacklistEntry {
  id: string;
  userId: string;
  inGameUid: string;
  username: string;
  reason: string;
  evidenceUrl?: string;
  bannedAt: string;
  bannedByAdminId: string;
  bannedByAdminName: string;
  duration: '24h' | '7d' | '30d' | 'permanent';
  appealStatus: 'NONE' | 'PENDING' | 'APPROVED' | 'REJECTED';
  appealReason?: string;
  appealDate?: string;
  appealDecisionNotes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  details: string;
  targetId?: string;
  targetName?: string;
}

export interface AppNotification {
  id: string;
  userId?: string; // If undefined, broadcast to all
  title: string;
  message: string;
  type: 'REGISTRATION' | 'ROOM_ALERT' | 'RESULT_READY' | 'SYSTEM_ALERT' | 'OFFICER_DUTY';
  timestamp: string;
  isRead: boolean;
  tournamentId?: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  username: string;
  inGameUid: string;
  subject: string;
  category: 'Match Dispute' | 'Room Access' | 'Registration' | 'Report Player' | 'Other';
  message: string;
  status: 'OPEN' | 'RESOLVED';
  createdAt: string;
  adminReply?: string;
}

export interface AppSettings {
  appName: string;
  tagline: string;
  emergencyBanner: {
    enabled: boolean;
    type: 'WARNING' | 'ALERT' | 'INFO' | 'MAINTENANCE';
    message: string;
    linkUrl?: string;
  };
  contactNumbers: {
    bKash: string;
    nagad: string;
    rocket: string;
    supportPhone: string;
    whatsapp: string;
  };
  tutorialVideo: {
    enabled: boolean;
    title: string;
    videoUrl: string;
    description: string;
  };
  noticeBoardText: string;
  shareMessage: string;
}

export interface AbnormalPlayReport {
  id: string;
  tournamentId: string;
  tournamentTitle: string;
  officerId: string;
  officerName: string;
  accusedPlayerName: string;
  accusedPlayerUid: string;
  accusedUserId?: string;
  cheatType: 'PANEL_HACK' | 'AIMBOT_HEADSHOT' | 'WALLHACK_ESP' | 'SPEED_HACK' | 'ILLEGAL_TEAMING' | 'CONFIG_MOD';
  cheatTypeBangla: string;
  evidenceUrl: string;
  videoProofUrl?: string;
  incidentRoundOrTime: string;
  description: string;
  status: 'PENDING_REVIEW' | 'BANNED' | 'DISMISSED';
  submittedAt: string;
  reviewedByAdminName?: string;
  adminActionNotes?: string;
}
