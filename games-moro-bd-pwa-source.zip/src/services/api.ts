import type {
  User,
  Tournament,
  ScoringConfig,
  MatchReport,
  BlacklistEntry,
  AuditLog,
  AppNotification,
  SupportTicket,
  UserRole,
  WalletTransaction,
  AppSettings,
  AbnormalPlayReport,
} from '../types/index.ts';

const API_BASE = '/api';

async function fetchJson<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${url}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}));
    throw new Error(errorBody.error || `Request failed with status ${res.status}`);
  }

  return res.json();
}

export const api = {
  // Authentication & Session
  async getMe(): Promise<{ user: User }> {
    return fetchJson('/auth/me');
  },

  async switchRole(role?: UserRole, userId?: string): Promise<{ success: boolean; user: User }> {
    return fetchJson('/auth/switch-role', {
      method: 'POST',
      body: JSON.stringify({ role, userId }),
    });
  },

  async register(data: {
    username: string;
    inGameName: string;
    inGameUid: string;
    email?: string;
    phone?: string;
  }): Promise<{ success: boolean; user: User }> {
    return fetchJson('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async sendOtp(phone: string): Promise<{ success: boolean; message: string; testOtp: string }> {
    return fetchJson('/auth/phone-otp/send', {
      method: 'POST',
      body: JSON.stringify({ phone }),
    });
  },

  async verifyOtp(phone: string, otp: string): Promise<{ success: boolean; user: User }> {
    return fetchJson('/auth/phone-otp/verify', {
      method: 'POST',
      body: JSON.stringify({ phone, otp }),
    });
  },

  async updateProfile(data: {
    username?: string;
    inGameName?: string;
    inGameUid?: string;
    phone?: string;
    avatar?: string;
  }): Promise<{ success: boolean; user: User }> {
    return fetchJson('/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // Tournaments
  async getTournaments(params?: {
    mode?: string;
    status?: string;
    search?: string;
  }): Promise<{ tournaments: Tournament[] }> {
    const query = new URLSearchParams();
    if (params?.mode) query.set('mode', params.mode);
    if (params?.status) query.set('status', params.status);
    if (params?.search) query.set('search', params.search);
    const qs = query.toString();
    return fetchJson(`/tournaments${qs ? `?${qs}` : ''}`);
  },

  async getTournament(id: string): Promise<{ tournament: Tournament; isRegistered: boolean }> {
    return fetchJson(`/tournaments/${id}`);
  },

  async registerTournament(
    id: string,
    teamSlot?: 'Alpha' | 'Bravo'
  ): Promise<{ success: boolean; tournament: Tournament }> {
    return fetchJson(`/tournaments/${id}/register`, {
      method: 'POST',
      body: JSON.stringify({ teamSlot }),
    });
  },

  async unregisterTournament(id: string): Promise<{ success: boolean; tournament: Tournament }> {
    return fetchJson(`/tournaments/${id}/unregister`, {
      method: 'POST',
    });
  },

  // Schedule & Match Admin
  async generateSchedule(date?: string): Promise<{ success: boolean; count: number; matches: Tournament[] }> {
    return fetchJson('/matches/schedule/generate', {
      method: 'POST',
      body: JSON.stringify({ date }),
    });
  },

  async createTournament(data: any): Promise<{ success: boolean; tournament: Tournament }> {
    return fetchJson('/admin/tournaments', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateTournament(id: string, data: any): Promise<{ success: boolean; tournament: Tournament }> {
    return fetchJson(`/tournaments/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  },

  // Officer Reports & Results Approval
  async submitReport(data: {
    tournamentId: string;
    results: any[];
    evidenceScreenshotUrl?: string;
    officerNotes?: string;
  }): Promise<{ success: boolean; report: MatchReport }> {
    return fetchJson('/officer/reports', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async getReports(status?: string): Promise<{ reports: MatchReport[] }> {
    const qs = status ? `?status=${status}` : '';
    return fetchJson(`/admin/reports${qs}`);
  },

  async approveReport(id: string): Promise<{ success: boolean; report: MatchReport }> {
    return fetchJson(`/admin/reports/${id}/approve`, {
      method: 'POST',
    });
  },

  async rejectReport(id: string, rejectionReason: string): Promise<{ success: boolean; report: MatchReport }> {
    return fetchJson(`/admin/reports/${id}/reject`, {
      method: 'POST',
      body: JSON.stringify({ rejectionReason }),
    });
  },

  // Blacklist & Appeals
  async getBlacklist(): Promise<{ blacklist: BlacklistEntry[] }> {
    return fetchJson('/blacklist');
  },

  async blacklistPlayer(data: {
    inGameUid: string;
    username?: string;
    reason: string;
    evidenceUrl?: string;
    duration?: string;
  }): Promise<{ success: boolean; entry: BlacklistEntry }> {
    return fetchJson('/blacklist', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async unbanPlayer(inGameUid: string): Promise<{ success: boolean }> {
    return fetchJson(`/blacklist/${inGameUid}`, {
      method: 'DELETE',
    });
  },

  async submitAppeal(inGameUid: string, appealReason: string): Promise<{ success: boolean }> {
    return fetchJson('/appeals/submit', {
      method: 'POST',
      body: JSON.stringify({ inGameUid, appealReason }),
    });
  },

  async reviewAppeal(
    inGameUid: string,
    decision: 'APPROVE' | 'REJECT',
    decisionNotes?: string
  ): Promise<{ success: boolean }> {
    return fetchJson('/appeals/review', {
      method: 'POST',
      body: JSON.stringify({ inGameUid, decision, decisionNotes }),
    });
  },

  // Scoring Settings
  async getScoringConfig(): Promise<{ scoringConfig: ScoringConfig }> {
    return fetchJson('/admin/settings/scoring');
  },

  async updateScoringConfig(config: Partial<ScoringConfig>): Promise<{ success: boolean; scoringConfig: ScoringConfig }> {
    return fetchJson('/admin/settings/scoring', {
      method: 'PUT',
      body: JSON.stringify(config),
    });
  },

  // Users Management
  async getUsers(): Promise<{ users: User[] }> {
    return fetchJson('/admin/users');
  },

  async updateUserRole(userId: string, newRole: UserRole): Promise<{ success: boolean; user: User }> {
    return fetchJson(`/admin/users/${userId}/role`, {
      method: 'PATCH',
      body: JSON.stringify({ newRole }),
    });
  },

  // Notifications
  async getNotifications(): Promise<{ notifications: AppNotification[] }> {
    return fetchJson('/notifications');
  },

  async markNotificationsRead(): Promise<{ success: boolean }> {
    return fetchJson('/notifications/mark-read', {
      method: 'POST',
    });
  },

  async broadcastNotification(title: string, message: string): Promise<{ success: boolean; notification: AppNotification }> {
    return fetchJson('/admin/notifications/broadcast', {
      method: 'POST',
      body: JSON.stringify({ title, message }),
    });
  },

  // Audit Logs
  async getAuditLogs(): Promise<{ auditLogs: AuditLog[] }> {
    return fetchJson('/audit-logs');
  },

  // Support Tickets
  async getSupportTickets(): Promise<{ tickets: SupportTicket[] }> {
    return fetchJson('/support/tickets');
  },

  async createSupportTicket(data: {
    subject: string;
    category: string;
    message: string;
  }): Promise<{ success: boolean; ticket: SupportTicket }> {
    return fetchJson('/support/tickets', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async replySupportTicket(id: string, reply: string): Promise<{ success: boolean; ticket: SupportTicket }> {
    return fetchJson(`/support/tickets/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ reply }),
    });
  },

  // Leaderboard
  async getLeaderboard(): Promise<{ leaderboard: any[] }> {
    return fetchJson('/leaderboard');
  },

  // Wallet & Payment
  async getWalletData(): Promise<{ balance: number; transactions: WalletTransaction[] }> {
    return fetchJson('/wallet/my');
  },

  async depositMoney(data: {
    method: 'bKash' | 'Nagad' | 'Rocket';
    amount: number;
    senderPhone: string;
    trxId: string;
  }): Promise<{ success: boolean; message: string; balance: number; transaction: WalletTransaction }> {
    return fetchJson('/wallet/deposit', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async withdrawMoney(data: {
    method: 'bKash' | 'Nagad' | 'Rocket';
    amount: number;
    receiverPhone: string;
  }): Promise<{ success: boolean; message: string; balance: number; transaction: WalletTransaction }> {
    return fetchJson('/wallet/withdraw', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async qualifyAndPay(data: {
    tournamentId: string;
    inGameUid: string;
    paymentAmount: number;
    teamSlot?: 'Alpha' | 'Bravo';
  }): Promise<{ success: boolean; message: string; newBalance: number; tournament: Tournament }> {
    return fetchJson('/wallet/qualify-pay', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async getAdminWalletTransactions(): Promise<{ transactions: WalletTransaction[] }> {
    return fetchJson('/admin/wallet/transactions');
  },

  // App Settings, Emergency Alert & Customizer
  async getAppSettings(): Promise<{ success: boolean; settings: AppSettings }> {
    return fetchJson('/settings');
  },

  async updateAppSettings(data: Partial<AppSettings>): Promise<{ success: boolean; message: string; settings: AppSettings }> {
    return fetchJson('/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  // Officer Abnormal Gameplay / Anti-Cheat Incidents
  async submitAbnormalReport(data: {
    tournamentId: string;
    accusedPlayerName: string;
    accusedPlayerUid: string;
    cheatType: string;
    evidenceUrl?: string;
    videoProofUrl?: string;
    incidentRoundOrTime?: string;
    description: string;
  }): Promise<{ success: boolean; message: string; report: AbnormalPlayReport }> {
    return fetchJson('/officer/incidents', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async getAbnormalReports(): Promise<{ success: boolean; incidents: AbnormalPlayReport[] }> {
    return fetchJson('/admin/incidents');
  },

  async banFromIncident(id: string, adminNotes?: string): Promise<{ success: boolean; message: string; ban: BlacklistEntry }> {
    return fetchJson(`/admin/incidents/${id}/ban`, {
      method: 'POST',
      body: JSON.stringify({ adminNotes }),
    });
  },

  async quickBanPlayer(data: {
    inGameUid: string;
    username?: string;
    reason: string;
    cheatType?: string;
    evidenceUrl?: string;
  }): Promise<{ success: boolean; message: string; ban: BlacklistEntry }> {
    return fetchJson('/admin/quick-ban', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async createOfficer(data: {
    username: string;
    inGameName?: string;
    inGameUid?: string;
    phone?: string;
  }): Promise<{ success: boolean; message: string; officer: User }> {
    return fetchJson('/admin/officers', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};
